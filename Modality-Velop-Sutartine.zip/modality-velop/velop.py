"""Modality Velop: a small, auditable branch-expansion substrate.

The vocabulary is intentionally kept close to the originating proposal.
This is a computational interpretation, not a claim that the words have one
fixed mathematical translation.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from enum import Enum
from math import isfinite, log2
from typing import Iterable


class Mode(str, Enum):
    ADD = "sudėtis"
    MULTIPLY = "daugyba"
    VISION = "vizija"


class Status(str, Enum):
    OPEN = "plėtojasi"
    PAUSED = "pristabdyta"
    CLOSED = "užbaigta"


@dataclass(frozen=True)
class Policy:
    max_magnitude: float = 10_000.0
    max_depth: int = 12
    max_rate: float = 3.0
    max_entropy: float = 2.0
    square_checkpoint: int = 3
    require_agreement: bool = True

    def __post_init__(self) -> None:
        if self.max_magnitude <= 0 or self.max_depth < 1 or self.max_rate <= 0:
            raise ValueError("limits must be positive")
        if self.max_entropy < 0 or self.square_checkpoint < 1:
            raise ValueError("entropy and square checkpoint must be valid")


@dataclass(frozen=True)
class Branch:
    name: str
    value: float
    meaning: str
    path: tuple[str, ...] = ()
    squares: int = 0
    status: Status = Status.OPEN
    reason: str = ""
    consent: bool = True
    routing_embargo: bool = False
    embassy_embargo: bool = False
    lineage: tuple[str, ...] = ()

    @property
    def publishable(self) -> bool:
        return self.status is Status.OPEN and not self.embassy_embargo


@dataclass(frozen=True)
class Proposal:
    mode: Mode
    operand: float = 0.0
    label: str = ""
    rate: float = 1.0
    square: bool = False
    agreement: bool = True  # sutartinė: both sides accept this transition
    consent: bool = True  # the branch can explicitly say "ne"
    routing_embargo: bool = False
    embassy_embargo: bool = False


@dataclass(frozen=True)
class Decision:
    branch: Branch
    accepted: bool
    publishable: bool
    note: str


def apply(branch: Branch, proposal: Proposal, policy: Policy = Policy()) -> Decision:
    """Evaluate one proposal without mutating its parent branch."""
    if branch.status is not Status.OPEN:
        return Decision(branch, False, branch.publishable, "branch is not open")
    if not branch.consent or not proposal.consent:
        closed = replace(branch, consent=False, status=Status.CLOSED, reason="ne: refusal")
        return Decision(closed, False, False, closed.reason)
    if branch.routing_embargo or proposal.routing_embargo:
        paused = replace(branch, routing_embargo=True, status=Status.PAUSED,
                         reason="routing embargo: expansion paused")
        return Decision(paused, False, False, paused.reason)
    if policy.require_agreement and not proposal.agreement:
        return Decision(branch, False, branch.publishable,
                        "sutartinė failed: proposal lacks agreement")
    if not isfinite(branch.value) or not isfinite(proposal.operand) or not isfinite(proposal.rate):
        return Decision(branch, False, branch.publishable, "non-finite input")
    if proposal.rate <= 0 or proposal.rate > policy.max_rate:
        return Decision(branch, False, branch.publishable, "rate outside allowed interval")
    if len(branch.path) >= policy.max_depth:
        closed = replace(branch, status=Status.CLOSED, reason="plėtos riba: depth limit")
        return Decision(closed, False, False, closed.reason)

    if proposal.mode is Mode.ADD:
        value = branch.value + proposal.operand * proposal.rate
    elif proposal.mode is Mode.MULTIPLY:
        value = branch.value * (proposal.operand * proposal.rate)
    elif proposal.mode is Mode.VISION:
        # A vision annotates meaning, without changing the numeric value.
        value = branch.value
    else:
        raise ValueError("unknown modality")

    squares = branch.squares
    if proposal.square:
        if proposal.mode is not Mode.MULTIPLY:
            return Decision(branch, False, branch.publishable,
                            "square is allowed only in multiplication mode")
        value *= value
        squares += 1

    if not isfinite(value) or abs(value) > policy.max_magnitude:
        closed = replace(branch, status=Status.CLOSED, reason="plėtos riba: magnitude limit")
        return Decision(closed, False, False, closed.reason)

    # The third-square checkpoint is a validation gate, not a forced third square.
    if squares == policy.square_checkpoint and proposal.square:
        if not proposal.label.strip():
            return Decision(branch, False, branch.publishable,
                            "third square requires a named meaning")

    label = proposal.label.strip() or proposal.mode.value
    child = Branch(
        name=f"{branch.name}/{label}", value=value,
        meaning=(branch.meaning + " → " + label),
        path=branch.path + (proposal.mode.value,), squares=squares,
        embassy_embargo=branch.embassy_embargo or proposal.embassy_embargo,
        lineage=branch.lineage + (branch.name,),
    )
    note = "third-square checkpoint passed" if squares == policy.square_checkpoint and proposal.square else "expanded"
    if child.embassy_embargo:
        note += "; embassy embargo holds output"
    return Decision(child, True, child.publishable, note)


def resume(branch: Branch, *, release_routing: bool = False) -> Branch:
    """Resume a paused route only through an explicit release."""
    if branch.status is Status.PAUSED and branch.routing_embargo and release_routing:
        return replace(branch, routing_embargo=False, status=Status.OPEN, reason="")
    return branch


def release_output(branch: Branch, *, release_embassy: bool = False) -> Branch:
    """Publishing requires a separate explicit release."""
    return replace(branch, embassy_embargo=False) if release_embassy else branch


def branch_entropy(branches: Iterable[Branch]) -> float:
    """Shannon entropy in bits of open branches weighted by absolute value.

    Equal or zero-valued open branches receive equal weights. This describes
    branching diversity; it does not claim physical thermodynamic entropy.
    """
    active = list(b for b in branches if b.status is Status.OPEN)
    if not active:
        return 0.0
    weights = [abs(b.value) if isfinite(b.value) else 0.0 for b in active]
    total = sum(weights)
    probabilities = [w / total for w in weights] if total > 0 else [1 / len(active)] * len(active)
    return -sum(p * log2(p) for p in probabilities if p > 0)


@dataclass
class Substrate:
    policy: Policy = field(default_factory=Policy)
    branches: dict[str, Branch] = field(default_factory=dict)
    audit: list[str] = field(default_factory=list)

    def add_root(self, name: str, value: float, meaning: str) -> Branch:
        if name in self.branches or not isfinite(value) or abs(value) > self.policy.max_magnitude:
            raise ValueError("root name or value invalid")
        root = Branch(name, value, meaning)
        self.branches[name] = root
        self.audit.append(f"root {name}: {meaning}")
        return root

    def propose(self, parent_name: str, proposal: Proposal) -> Decision:
        parent = self.branches[parent_name]
        decision = apply(parent, proposal, self.policy)
        if decision.branch is not parent:
            if decision.accepted:
                if decision.branch.name in self.branches:
                    raise ValueError("branch label already exists under this parent")
                # Check branching entropy before committing a child.
                projected = list(self.branches.values()) + [decision.branch]
                if branch_entropy(projected) > self.policy.max_entropy:
                    self.audit.append(f"hold {parent_name}: entropy limit")
                    return Decision(parent, False, parent.publishable, "entropy limit")
                self.branches[decision.branch.name] = decision.branch
            else:
                self.branches[parent_name] = decision.branch
        self.audit.append(f"{parent_name}: {decision.note}")
        return decision


def demo() -> None:
    substrate = Substrate()
    branch = substrate.add_root("sutartinė", 1.2, "welcome transvex")
    for number in range(1, 4):
        decision = substrate.propose(branch.name, Proposal(
            Mode.MULTIPLY, operand=1.1, square=True,
            label=f"kvadratas-{number}", rate=1.0))
        print(decision.note, decision.branch.name, round(decision.branch.value, 6))
        if not decision.accepted:
            break
        branch = decision.branch
    held = substrate.propose(branch.name, Proposal(Mode.VISION,
        label="portretas", embassy_embargo=True))
    print(held.note, "publishable=", held.publishable)
    print("entropy=", round(branch_entropy(substrate.branches.values()), 6))


if __name__ == "__main__":
    demo()
