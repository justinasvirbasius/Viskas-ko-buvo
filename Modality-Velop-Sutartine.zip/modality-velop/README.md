# Modality Velop — sutartinės substratas

This is one **proposed computational reading** of your Lithuanian and English vocabulary. It is a small model of how a meaning branches, gains numeric weight, meets a boundary, or stops. The terms remain editable design names, not established mathematical definitions.

## Sutartinės plėtotė

**Substratas** yra pradinė reikšmė ir jos skaitinė būsena. **Modalumas** nusako, ką siūloma daryti: sudėti, dauginti arba kurti vizijos atšaką. **Sutartinė** reiškia, kad perėjimas priimamas; pasakytas **„ne“** užbaigia tik tą atšaką. Kitos atšakos gali plėtotis toliau.

**Daugybos plexorius** daugina reikšmės dydį. Jei įjungtas kvadratas, rezultatas pakeliamas kvadratu. Po trečio tokio veiksmo prašoma aiškiai įvardyti naują prasmę. Jei riba viršijama, seka sustoja ir priežastis lieka įraše. Taip „reikšmė dingo“ žymi nutrūkusią gyvą seką, o jos istorija išlieka.

**Saviraiška** gali plėtotis vizijos atšakoje nekeičiant skaičiaus. **Valdymas** čia nustato ribas: greitį, gylį, dydį ir šakų informacinę entropiją. Maršruto embargo pristabdo judėjimą; išvesties embargo leidžia plėtotis viduje, bet sulaiko rezultatą. Šie ribojimai yra aiškūs modelio sprendimai, ne lietuviškų žodžių privalomos reikšmės.

| Your term | Operational meaning in this version |
| --- | --- |
| **sutartinė** | An explicit agreement flag required for a proposed transition. |
| **daugybos plexorius** | The multiplication modality; addition and vision are separate modalities. |
| **plėtos riba** | Maximum magnitude and branch depth. A breach closes the attempted branch. |
| **trečias kvadratas** | A checkpoint on the third square operation: the proposal must name its meaning. |
| **rates regime** | Each operation has a positive bounded rate. |
| **routing embargo** | Pauses branch expansion until explicitly released. |
| **embassy embargo** | Allows local growth but prevents publication until explicitly released. |
| **entropy govern** | A ceiling on Shannon diversity across open branches. This is information entropy, not thermodynamic entropy. |
| **ne / nope** | Refusal closes that branch while other branches remain available. |
| **saviraiška / portretas** | A vision operation annotates the branch's meaning without changing its numeric value. |
| **atšaka** | A child with its own path and lineage; the parent remains intact. |

The model begins with a root meaning. An addition applies `value + operand × rate`; multiplication applies `value × (operand × rate)`. If `square=True`, it squares the multiplication result and increments the square counter. Vision adds a named annotation. Agreement, consent, rate, depth, magnitude, and entropy are checked before a child is committed. A failed proposal records why; a valid child retains its ancestry.

The third square is **not** a mathematical necessity or proof. It is the requested design checkpoint. Likewise, “government is opposite” is modeled narrowly: a branch can be self-expressive, while governance only sets outer limits and holds. A closed meaning may still remain in the audit history; it does not disappear from that record.

Run with Python 3.10+:

```sh
python3 velop.py
python3 -m unittest discover -v
```

To change the thresholds, instantiate `Policy(max_magnitude=..., max_depth=..., max_rate=..., max_entropy=...)`. To lift a routing hold, use `resume(branch, release_routing=True)`. To publish a held output, use `release_output(branch, release_embassy=True)`. Neither release is automatic.

The default entropy ceiling of 2 bits permits up to four equally weighted open branches; distributions of unequal branch weights have lower entropy. This is an illustrative setting, not a measured property of language or music.
