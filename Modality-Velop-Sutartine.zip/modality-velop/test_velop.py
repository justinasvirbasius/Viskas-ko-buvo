import unittest

from velop import (Branch, Mode, Policy, Proposal, Status, Substrate, apply,
                   branch_entropy, release_output, resume)


class VelopTests(unittest.TestCase):
    def test_three_squares_require_named_checkpoint(self):
        branch = Branch("root", 1.0, "start")
        for i in range(2):
            result = apply(branch, Proposal(Mode.MULTIPLY, 1.2, square=True, label=str(i)))
            self.assertTrue(result.accepted)
            branch = result.branch
        blocked = apply(branch, Proposal(Mode.MULTIPLY, 1.2, square=True))
        self.assertFalse(blocked.accepted)
        accepted = apply(branch, Proposal(Mode.MULTIPLY, 1.2, square=True, label="third"))
        self.assertTrue(accepted.accepted)
        self.assertEqual(accepted.branch.squares, 3)

    def test_refusal_and_embargo_are_distinct(self):
        root = Branch("root", 2.0, "portrait")
        held = apply(root, Proposal(Mode.VISION, label="image", embassy_embargo=True))
        self.assertTrue(held.accepted)
        self.assertFalse(held.publishable)
        self.assertTrue(release_output(held.branch, release_embassy=True).publishable)
        paused = apply(root, Proposal(Mode.ADD, 1.0, routing_embargo=True))
        self.assertEqual(paused.branch.status, Status.PAUSED)
        self.assertEqual(resume(paused.branch, release_routing=True).status, Status.OPEN)
        refused = apply(root, Proposal(Mode.ADD, 1.0, consent=False))
        self.assertEqual(refused.branch.status, Status.CLOSED)

    def test_magnitude_and_entropy_boundary(self):
        root = Branch("root", 5.0, "start")
        exceeded = apply(root, Proposal(Mode.MULTIPLY, 3.0), Policy(max_magnitude=10))
        self.assertFalse(exceeded.accepted)
        self.assertEqual(exceeded.branch.status, Status.CLOSED)
        substrate = Substrate(Policy(max_entropy=0.5))
        substrate.add_root("r", 1.0, "seed")
        result = substrate.propose("r", Proposal(Mode.ADD, 0.0, label="sibling"))
        self.assertFalse(result.accepted)
        self.assertEqual(len(substrate.branches), 1)
        self.assertAlmostEqual(branch_entropy([Branch("a", 1, ""), Branch("b", 1, "")]), 1)


if __name__ == "__main__":
    unittest.main()
