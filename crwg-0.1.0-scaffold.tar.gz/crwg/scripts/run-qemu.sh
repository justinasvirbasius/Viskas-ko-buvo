#!/bin/sh
# Boot the CRWG ISO in QEMU for testing.
# Requires: qemu-system-x86_64
set -eu
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ISO="$ROOT/build/out/crwg.iso"
[ -f "$ISO" ] || { echo "ISO not found at $ISO - run ./build.sh all first" >&2; exit 1; }

exec qemu-system-x86_64 \
    -m 256 \
    -cdrom "$ISO" \
    -boot d \
    -nographic \
    -serial mon:stdio
