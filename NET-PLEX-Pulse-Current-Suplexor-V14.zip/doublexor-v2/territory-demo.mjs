import { TerritorySuplexor } from './territory.mjs';
const net = new TerritorySuplexor([["n1",0.12],["n2",0.32],["n3",0.56],["n4",0.78],["n5",0.92]], [{from:'n1',to:'n2',weight:0.2}], { maxMeanEntropy: 1, maxNodeEntropy: 1 });
net.setOblique({ AB: 0.2, BA: 0.3 });
const result = net.cascadeTerritory();
console.log(JSON.stringify({ committed: result.committed, territory: result.territory, restored: net.restoreTerritory().restored }, null, 2));
if (!result.committed) process.exitCode = 1;
