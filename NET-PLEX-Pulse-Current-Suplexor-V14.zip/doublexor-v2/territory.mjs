import { DoubleStereoSuplexor } from './stereo.mjs';

// Territory routing works on stereo control signals, not PCM samples.
export class TerritorySuplexor extends DoubleStereoSuplexor {
  constructor(nodes, edges, options = {}) {
    super(nodes, edges, options);
    this.territories = { A: 'primary', B: 'secondary' };
    this.oblique = { AB: 0, BA: 0, maxCross: 0.5 };
    this.territoryLog = [];
  }
  setTerritory(group, territory) {
    if (!['A', 'B'].includes(group) || typeof territory !== 'string' || !/^[a-z0-9_-]{1,40}$/i.test(territory)) throw new RangeError('Invalid territory');
    this.territories[group] = territory;
  }
  setOblique(settings = {}) {
    const next = { ...this.oblique, ...settings };
    if (![next.AB, next.BA, next.maxCross].every(Number.isFinite) || next.maxCross < 0 || next.maxCross > 1 || next.AB < 0 || next.BA < 0 || next.AB > next.maxCross || next.BA > next.maxCross) throw new RangeError('Oblique weights exceed territory bounds');
    this.oblique = next;
  }
  renderTerritory() {
    // Snapshot inputs before applying cross-territory routing to prevent order dependence.
    const base = this.renderStereo();
    const routed = structuredClone(base);
    const ab = this.oblique.AB, ba = this.oblique.BA;
    for (const channel of ['left', 'right']) {
      routed.A[channel] = (1 - ba) * base.A[channel] + ba * base.B[channel];
      routed.B[channel] = (1 - ab) * base.B[channel] + ab * base.A[channel];
    }
    return { territories: { ...this.territories }, oblique: { ...this.oblique }, channels: routed };
  }
  cascadeTerritory() {
    // Configuration is validated before any substrate mutation.
    this.setOblique({});
    const outcome = this.cascadeRoute();
    if (!outcome.committed) return { ...outcome, territory: null };
    const territory = this.renderTerritory();
    this.territoryLog.push({ sequence: this.sequence, territory });
    if (this.territoryLog.length > this.maxRouteLog) this.territoryLog.shift();
    this.record('TERRITORY-ACCORD', 'routed', { oblique: { ...this.oblique } });
    return { ...outcome, territory };
  }
  restoreTerritory() {
    const restored = this.restoreRoute();
    return { restored, territory: restored ? this.renderTerritory() : null };
  }
}
