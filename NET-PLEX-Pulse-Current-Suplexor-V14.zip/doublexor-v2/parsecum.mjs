import { MassMelodicSuppressor } from './mass-suppressor.mjs';

// Strasse grammar: NOTE pitch=60 beat=0 velocity=0.7 weights=1,0,0,0
// Strict parsing: no duplicate/unknown fields, no partial numeric tokens.
export function parseParsecum(source) {
  if (typeof source !== 'string' || source.length > 8192) throw new TypeError('Invalid Strasse source');
  const events=[];
  for (const [lineNo,raw] of source.split(/\r?\n/).entries()) {
    const line=raw.replace(/#.*/, '').trim();
    if(!line) continue;
    const parts=line.split(/\s+/);
    if(parts.shift().toUpperCase()!=='NOTE') throw new SyntaxError(`Line ${lineNo+1}: expected NOTE`);
    const fields={};
    for(const part of parts){
      const match=/^(pitch|beat|velocity|weights)=([^=\s]+)$/.exec(part);
      if(!match || Object.hasOwn(fields,match[1])) throw new SyntaxError(`Line ${lineNo+1}: invalid or repeated field`);
      fields[match[1]]=match[2];
    }
    if(Object.keys(fields).length!==4) throw new SyntaxError(`Line ${lineNo+1}: four fields required`);
    const number=s=>{if(!/^(?:\d+(?:\.\d+)?|\.\d+)$/.test(s)) throw new SyntaxError(`Line ${lineNo+1}: invalid number`);return Number(s);};
    const event={pitch:number(fields.pitch),beat:number(fields.beat),velocity:number(fields.velocity),weights:fields.weights.split(',').map(number)};
    if(!Number.isInteger(event.pitch)||event.pitch>127||event.beat<0||event.velocity>1||event.weights.length!==4||event.weights.some(x=>!Number.isFinite(x))) throw new RangeError(`Line ${lineNo+1}: invalid musical event`);
    events.push(event);
    if(events.length>256) throw new RangeError('Too many events');
  }
  return events;
}
export class MillenniumStrasseGovernor extends MassMelodicSuppressor {
  runStrasse(source, input=[0.3,0.7], options={}) {
    const events=parseParsecum(source); const results=[];
    for(const event of events){
      const result=this.cascadeSuppressed(event,input,options);
      results.push({event,result});
      if(!result.committed) break;
    }
    return {committed:results.length===events.length&&results.every(r=>r.result.committed),results};
  }
}
