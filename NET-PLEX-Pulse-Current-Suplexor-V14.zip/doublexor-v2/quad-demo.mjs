import { QuadTerritorySuplexor } from './quad-territory.mjs';
const net = new QuadTerritorySuplexor([['n1',0.25],['n2',0.75]], [{from:'n1',to:'n2',weight:0.2}], {maxMeanEntropy:1,maxNodeEntropy:1.01,maxStereoMagnitude:1});
net.setOblique({AB:0.2,BA:0.3,maxCross:0.5});
const result = net.cascadeQuad();
console.log(JSON.stringify({committed:result.committed,approvals:Object.fromEntries(Object.entries(result.decision.authorities).map(([k,v])=>[k,v.approved])),restored:net.restoreQuad().restored},null,2));
if (!result.committed) process.exitCode=1;
