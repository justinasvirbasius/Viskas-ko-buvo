import { ModalumSuplexor } from './modalum.mjs';

// V9: Melo = quadratic penalty on abrupt input changes.
// Meta-MOP = bounded candidate inspection and reclusive fallback.
export class MeloSubvisorySuplexor extends ModalumSuplexor {
  constructor(nodes, edges, options={}) {
    super(nodes, edges, options);
    this.meloWeight = options.meloWeight ?? 0.4;
    this.maxMeloJump = options.maxMeloJump ?? 1;
    this.previousManeuver = null;
    this.subvisoryHistory = [];
    this.subvisoryLog = [];
    if (![this.meloWeight,this.maxMeloJump].every(Number.isFinite) || this.meloWeight<0 || this.maxMeloJump<0)
      throw new RangeError('Invalid Melo configuration');
  }
  inspectSubvisory(input, options={}) {
    const disabled=options.disabledModes ?? [];
    if (!Array.isArray(disabled) || !disabled.every(x=>typeof x==='string'))
      return {approved:false,mode:'reclusive',reason:'invalid-disabled-modes',candidates:[]};
    const candidates=this.candidates(input).filter(c=>!disabled.includes(c.mode)).map(c=>{
      const review=this.inspectSOM(c.input);
      const jump=this.previousManeuver ? c.input.reduce((s,x,i)=>s+(x-this.previousManeuver[i])**2,0) : 0;
      const cost=review.energy+c.penalty+this.meloWeight*jump;
      return {mode:c.mode,input:c.input,cost,jump,approved:review.approved && Number.isFinite(cost) && jump<=this.maxMeloJump && cost<=this.maxManeuverCost};
    });
    const chosen=candidates.filter(c=>c.approved).sort((a,b)=>a.cost-b.cost)[0];
    return {approved:!!chosen,mode:chosen?.mode??'reclusive',input:chosen?.input??null,cost:chosen?.cost??null,
      candidates:candidates.map(({mode,cost,jump,approved})=>({mode,cost,jump,approved}))};
  }
  cascadeSubvisory(input,options={}) {
    const decision=this.inspectSubvisory(input,options);
    if (!decision.approved) {
      this.subvisoryLog.push({mode:'reclusive',committed:false});
      return {committed:false,mode:'reclusive',decision,reason:'meta-mop-reclusive'};
    }
    const result=this.cascadeQuadratic(decision.input);
    if (result.committed) {
      this.subvisoryHistory.push(this.previousManeuver ? [...this.previousManeuver] : null);
      this.previousManeuver=[...decision.input];
    }
    this.subvisoryLog.push({mode:decision.mode,committed:result.committed,cost:decision.cost});
    return {...result,mode:decision.mode,decision};
  }
  restoreSubvisory() {
    if (!this.subvisoryHistory.length) return {restored:false};
    const result=this.restoreQuadratic();
    if (result.restored) this.previousManeuver=this.subvisoryHistory.pop();
    return result;
  }
}
