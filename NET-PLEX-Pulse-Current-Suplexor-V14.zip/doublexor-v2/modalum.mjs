import { QuadraticSOMSuplexor } from './quadratic-som.mjs';

// V8: candidate substitution is evaluated before any V7 substrate commit.
export class ModalumSuplexor extends QuadraticSOMSuplexor {
  constructor(nodes, edges, options={}) {
    super(nodes, edges, options);
    this.substitutionPenalty = options.substitutionPenalty ?? 0.05;
    this.maxManeuverCost = options.maxManeuverCost ?? 4;
    this.obliqueShift = options.obliqueShift ?? 0.15;
    this.modalumLog = [];
    if (![this.substitutionPenalty,this.maxManeuverCost,this.obliqueShift].every(Number.isFinite) ||
        this.substitutionPenalty<0 || this.maxManeuverCost<0 || this.obliqueShift<0 || this.obliqueShift>1)
      throw new RangeError('Invalid Modalum configuration');
  }
  candidates(input) {
    if (!Array.isArray(input) || input.length!==2 || !input.every(x=>Number.isFinite(x)&&x>=0&&x<=1))
      return [];
    const a=[...input];
    const b=[(1-this.obliqueShift)*input[0]+this.obliqueShift*input[1],
             (1-this.obliqueShift)*input[1]+this.obliqueShift*input[0]];
    const c=[(input[0]+0.5)/2,(input[1]+0.5)/2];
    return [{mode:'primary',input:a,penalty:0},
            {mode:'oblique',input:b,penalty:this.substitutionPenalty},
            {mode:'substitutory',input:c,penalty:2*this.substitutionPenalty}];
  }
  inspectModalum(input, disabledModes=[]) {
    const available=this.candidates(input).filter(c=>!disabledModes.includes(c.mode));
    const inspected=available.map(c=>{
      const review=this.inspectSOM(c.input);
      const cost=review.energy+c.penalty;
      return {...c,review,cost,approved:review.approved&&Number.isFinite(cost)&&cost<=this.maxManeuverCost};
    });
    const chosen=inspected.filter(c=>c.approved).sort((a,b)=>a.cost-b.cost)[0];
    return {approved:!!chosen,mode:chosen?.mode??'reclusive',input:chosen?.input??null,
      cost:chosen?.cost??null,candidates:inspected.map(({mode,cost,approved})=>({mode,cost,approved}))};
  }
  cascadeModalum(input, options={}) {
    const decision=this.inspectModalum(input,options.disabledModes??[]);
    if (!decision.approved) {
      this.modalumLog.push({mode:'reclusive',committed:false});
      return {committed:false,mode:'reclusive',decision,reason:'no-valid-maneuver'};
    }
    const result=this.cascadeQuadratic(decision.input);
    this.modalumLog.push({mode:decision.mode,committed:result.committed,cost:decision.cost});
    return {...result,mode:decision.mode,decision};
  }
  restoreModalum() { return this.restoreQuadratic(); }
}
