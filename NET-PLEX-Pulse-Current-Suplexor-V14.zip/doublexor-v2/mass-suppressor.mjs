import { MelodyRhythmSuplexor } from './melody-rhythm.mjs';

// V11: pre-commit mass/entropy suppression above the V10 music governor.
export class MassMelodicSuppressor extends MelodyRhythmSuplexor {
  constructor(nodes,edges,options={}) {
    super(nodes,edges,options);
    this.massWeights=new Map(nodes.map(([id])=>[id,options.massWeights?.[id]??1]));
    this.maxMassEnergy=options.maxMassEnergy??Infinity;
    this.maxEventEnergy=options.maxEventEnergy??1;
    this.suppressFactor=options.suppressFactor??0.75;
    this.suppressionLog=[];
    if (![...this.massWeights.values(),this.maxMassEnergy,this.maxEventEnergy,this.suppressFactor].every(x=>typeof x==='number'&&!Number.isNaN(x)&&x>=0) || this.suppressFactor>1 || !Number.isFinite(this.maxEventEnergy)) throw new RangeError('Invalid mass governor');
  }
  massEnergy(state){return [...state].reduce((sum,[id,a])=>sum+(this.massWeights.get(id)??0)*a*a,0);}
  inspectMass(event){
    const proposal=this.propose();
    const energy=this.massEnergy(proposal);
    const eventEnergy=event.velocity*event.velocity;
    return {approved:energy<=this.maxMassEnergy&&eventEnergy<=this.maxEventEnergy,energy,eventEnergy};
  }
  cascadeSuppressed(event,input,options={}){
    const original=this.inspectMusic(event);
    if(!original.approved) return {committed:false,mode:'reclusive',reason:original.reason};
    let candidate={...event,weights:[...event.weights]};
    let mass=this.inspectMass(candidate),attempts=0;
    while(!mass.approved&&attempts<12&&mass.energy<=this.maxMassEnergy&&this.suppressFactor<1){
      candidate.velocity*=this.suppressFactor;
      mass=this.inspectMass(candidate);attempts++;
    }
    if(!mass.approved){this.suppressionLog.push({committed:false,reason:'mass-budget',mass});return {committed:false,mode:'reclusive',reason:'mass-budget',mass};}
    const result=this.cascadeMusic(candidate,input,options);
    if(result.committed)this.suppressionLog.push({committed:true,attempts,mass});
    return {...result,attempts,mass,suppressed:attempts>0};
  }
  restoreSuppressed(){return this.restoreMusic();}
}
