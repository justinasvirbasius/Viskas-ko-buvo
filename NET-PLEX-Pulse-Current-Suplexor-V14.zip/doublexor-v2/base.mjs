export class DoubleDoublexor {
  constructor(nodes, edges, {maxMeanEntropy=0.8,maxNodeEntropy=1,maxWeight=4}={}) {
    this.nodes=new Map(nodes.map(([id,p])=>[id,p]));
    this.edges=edges.map(e=>({...e}));
    this.limits={maxMeanEntropy,maxNodeEntropy,maxWeight};
    this.history=[]; this.omissions=[];
  }
  entropy(p){return p===0||p===1?0:-p*Math.log2(p)-(1-p)*Math.log2(1-p)}
  propose(){
    const next=new Map(this.nodes);
    for(const [id] of this.nodes){
      const input=this.edges.filter(e=>e.to===id).reduce((s,e)=>s+this.nodes.get(e.from)*e.weight,0);
      next.set(id,1/(1+Math.exp(-input)));
    }
    return next;
  }
  review(proposal){
    const values=[...proposal.values()];
    const finite=values.length===this.nodes.size&&[...proposal.keys()].every(id=>this.nodes.has(id))&&values.every(p=>Number.isFinite(p)&&p>=0&&p<=1);
    const weights=this.edges.every(e=>this.nodes.has(e.from)&&this.nodes.has(e.to)&&Number.isFinite(e.weight)&&Math.abs(e.weight)<=this.limits.maxWeight);
    const mean=finite?values.reduce((s,p)=>s+this.entropy(p),0)/values.length:Infinity;
    const checks={A1:finite&&mean<=this.limits.maxMeanEntropy,A2:finite&&weights&&values.every(p=>this.entropy(p)<=this.limits.maxNodeEntropy),B1:finite&&this.omissions.length<10000,B2:this.history.length<10000};
    return {checks,mean,approved:Object.values(checks).every(Boolean)};
  }
  cascade(){
    const proposal=this.propose(),decision=this.review(proposal);
    if(!decision.approved){this.omissions.push({reason:'governance',checks:decision.checks});return {committed:false,...decision};}
    this.history.push(new Map(this.nodes));this.nodes=proposal;
    return {committed:true,...decision};
  }
  restore(){if(!this.history.length)return false;this.nodes=this.history.pop();return true;}
}
