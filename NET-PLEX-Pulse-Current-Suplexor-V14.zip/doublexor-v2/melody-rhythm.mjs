import { MeloSubvisorySuplexor } from './subvisory.mjs';

// V10: governed event scheduling, not an audio synthesizer.
export class MelodyRhythmSuplexor extends MeloSubvisorySuplexor {
  constructor(nodes, edges, options={}) {
    super(nodes,edges,options);
    this.bpm=options.bpm??120;
    this.entropyBudget=options.entropyBudget??1;
    this.maxQuadraticMusicCost=options.maxQuadraticMusicCost??16;
    this.musicHistory=[];
    this.musicEvents=[];
    this.lastEvent=null;
    if (![this.bpm,this.entropyBudget,this.maxQuadraticMusicCost].every(Number.isFinite) || this.bpm<=0 || this.entropyBudget<0 || this.entropyBudget>1 || this.maxQuadraticMusicCost<0) throw new RangeError('Invalid music configuration');
  }
  // Shannon entropy normalized to [0,1], with silence treated as zero entropy.
  musicEntropy(weights) {
    const sum=weights.reduce((a,b)=>a+b,0);
    if(sum===0) return 0;
    const p=weights.filter(w=>w>0).map(w=>w/sum);
    return p.length<=1?0:-p.reduce((a,v)=>a+v*Math.log2(v),0)/Math.log2(weights.length);
  }
  inspectMusic(event) {
    if (!event || !Number.isInteger(event.pitch) || event.pitch<0 || event.pitch>127 || !Number.isFinite(event.beat) || event.beat<0 || !Number.isFinite(event.velocity) || event.velocity<0 || event.velocity>1 || !Array.isArray(event.weights) || event.weights.length!==4 || !event.weights.every(w=>Number.isFinite(w)&&w>=0)) return {approved:false,reason:'invalid-event'};
    const h=this.musicEntropy(event.weights);
    const prior=this.lastEvent;
    const cost=prior?((event.pitch-prior.pitch)/12)**2+(event.beat-prior.beat-1)**2+(event.velocity-prior.velocity)**2:0;
    return {approved:h<=this.entropyBudget && cost<=this.maxQuadraticMusicCost,entropy:h,cost,reason:h>this.entropyBudget?'entropy-budget':cost>this.maxQuadraticMusicCost?'quadratic-cost':'ok'};
  }
  // A giver submits an event; the givee validates it before committing the V9 cascade.
  cascadeMusic(event,input,options={}) {
    const verdict=this.inspectMusic(event);
    if(!verdict.approved) return {committed:false,mode:'reclusive',verdict};
    const result=this.cascadeSubvisory(input,options);
    if(!result.committed) return {...result,verdict};
    this.musicHistory.push(this.lastEvent?structuredClone(this.lastEvent):null);
    this.lastEvent=structuredClone(event);
    const scheduled={...structuredClone(event),seconds:event.beat*60/this.bpm,entropy:verdict.entropy};
    this.musicEvents.push(scheduled);
    return {...result,verdict,scheduled};
  }
  restoreMusic() {
    if(!this.musicHistory.length) return {restored:false};
    const restored=this.restoreSubvisory();
    if(restored.restored) {this.lastEvent=this.musicHistory.pop();this.musicEvents.pop();}
    return restored;
  }
}
