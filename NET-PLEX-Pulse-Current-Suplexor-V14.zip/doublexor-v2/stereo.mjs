import { RoutedSuplexor } from './routes.mjs';

// Two independent stereo pairs (A L/R, B L/R), with subgroup modulation.
export class DoubleStereoSuplexor extends RoutedSuplexor {
  constructor(nodes, edges, options = {}) {
    super(nodes, edges, options);
    this.stereo = {
      A: { left: 0, right: 0, gain: 1, pan: 0 },
      B: { left: 0, right: 0, gain: 1, pan: 0 },
    };
    this.modulation = { A: 0.5, B: 0.5, depth: 0.35, crossfeed: 0 };
    this.stereoLog = [];
  }
  setSubgroup(group, settings = {}) {
    if (!['A', 'B'].includes(group)) throw new RangeError('Unknown subgroup');
    const next = { ...this.stereo[group], ...settings };
    if (![next.gain, next.pan].every(Number.isFinite) || next.gain < 0 || next.gain > 2 || Math.abs(next.pan) > 1)
      throw new RangeError('gain must be 0..2 and pan -1..1');
    this.stereo[group] = next;
  }
  setModulation(settings = {}) {
    const next = { ...this.modulation, ...settings };
    if (!Object.values(next).every(Number.isFinite) || next.A < 0 || next.A > 1 || next.B < 0 || next.B > 1 || next.depth < 0 || next.depth > 1 || next.crossfeed < 0 || next.crossfeed > 1)
      throw new RangeError('Invalid modulation range');
    this.modulation = next;
  }
  // Compute stereo monitoring outputs only after a governed commit.
  // These are normalized control signals, not PCM audio samples.
  renderStereo() {
    const values = [...this.nodes.values()];
    const mid = Math.ceil(values.length / 2);
    const mean = xs => xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 0;
    const input = { A: mean(values.slice(0, mid)), B: mean(values.slice(mid)) };
    const result = {};
    for (const group of ['A', 'B']) {
      const cfg = this.stereo[group];
      const other = group === 'A' ? 'B' : 'A';
      const signal = (1 - this.modulation.crossfeed) * input[group] + this.modulation.crossfeed * input[other];
      const envelope = (1 - this.modulation.depth) + this.modulation.depth * this.modulation[group];
      const level = signal * envelope * cfg.gain;
      const left = level * Math.sqrt((1 - cfg.pan) / 2);
      const right = level * Math.sqrt((1 + cfg.pan) / 2);
      result[group] = { left, right, envelope, source: input[group] };
    }
    this.stereo.A = { ...this.stereo.A, ...result.A };
    this.stereo.B = { ...this.stereo.B, ...result.B };
    return structuredClone(result);
  }
  cascadeStereo() {
    const outcome = this.cascadeRoute();
    if (!outcome.committed) return { ...outcome, stereo: null };
    const stereo = this.renderStereo();
    this.stereoLog.push({ sequence: this.sequence, stereo });
    if (this.stereoLog.length > this.maxRouteLog) this.stereoLog.shift();
    this.record('STEREO-ACCORD', 'rendered', { groups: ['A', 'B'] });
    return { ...outcome, stereo };
  }
  restoreStereo() {
    const restored = this.restoreRoute();
    if (restored) this.renderStereo();
    return restored;
  }
}
