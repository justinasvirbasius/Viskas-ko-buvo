import { TerritorySuplexor } from './territory.mjs';

// Two independent suplexors: route validation and oblique modulation validation.
export class DoubleTerritorySuplexor extends TerritorySuplexor {
  constructor(nodes, edges, options = {}) {
    super(nodes, edges, options);
    this.doubleRouteLog = [];
    this.maxDoubleLog = options.maxDoubleLog ?? 1000;
    this.maxStereoMagnitude = options.maxStereoMagnitude ?? 1;
    if (!Number.isFinite(this.maxStereoMagnitude) || this.maxStereoMagnitude <= 0) throw new RangeError('Invalid stereo magnitude limit');
  }
  inspectTerritory() {
    this.setOblique({});
    const render = this.renderTerritory();
    const channels = ['A', 'B'].flatMap(g => ['left', 'right'].map(c => render.channels[g][c]));
    const stereo = channels.every(v => Number.isFinite(v) && Math.abs(v) <= this.maxStereoMagnitude);
    const routing = ['AB', 'BA'].every(k => this.oblique[k] >= 0 && this.oblique[k] <= this.oblique.maxCross);
    const territories = ['A', 'B'].every(g => typeof this.territories[g] === 'string' && /^[a-z0-9_-]{1,40}$/i.test(this.territories[g]));
    return { approved: stereo && routing && territories, checks: { stereo, routing, territories }, render };
  }
  cascadeDouble() {
    // Review both authorities BEFORE the substrate changes.
    const proposal = this.propose();
    const primary = this.inspect(proposal);
    const secondary = this.inspectTerritory();
    const approved = primary.approved && secondary.approved;
    const decision = { approved, primary: primary.results, secondary: secondary.checks };
    this.doubleRouteLog.push(decision);
    if (this.doubleRouteLog.length > this.maxDoubleLog) this.doubleRouteLog.shift();
    if (!approved) {
      this.record('DOUBLE-SUPLEXOR', 'rejected', { primaryApproved: primary.approved, secondaryApproved: secondary.approved });
      return { committed: false, decision, territory: null };
    }
    this.history.push(new Map(this.nodes));
    this.nodes = new Map(proposal);
    const territory = this.renderTerritory();
    this.record('DOUBLE-SUPLEXOR', 'committed', { mean: primary.mean });
    return { committed: true, decision, state: Object.fromEntries(this.nodes), territory };
  }
  restoreDouble() { return this.restoreTerritory(); }
}
