import { MillenniumStrasseGovernor, parseParsecum } from './parsecum.mjs';

// V13: two sequential supervisory gates: musical conditioning, then inherited mass governance.
export class DoubleSupMusicalConditioner extends MillenniumStrasseGovernor {
  constructor(nodes,edges,options={}) {
    super(nodes,edges,options);
    this.maxInterval=options.maxInterval??7;
    this.maxBeatGap=options.maxBeatGap??4;
    this.conditionHistory=[];
    if(!Number.isFinite(this.maxInterval)||this.maxInterval<0||!Number.isFinite(this.maxBeatGap)||this.maxBeatGap<0) throw new RangeError('Invalid conditioner bounds');
  }
  condition(event,mode='profuse') {
    if(!['profuse','self-recluse','obtuse'].includes(mode)) throw new RangeError('Unknown conditioner mode');
    const valid=this.inspectMusic(event);
    if(!valid.approved) return {approved:false,reason:valid.reason};
    const previous=this.lastEvent;
    const gap=previous?event.beat-previous.beat:0;
    if(gap<0 || gap>this.maxBeatGap) return {approved:false,reason:'rhythm-gap'};
    const result={...event,weights:[...event.weights]};
    if(previous && Math.abs(result.pitch-previous.pitch)>this.maxInterval) {
      if(mode==='self-recluse') return {approved:false,reason:'reclusive-interval'};
      const sign=Math.sign(result.pitch-previous.pitch);
      result.pitch=previous.pitch+sign*this.maxInterval;
    }
    if(mode==='profuse') result.velocity=Math.min(1,result.velocity*1.1);
    if(mode==='self-recluse') result.velocity*=0.5;
    if(mode==='obtuse') result.velocity*=0.85;
    return {approved:true,event:result,mode};
  }
  cascadeConditioned(event,input=[0.3,0.7],mode='profuse',options={}) {
    const conditioned=this.condition(event,mode);
    if(!conditioned.approved) return {committed:false,mode:'reclusive',reason:conditioned.reason};
    const result=this.cascadeSuppressed(conditioned.event,input,options);
    if(result.committed) this.conditionHistory.push({mode,source:structuredClone(event),scheduled:structuredClone(result.scheduled)});
    return {...result,conditioner:mode};
  }
  runConditionedStrasse(source,input=[0.3,0.7],mode='profuse',options={}) {
    const events=parseParsecum(source), results=[];
    for(const event of events){const result=this.cascadeConditioned(event,input,mode,options);results.push(result);if(!result.committed)break;}
    return {committed:results.length===events.length&&results.every(x=>x.committed),results};
  }
  restoreConditioned(){const r=this.restoreSuppressed();if(r.restored)this.conditionHistory.pop();return r;}
}
