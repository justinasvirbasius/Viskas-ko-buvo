import { DoubleTerritorySuplexor } from './double-territory.mjs';

// V6: two additional, independently reported authorities above V5.
export class QuadTerritorySuplexor extends DoubleTerritorySuplexor {
  constructor(nodes, edges, options = {}) {
    super(nodes, edges, options);
    this.matrix = options.matrix ?? [[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]];
    this.maxRowSum = options.maxRowSum ?? 1;
    this.quadLog = [];
    this.maxQuadLog = options.maxQuadLog ?? 1000;
  }
  inspectMatrix() {
    const valid = Array.isArray(this.matrix) && this.matrix.length === 4 &&
      this.matrix.every(row => Array.isArray(row) && row.length === 4 &&
        row.every(v => Number.isFinite(v) && v >= 0) &&
        row.reduce((a,b) => a+b,0) <= this.maxRowSum + 1e-12);
    return { approved: valid, checks: { matrix: valid } };
  }
  routeChannels(render) {
    const c = render.channels;
    const input = [c.A.left,c.A.right,c.B.left,c.B.right];
    const out = this.matrix.map(row => row.reduce((sum,w,i) => sum+w*input[i],0));
    return { ...render, channels: { A: {left:out[0],right:out[1]}, B: {left:out[2],right:out[3]} } };
  }
  cascadeQuad() {
    const proposal = this.propose();
    const first = this.inspect(proposal);
    const second = this.inspectTerritory();
    const third = this.inspectMatrix();
    const fourth = { approved: false, checks: { output: false } };
    let output = null;
    if (second.approved && third.approved) {
      output = this.routeChannels(second.render);
      const vals = [output.channels.A.left,output.channels.A.right,output.channels.B.left,output.channels.B.right];
      fourth.checks.output = vals.every(v => Number.isFinite(v) && Math.abs(v) <= this.maxStereoMagnitude);
      fourth.approved = fourth.checks.output;
    }
    const approved = first.approved && second.approved && third.approved && fourth.approved;
    const decision = { approved, authorities: {
      substrate: { approved:first.approved, results:first.results },
      territory: { approved:second.approved, checks:second.checks },
      matrix: third, output: fourth
    }};
    this.quadLog.push(decision);
    if (this.quadLog.length > this.maxQuadLog) this.quadLog.shift();
    if (!approved) {
      this.record('QUAD-SUPLEXOR','rejected', { authorities: Object.fromEntries(Object.entries(decision.authorities).map(([k,v])=>[k,v.approved])) });
      return { committed:false, decision, territory:null };
    }
    this.history.push(new Map(this.nodes));
    this.nodes = new Map(proposal);
    const territory = this.routeChannels(this.renderTerritory());
    this.record('QUAD-SUPLEXOR','committed', { mean:first.mean });
    return { committed:true, decision, state:Object.fromEntries(this.nodes), territory };
  }
  restoreQuad() { return this.restoreTerritory(); }
}
