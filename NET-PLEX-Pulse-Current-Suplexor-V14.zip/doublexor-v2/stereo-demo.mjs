import { DoubleStereoSuplexor } from './stereo.mjs';
const nodes = [['n1', 0.1], ['n2', 0.2], ['n3', 0.9], ['n4', 0.8]];
const edges = [
  { from: 'n1', to: 'n1', weight: 4 }, { from: 'n2', to: 'n2', weight: 4 },
  { from: 'n3', to: 'n3', weight: 4 }, { from: 'n4', to: 'n4', weight: 4 },
];
const net = new DoubleStereoSuplexor(nodes, edges, { maxMeanEntropy: 1 });
net.setSubgroup('A', { gain: 0.8, pan: -0.4 });
net.setSubgroup('B', { gain: 0.7, pan: 0.4 });
net.setModulation({ A: 0.75, B: 0.6, depth: 0.4, crossfeed: 0.15 });
const result = net.cascadeStereo();
if (!result.committed || !result.stereo || !['A','B'].every(g => ['left','right'].every(c => Number.isFinite(result.stereo[g][c])))) throw new Error('Stereo cascade failed');
console.log(JSON.stringify({ committed: result.committed, stereo: result.stereo, restored: net.restoreStereo() }, null, 2));
