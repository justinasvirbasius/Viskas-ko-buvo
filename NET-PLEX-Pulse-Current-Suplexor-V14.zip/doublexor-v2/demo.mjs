import { RoutedSuplexor } from './routes.mjs';
const net = new RoutedSuplexor([['n1', 0.12], ['n2', 0.32], ['n3', 0.56]], [
  { from: 'n1', to: 'n2', weight: 0.4 },
  { from: 'n2', to: 'n3', weight: 0.7 },
], { maxMeanEntropy: 1 });
console.log(JSON.stringify(net.runRoutes(2), null, 2));
console.log('restored:', net.restoreRoute());
console.log('route events:', net.routeLog.length);
