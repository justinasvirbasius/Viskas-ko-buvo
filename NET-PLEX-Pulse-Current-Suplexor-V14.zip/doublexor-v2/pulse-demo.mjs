import assert from 'node:assert/strict';
import {PulseCurrentSuplexor} from './pulse-currents.mjs';
const net=new PulseCurrentSuplexor([['n1',0.25],['n2',0.75]],[{from:'n1',to:'n2',weight:0.2}],{maxMeanEntropy:1,maxNodeEntropy:1.01,maxStereoMagnitude:1,bpm:120,maxMassEnergy:1,maxEventEnergy:0.3,suppressFactor:0.5,currentLimit:0.8});
net.setOblique({AB:0.2,BA:0.3,maxCross:0.5});
const event={pitch:60,beat:0,velocity:0.9,weights:[1,0,0,0]};
const r=net.cascadePulse(event);assert.equal(r.committed,true);assert.equal(r.current,0.5);assert.equal(r.substituted,true);
assert.equal(net.cascadePulse({...event,beat:0.124}).committed,false);
assert.equal(net.restorePulse().restored,true);assert.equal(net.lastEvent,null);
console.log('PASS V14: substitute current, pulse gate, restoration');
