import { QuadTerritorySuplexor } from './quad-territory.mjs';

// V7: quadratic SOM = squared Euclidean matching plus squared-distance neighborhood.
// SOM weights and the inherited substrate are committed together only after review.
export class QuadraticSOMSuplexor extends QuadTerritorySuplexor {
  constructor(nodes, edges, options = {}) {
    super(nodes, edges, options);
    this.som = (options.somWeights ?? [[0.2,0.8],[0.8,0.2],[0.5,0.5],[0.1,0.1]]).map(v=>[...v]);
    this.grid = [[0,0],[1,0],[0,1],[1,1]];
    this.learningRate = options.learningRate ?? 0.15;
    this.sigma = options.sigma ?? 1;
    this.maxQuadraticEnergy = options.maxQuadraticEnergy ?? 4;
    this.somHistory = [];
  }
  inspectSOM(input) {
    const valid = Array.isArray(input) && input.length === 2 && input.every(x=>Number.isFinite(x)&&x>=0&&x<=1) &&
      this.som.length===4 && this.som.every(w=>w.length===2&&w.every(x=>Number.isFinite(x)&&x>=0&&x<=1)) &&
      Number.isFinite(this.learningRate)&&this.learningRate>=0&&this.learningRate<=1 &&
      Number.isFinite(this.sigma)&&this.sigma>0 && Number.isFinite(this.maxQuadraticEnergy)&&this.maxQuadraticEnergy>=0;
    if (!valid) return {approved:false, reason:'invalid-som-configuration'};
    const distances = this.som.map(w=>w.reduce((s,v,i)=>s+(input[i]-v)**2,0));
    const winner = distances.indexOf(Math.min(...distances));
    const proposed = this.som.map((w,k)=> {
      const d2 = this.grid[k].reduce((s,v,i)=>s+(v-this.grid[winner][i])**2,0);
      const neighborhood = Math.exp(-d2/(2*this.sigma**2));
      return w.map((v,i)=>v+this.learningRate*neighborhood*(input[i]-v));
    });
    const energy = proposed.reduce((s,w)=>s+w.reduce((t,v,i)=>t+(input[i]-v)**2,0),0);
    return {approved:Number.isFinite(energy)&&energy<=this.maxQuadraticEnergy, winner, distances, energy, proposed};
  }
  cascadeQuadratic(input) {
    const som = this.inspectSOM(input);
    if (!som.approved) return {committed:false,reason:'som-governor',som:{approved:false,energy:som.energy}};
    // The inherited quad cascade validates all four route authorities first.
    const result = this.cascadeQuad();
    if (!result.committed) return {...result,som:{approved:true,energy:som.energy}};
    this.somHistory.push(this.som.map(w=>[...w]));
    this.som = som.proposed;
    this.record('QUADRATIC-SOM','committed',{winner:som.winner,energy:som.energy});
    return {...result,som:{approved:true,winner:som.winner,energy:som.energy,weights:this.som.map(w=>[...w])}};
  }
  restoreQuadratic() {
    if (!this.somHistory.length || !this.history.length) return {restored:false};
    const restored = this.restoreQuad();
    if (restored.restored) this.som=this.somHistory.pop();
    return restored;
  }
}
