import { DoubleSupMusicalConditioner } from './double-sup-conditioner.mjs';

// V14: deterministic pulse gate and bounded substitution-current selection.
export class PulseCurrentSuplexor extends DoubleSupMusicalConditioner {
  constructor(nodes, edges, options={}) {
    super(nodes,edges,options);
    this.pulseSubdivision=options.pulseSubdivision??4;
    this.pulseTolerance=options.pulseTolerance??0.05;
    this.currentLimit=options.currentLimit??1;
    this.currentHistory=[];
    if(!Number.isInteger(this.pulseSubdivision)||this.pulseSubdivision<1||!Number.isFinite(this.pulseTolerance)||this.pulseTolerance<0||!Number.isFinite(this.currentLimit)||this.currentLimit<0||this.currentLimit>1)throw new RangeError('Invalid pulse/current configuration');
  }
  pulseAt(beat){
    if(!Number.isFinite(beat)||beat<0)throw new RangeError('Invalid beat');
    const quantized=Math.round(beat*this.pulseSubdivision)/this.pulseSubdivision;
    return {beat:quantized,seconds:quantized*60/this.bpm,withinGate:Math.abs(beat-quantized)<=this.pulseTolerance};
  }
  cascadePulse(event,input=[0.3,0.7],mode='profuse',currents=[1,0.75,0.5,0.25]){
    const p=this.pulseAt(event?.beat);
    if(!p.withinGate)return {committed:false,reason:'pulse-gate',mode:'reclusive'};
    if(!Array.isArray(currents)||!currents.length||!currents.every(c=>Number.isFinite(c)&&c>=0&&c<=1))throw new RangeError('Invalid currents');
    const source=this.condition({...event,beat:p.beat},mode);
    if(!source.approved)return {committed:false,reason:source.reason,mode:'reclusive'};
    for(const current of currents){
      if(current>this.currentLimit)continue;
      const candidate={...source.event,velocity:source.event.velocity*current,weights:[...source.event.weights]};
      const verdict=this.inspectMusic(candidate);
      if(!verdict.approved)continue;
      const mass=this.inspectMass(candidate);
      if(!mass.approved)continue;
      const result=this.cascadeSuppressed(candidate,input);
      if(result.committed){
        this.conditionHistory.push({mode,source:structuredClone(event),scheduled:structuredClone(result.scheduled)});
        this.currentHistory.push({current,pulse:p,mode});
        return {...result,current,pulse:p,conditioner:mode,substituted:current!==currents[0]};
      }
      // An inherited cascade rejection is authoritative; don't retry after possible side effects.
      return {...result,current,pulse:p};
    }
    return {committed:false,mode:'reclusive',reason:'no-valid-current',pulse:p};
  }
  restorePulse(){const r=this.restoreConditioned();if(r.restored)this.currentHistory.pop();return r;}
}
