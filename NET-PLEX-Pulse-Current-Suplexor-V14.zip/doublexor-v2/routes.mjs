import { DoubleDoublexor } from './base.mjs';

export const ROUTES = Object.freeze({
  A1: 'entropy', A2: 'substrate', B1: 'omission', B2: 'recovery',
});

export class RoutedSuplexor extends DoubleDoublexor {
  constructor(nodes, edges, options = {}) {
    super(nodes, edges, options);
    this.routeLog = [];
    this.sequence = 0;
    this.maxRouteLog = options.maxRouteLog ?? 1000;
    this.maxHistory = options.maxHistory ?? 1000;
    this.maxOmissions = options.maxOmissions ?? 1000;
  }
  record(route, status, detail = {}) {
    const entry = { sequence: ++this.sequence, route, status, ...detail };
    this.routeLog.push(entry);
    if (this.routeLog.length > this.maxRouteLog) this.routeLog.shift();
    return entry;
  }
  inspect(proposal) {
    const complete = proposal instanceof Map && proposal.size === this.nodes.size &&
      [...proposal.keys()].every(id => this.nodes.has(id));
    const values = complete ? [...proposal.values()] : [];
    const numeric = complete && values.length > 0 && values.every(p => Number.isFinite(p) && p >= 0 && p <= 1);
    const edgeValid = this.edges.every(e => this.nodes.has(e.from) && this.nodes.has(e.to) &&
      Number.isFinite(e.weight) && Math.abs(e.weight) <= this.limits.maxWeight);
    const mean = numeric ? values.reduce((sum, p) => sum + this.entropy(p), 0) / values.length : Infinity;
    const results = {
      A1: { approved: numeric && mean <= this.limits.maxMeanEntropy, metric: mean, decree: 'mean-entropy' },
      A2: { approved: numeric && edgeValid && values.every(p => this.entropy(p) <= this.limits.maxNodeEntropy), decree: 'node-edge-integrity' },
      B1: { approved: this.omissions.length < this.maxOmissions, decree: 'omission-capacity' },
      B2: { approved: this.history.length < this.maxHistory, decree: 'recovery-capacity' },
    };
    for (const [route, decision] of Object.entries(results)) {
      this.record(route, decision.approved ? 'approved' : 'rejected', { decree: decision.decree });
    }
    return { results, mean, approved: Object.values(results).every(x => x.approved) };
  }
  cascadeRoute() {
    // Proposals are calculated from the same immutable pre-commit state.
    const proposal = this.propose();
    const review = this.inspect(proposal);
    if (!review.approved) {
      const rejection = { reason: 'route-accord', failed: Object.entries(review.results).filter(([, d]) => !d.approved).map(([r]) => r) };
      if (this.omissions.length < this.maxOmissions) this.omissions.push(rejection);
      this.record('ACCORD', 'omitted', rejection);
      return { committed: false, ...review, rejection };
    }
    this.history.push(new Map(this.nodes));
    this.nodes = new Map(proposal);
    this.record('ACCORD', 'committed', { mean: review.mean });
    return { committed: true, ...review, state: Object.fromEntries(this.nodes) };
  }
  restoreRoute() {
    if (!this.history.length) {
      this.record('B2', 'restore-unavailable');
      return false;
    }
    this.nodes = this.history.pop();
    this.record('B2', 'restored');
    return true;
  }
  runRoutes(passes = 1) {
    if (!Number.isSafeInteger(passes) || passes < 1 || passes > 1000) throw new RangeError('passes must be 1..1000');
    const outcomes = [];
    for (let i = 0; i < passes; i++) {
      const outcome = this.cascadeRoute();
      outcomes.push(outcome);
      if (!outcome.committed) break;
    }
    return outcomes;
  }
}
