# NET-PLEX Double Doublexor — Routed Suplexor V2

ES module extension of the original DoubleDoublexor class.

- A1: whole-network mean Shannon entropy threshold
- A2: per-node entropy and weighted edge integrity
- B1: bounded omission record capacity
- B2: bounded recovery snapshot capacity
- ACCORD: all four must approve before atomic state replacement

## Run

`node demo.mjs`

Import `RoutedSuplexor` from `routes.mjs`, call `cascadeRoute()`, `runRoutes(n)`, or `restoreRoute()`.

This is a deterministic network simulation, not a trained neural model. Route events are in-memory and are not durable storage. The original `DoubleDoublexor` is preserved in `base.mjs`.

## V3 Double Stereo subgroup modulation

`stereo.mjs` adds two stereo subgroups (A and B), each with left and right control outputs. `setSubgroup('A', {gain, pan})` configures independent subgroup levels; `setModulation({A,B,depth,crossfeed})` controls envelopes and group-to-group blending. `cascadeStereo()` invokes the existing A1/A2/B1/B2 route accord first and emits stereo control signals only after a successful commit. `restoreStereo()` rolls back the network and refreshes the stereo output. The four channels are **control/monitor signals**, not audio PCM; feed them to an audio renderer if sound is desired.

Run: `node stereo-demo.mjs` (Node.js 18+).

## V4 Territory / Oblique Substrate
`territory.mjs` extends the V3 stereo control module with named subgroup territories, bounded asymmetric oblique routes A→B and B→A, pre-commit governance, independent simultaneous mixing and restoration. The original substrate nodes remain governed by the four Doublexor authorities. This is a control-signal simulation, not audio playback. Run `node territory-demo.mjs` from this folder.

## V5: Double Territory Suplexor

`double-territory.mjs` introduces a second supervisory review before the commit. The primary suplexor checks entropy, nodes, edges, omission and history capacities; the secondary suplexor checks territory names, oblique routing bounds, and the four stereo-control outputs. Both must approve. Run `node double-demo.mjs` to test. This is control-signal modulation, not PCM audio. Territory rendering after commit is informational; the precommit stereo review uses the current state.

## V6 Quad Territory Suplexor
`quad-territory.mjs` adds two authorities above V5: a four-channel routing matrix and a bounded output validator. Use `cascadeQuad()` and `restoreQuad()`. The four channels are normalized stereo **control signals**, not PCM audio. Run `node quad-demo.mjs` to test. A matrix row may contain nonnegative weights with sum at most `maxRowSum` (default 1). The four authorities must approve before the node state commits. Matrix settings are configuration, not included in state rollback.

## V7 Quadratic SOM Suplexor
`quadratic-som.mjs` adds a four-cell self-organizing map (SOM) to V6.
Quadratic means squared Euclidean distance for best-matching-unit selection and squared grid distance in a Gaussian neighborhood. The original V6 substrate, routes, territory, and stereo modules remain in place. SOM training is staged before the V6 quad accord and committed only if all checks pass. `restoreQuadratic()` restores both SOM weights and the network substrate. The two-feature input is a normalized modulation vector, not PCM audio.

Run: `node quadratic-demo.mjs`.

## V8 Modalum Substitutory
`modalum.mjs` adds three quadratic SOM maneuver candidates: primary, oblique (cross-axis blend), and substitutory (center-directed blend). Each candidate is inspected without committing. The lowest accepted quadratic energy plus substitution penalty is selected. If none passes, reclusive mode leaves the substrate unchanged. `cascadeModalum(input, {disabledModes: []})` commits through V7 governance, and `restoreModalum()` restores the paired substrate/SOM snapshot. Run `node modalum-demo.mjs`.

## V9 Melo Quadratic Subvisory
`subvisory.mjs` adds `MeloSubvisorySuplexor` to V8. `cascadeSubvisory(input,{disabledModes})` selects the lowest-cost validated candidate using SOM energy + substitution penalty + `meloWeight * squared_jump_from_previous_committed_maneuver`. `maxMeloJump` bounds sudden changes. No valid candidate means reclusive (no commit). `restoreSubvisory()` restores both the inherited network/SOM state and previous maneuver memory. Run `node subvisory-demo.mjs`.

## V10 — Melody / Cascading Rhythm / Entropy Giver-Givee
`melody-rhythm.mjs` exports `MelodyRhythmSuplexor`. A giver proposes `{pitch, beat, velocity, weights}`; a givee validates normalized Shannon entropy and a quadratic pitch/timing/velocity change cost before passing to V9 `cascadeSubvisory`. Approved events have a beat-to-seconds timestamp. `restoreMusic` restores the committed substrate, SOM, maneuver memory and event history together. Run `node music-demo.mjs`. This is event/control scheduling, not PCM audio playback.

## V11 — Mass Melodic Suppressor

`mass-suppressor.mjs` adds a pre-commit mass-energy governor. Mass is an abstract nonnegative weight assigned to each network node. `cascadeSuppressed(event,input)` first checks V10 musical validity, predicts substrate energy `sum(m_i * activation_i^2)`, and attenuates event velocity when only the event-energy budget is exceeded. If substrate energy is over budget, the event is rejected without mutation. `restoreSuppressed()` restores the committed V10 state. Run `node mass-demo.mjs`.

Note: suppression here is a control-event gate, not audio signal processing. A preexisting V10 musical entropy violation is rejected rather than automatically reweighted.

## V12 Millennium Strasse / Parsecum

`parsecum.mjs` provides a strict line-oriented Strasse musical input parser and `MillenniumStrasseGovernor`, retaining V11 mass suppression and the underlying NET-PLEX governors.

Syntax: `NOTE pitch=60 beat=0 velocity=0.9 weights=1,0,0,0`

One NOTE per line; `#` introduces comments. Each note is validated and committed independently. Processing stops on the first rejected event; earlier accepted events remain committed and can be restored individually using `restoreSuppressed()`. This is a control-event sequencer, not an audible synthesizer.

Run `node doublexor-v2/parsecum-demo.mjs`.

## V13 Double Sup Musical Conditioner

Use `double-sup-conditioner.mjs` for profuse, self-recluse, and obtuse modes. Run `node conditioner-demo.mjs`. Outputs are MIDI-like control events, not synthesized sound.

## V14 Pulse Decree / Current Substitutory
`pulse-currents.mjs` exports `PulseCurrentSuplexor`. `cascadePulse(event,input,mode,currents)` quantizes beats to a pulse subdivision, rejects off-grid events, and tries descending current gains subject to a global current limit, musical validity, and mass budget. Only the first validated candidate enters the inherited cascade. `restorePulse()` restores its associated histories. Run `node pulse-demo.mjs`. This module emits scheduled control events, not audible audio.
