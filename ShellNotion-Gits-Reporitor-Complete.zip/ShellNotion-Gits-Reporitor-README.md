# ShellNotion + Gits + Reporitor

This package contains three coordinated PowerShell components with separate responsibilities and evidence ledgers:

- **ShellNotion** governs PowerShell inspection, execution, streams, Windows windows, Forward Pass temporal records, and Record-Through verification.
- **Gits** governs local Git repository reads and explicit local mutations.
- **Reporitor** manages selected GitHub operations through `gh` and runs a finite repository reporting bot.

## Start

Extract the ZIP and run from the extracted directory:

```powershell
Import-Module .\ShellNotion\ShellNotion.psd1 -Force
Start-ShellNotion

Import-Module .\Gits\Gits.psd1 -Force
Start-Gits -RepositoryPath C:\path\to\repository

Import-Module .\Reporitor\Reporitor.psd1 -Force
Start-Reporitor -Repository owner/repository
```

Use `Initialize-GitsRepository -Path C:\path\to\new-repository -InitialBranch main -Commit` for a new local repository. Use `New-RPRepository -Name repository-name -Visibility private -Commit` for a new GitHub repository. Neither command performs the other operation automatically.

Read each component's `README.md` for its commands and policy boundaries. ShellNotion exposes Gits and Reporitor as readiness categories while both modules remain separately importable, configured, and verifiable.
