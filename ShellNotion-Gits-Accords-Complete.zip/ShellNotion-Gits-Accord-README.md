# ShellNotion + Forward Pass + Gits

This package contains two coordinated but separate PowerShell accords:

- **ShellNotion** governs shell execution, stream routing, diagnostics, and Windows windows. Its ForwardPass submodule integrates the supplied temporal and annotation model.
- **Gits** governs local Git repositories with explicit-consent local mutations and a separate chained evidence ledger.

## Install and start

Extract the ZIP, then from the extracted directory:

```powershell
Import-Module .\ShellNotion\ShellNotion.psd1 -Force
Start-ShellNotion
Import-Module .\Gits\Gits.psd1 -Force
Start-Gits -RepositoryPath C:\path\to\existing-repository
```

To create a fresh local repository, use `Initialize-GitsRepository -Path C:\path\to\new-repository -InitialBranch main -Commit`, then pass that path to `Start-Gits`.

Read `ShellNotion/README.md` and `Gits/README.md` for command details and policy boundaries. The bundled `ShellNotion/ForwardPass/PowerShell-Forward-Pass.ps1` is the provided source integrated behind `Invoke-SNForwardPass` and `Test-SNForwardPass`.

ShellNotion's Gits category is a discovery link only: the Gits module remains separately importable, separately configured, and separately verifiable. It can be installed or updated without altering ShellNotion's Record-Through ledger.
