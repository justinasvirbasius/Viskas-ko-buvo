@{
    RootModule = 'ShellNotion.psm1'
    ModuleVersion = '1.0.0'
    GUID = '7f7ab6b9-d37d-4d8f-bfa1-2c15e18896a6'
    Author = 'ShellNotion Accord'
    CompanyName = 'Independent'
    Copyright = 'Copyright (c) 2026. All rights reserved.'
    Description = 'Governable PowerShell categories for Shadow, Current, Light, Echoscopy, Currents, Window, Forward Pass, and Record-Through accord evidence.'
    PowerShellVersion = '5.1'
    FunctionsToExport = @(
        'Get-SNCategory',
        'Get-SNPolicy',
        'Get-SNCurrent',
        'Get-SNLight',
        'Get-SNCurrents',
        'Test-SNShadow',
        'Invoke-SNEchoscopy',
        'Get-SNWindow',
        'Set-SNWindowState',
        'Move-SNWindow',
        'Invoke-SNForwardPass',
        'Test-SNForwardPass',
        'Write-SNNotation',
        'Test-SNAccord',
        'Start-ShellNotion'
    )
    CmdletsToExport = @()
    VariablesToExport = @()
    AliasesToExport = @()
    PrivateData = @{
        PSData = @{
            Tags = @('PowerShell', 'Governance', 'Audit', 'Windows', 'RecordThrough')
            ReleaseNotes = 'Initial governed ShellNotion categories and Record-Through integration.'
        }
    }
}
