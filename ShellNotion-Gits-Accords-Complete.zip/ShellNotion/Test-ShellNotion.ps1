#requires -Version 5.1
[CmdletBinding()]
param([switch]$CommitProbe)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$manifest = Join-Path $PSScriptRoot 'ShellNotion.psd1'
Import-Module $manifest -Force -ErrorAction Stop

$required = @(
    'Get-SNCategory', 'Get-SNCurrent', 'Get-SNLight', 'Get-SNCurrents',
    'Test-SNShadow', 'Invoke-SNEchoscopy', 'Invoke-SNForwardPass',
    'Test-SNForwardPass', 'Write-SNNotation', 'Test-SNAccord'
)
$missing = @($required | Where-Object { -not (Get-Command $_ -ErrorAction SilentlyContinue) })
$shadow = Test-SNShadow { Get-Process }
$currents = @(Get-SNCurrents)
$light = Get-SNLight
$gitsAvailable = Test-Path -LiteralPath (Join-Path $PSScriptRoot '..\Gits\Gits.psd1')

$probe = $null
if ($CommitProbe) {
    $probe = Invoke-SNEchoscopy -Name 'self-test' -ScriptBlock {
        [pscustomobject]@{ Probe = 'success'; TimestampUtc = [DateTimeOffset]::UtcNow.ToString('o') }
        Write-Warning 'self-test warning current'
    } -Commit
}

[pscustomobject]@{
    Schema = 'shell-notion-self-test/v1'
    Passed = ($missing.Count -eq 0 -and $shadow.Risk -eq 'Standard' -and $currents.Count -eq 7 -and $gitsAvailable)
    MissingCommands = $missing
    ShadowRisk = $shadow.Risk
    CurrentCount = $currents.Count
    LightReady = $light.Ready
    GitsAvailable = $gitsAvailable
    CommitProbe = $probe
}
