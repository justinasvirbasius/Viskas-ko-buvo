# Gits Accord

Gits is a standalone PowerShell module for governing local Git repositories. It records a separate SHA-256-linked accord ledger outside the working tree by default, so audit notes do not dirty the repository. It never embeds remote URLs in the ledger and does not implement fetch, pull, push, reset, clean, or history rewrite.

## Import and inspect

```powershell
Import-Module .\Gits.psd1 -Force
Get-GitsRepository -Path C:\path\to\existing-repository
Test-GitsAccord -RepositoryPath C:\path\to\existing-repository
Start-Gits -RepositoryPath C:\path\to\existing-repository
```

## Initialize a local repository

```powershell
Initialize-GitsRepository -Path .\new-project -InitialBranch main
Initialize-GitsRepository -Path .\new-project -InitialBranch main -Commit
```

Without `-Commit`, this is a preview. Initialization creates a local `.git` directory only; it does not add files, create a commit, set identity, configure a remote, or contact a network.

## Record a checkpoint

```powershell
Write-GitsAccord -RepositoryPath . -Operation 'Review checkpoint'
Write-GitsAccord -RepositoryPath . -Operation 'Review checkpoint' `
  -Evidence @{ reviewer = 'local'; scope = 'working-tree' } -Commit
Test-GitsAccord -RepositoryPath .
```

## Read-only repository views

```powershell
Invoke-GitsRead -Operation Status
Invoke-GitsRead -Operation Log -Limit 20
Invoke-GitsRead -Operation Diff
```

Reads return their output and an accord preview; pass `-Commit` to persist the read receipt.

## Governed local changes

```powershell
Invoke-GitsMutation -Operation Add -Pathspec README.md
Invoke-GitsMutation -Operation Add -Pathspec README.md -Commit
Invoke-GitsMutation -Operation Commit -Message 'Document repository' -Commit
Invoke-GitsMutation -Operation CreateBranch -Name feature/notes -Commit
```

Every mutation previews without `-Commit`, then goes through PowerShell `ShouldProcess` (`-WhatIf`/`-Confirm`). Staging requires explicit paths. Branch/tag names are validated. There is no force-switch, cleanup command, or remote operation in this version.

Before a mutation, Gits records an intent; after success it records the result, and on a reported Git failure it records the failure. A commit is blocked when hooks are present unless you inspect them and add `-AllowHooks`, because repository hooks can execute local programs.

## Accord record fields

Each `gits-accord.jsonl` line is a compact envelope around exact `PayloadJson` bytes and their SHA-256. Payloads include sequence, UTC time, actor, repository root, operation, branch/HEAD/clean-state summary, operation evidence, and the prior digest. `Test-GitsAccord` validates payload digests and every prior link.

The accord is an integrity aid, not a digital signature or proof against an administrator who can replace both code and ledger. Use signed commits, protected remotes, backups, and access controls when those guarantees are needed.
