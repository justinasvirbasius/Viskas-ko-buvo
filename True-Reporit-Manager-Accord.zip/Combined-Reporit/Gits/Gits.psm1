#requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$script:GitsRoot = $PSScriptRoot
$script:PolicyPath = Join-Path $PSScriptRoot 'Gits.policy.json'
$script:Utf8NoBom = New-Object Text.UTF8Encoding($false)

function Get-GitsPolicy {
    [CmdletBinding()]
    param()
    if (-not (Test-Path -LiteralPath $script:PolicyPath)) { throw "Gits policy missing: $script:PolicyPath" }
    Get-Content -LiteralPath $script:PolicyPath -Raw -Encoding UTF8 | ConvertFrom-Json
}

function Get-GitsHash {
    param([Parameter(Mandatory)][byte[]]$Bytes)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return -join ($sha.ComputeHash($Bytes) | ForEach-Object { $_.ToString('x2') }) }
    finally { $sha.Dispose() }
}

function Resolve-GitsRoot {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw 'Git executable was not found on PATH.' }
    if (-not (Test-Path -LiteralPath $Path)) { throw "Repository path does not exist: $Path" }
    $full = [IO.Path]::GetFullPath((Resolve-Path -LiteralPath $Path).Path)
    $out = @(& git -C $full rev-parse --show-toplevel 2>&1)
    if ($LASTEXITCODE -ne 0) { throw "Not a Git working tree: $Path" }
    return [IO.Path]::GetFullPath(([string]$out[-1]).Trim())
}

function Invoke-GitsGit {
    param([Parameter(Mandatory)][string]$RepositoryRoot, [Parameter(Mandatory)][string[]]$Arguments)
    $output = @(& git -C $RepositoryRoot @Arguments 2>&1 | ForEach-Object { [string]$_ })
    $code = $LASTEXITCODE
    [pscustomobject]@{ ExitCode = [int]$code; Output = @($output); Text = (@($output) -join "`n") }
}

function Get-GitsHooks {
    param([Parameter(Mandatory)][string]$RepositoryRoot)
    $result = Invoke-GitsGit -RepositoryRoot $RepositoryRoot -Arguments @('rev-parse', '--git-path', 'hooks')
    if ($result.ExitCode -ne 0) { return @() }
    $hookRoot = [string]$result.Text.Trim()
    if (-not [IO.Path]::IsPathRooted($hookRoot)) { $hookRoot = Join-Path $RepositoryRoot $hookRoot }
    if (-not (Test-Path -LiteralPath $hookRoot)) { return @() }
    return @((Get-ChildItem -LiteralPath $hookRoot -File -ErrorAction SilentlyContinue | Where-Object {
        $_.Name -notlike '*.sample'
    } | Select-Object -ExpandProperty Name | Sort-Object -Unique))
}

function Get-GitsRepository {
    [CmdletBinding()]
    param([string]$Path = (Get-Location).Path)
    $root = Resolve-GitsRoot -Path $Path
    $headResult = Invoke-GitsGit -RepositoryRoot $root -Arguments @('rev-parse', 'HEAD')
    $head = if ($headResult.ExitCode -eq 0) { $headResult.Text.Trim() } else { $null }
    $branchResult = Invoke-GitsGit -RepositoryRoot $root -Arguments @('symbolic-ref', '--quiet', '--short', 'HEAD')
    $branch = if ($branchResult.ExitCode -eq 0) { $branchResult.Text.Trim() } else { '(detached HEAD)' }
    $statusResult = Invoke-GitsGit -RepositoryRoot $root -Arguments @('status', '--porcelain=v2', '--branch', '--untracked-files=all')
    if ($statusResult.ExitCode -ne 0) { throw "git status failed: $($statusResult.Text)" }
    $statusLines = @($statusResult.Output | Where-Object { $_ -and -not $_.StartsWith('#') })
    $upstreamLine = @($statusResult.Output | Where-Object { $_.StartsWith('# branch.upstream ') } | Select-Object -First 1)
    $upstream = if ($upstreamLine.Count -gt 0) { ([string]$upstreamLine[0] -replace '^# branch\.upstream ', '') } else { $null }
    $remotesResult = Invoke-GitsGit -RepositoryRoot $root -Arguments @('remote')
    $remotes = if ($remotesResult.ExitCode -eq 0) { @($remotesResult.Output | Where-Object { $_ }) } else { @() }
    $hooks = @(Get-GitsHooks -RepositoryRoot $root)
    [pscustomobject]@{
        Schema = 'gits-repository/v1'
        Root = $root
        Branch = $branch
        Head = $head
        Upstream = $upstream
        Remotes = $remotes
        HookFiles = $hooks
        CommitHooksMayExecute = ($hooks.Count -gt 0)
        IsDetached = ($branch -eq '(detached HEAD)')
        IsClean = ($statusLines.Count -eq 0)
        ChangeCount = $statusLines.Count
        StatusPorcelainV2 = $statusLines
        StatusError = if ($headResult.ExitCode -ne 0) { $headResult.Text } else { '' }
    }
}

function Get-GitsAccordRoot {
    [CmdletBinding()]
    param([string]$RepositoryPath = (Get-Location).Path, [string]$AccordRoot)
    $root = Resolve-GitsRoot -Path $RepositoryPath
    if (-not [string]::IsNullOrWhiteSpace($AccordRoot)) { return [IO.Path]::GetFullPath($AccordRoot) }
    $base = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'Gits'
    $digest = Get-GitsHash -Bytes $script:Utf8NoBom.GetBytes($root.ToLowerInvariant())
    return Join-Path $base $digest.Substring(0, 24)
}

function Read-GitsLedger {
    param([Parameter(Mandatory)][string]$LedgerPath)
    if (-not (Test-Path -LiteralPath $LedgerPath)) { return @() }
    $items = New-Object Collections.Generic.List[object]
    $previous = $null
    $lineNumber = 0
    $expectedSequence = 1L
    foreach ($line in [IO.File]::ReadLines($LedgerPath, $script:Utf8NoBom)) {
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        $lineNumber++
        $envelope = $line | ConvertFrom-Json
        $canonical = [string]$envelope.PayloadJson
        $payload = $canonical | ConvertFrom-Json
        $actual = Get-GitsHash -Bytes $script:Utf8NoBom.GetBytes($canonical)
        if ($actual -cne [string]$envelope.PayloadSha256) { throw "Gits accord record $lineNumber has an invalid digest." }
        $expectedPrior = if ($null -eq $previous) { '' } else { [string]$previous }
        if ([string]$payload.PreviousRecordSha256 -cne $expectedPrior) { throw "Gits accord record $lineNumber has a broken prior link." }
        if ([long]$payload.Sequence -ne $expectedSequence) { throw "Gits accord record $lineNumber has a broken sequence." }
        $items.Add([pscustomobject]@{ Payload = $payload; Hash = [string]$envelope.PayloadSha256 })
        $previous = [string]$envelope.PayloadSha256
        $expectedSequence++
    }
    return @($items)
}

function Write-GitsAccord {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory)][string]$RepositoryPath,
        [Parameter(Mandatory)][string]$Operation,
        [hashtable]$Evidence = @{},
        [string]$AccordRoot,
        [switch]$Commit
    )
    $repo = Get-GitsRepository -Path $RepositoryPath
    $root = Get-GitsAccordRoot -RepositoryPath $repo.Root -AccordRoot $AccordRoot
    $ledger = Join-Path $root 'gits-accord.jsonl'
    if (-not $Commit) { return [pscustomobject]@{ Written = $false; Ledger = $ledger; Guidance = 'Add -Commit to append an accord record.' } }
    if (-not $PSCmdlet.ShouldProcess($ledger, "append Gits accord record for $Operation")) { return }
    [void](New-Item -ItemType Directory -Path $root -Force)
    $mutexKey = Get-GitsHash -Bytes $script:Utf8NoBom.GetBytes($ledger.ToLowerInvariant())
    $mutex = New-Object Threading.Mutex($false, ('Local\GitsAccord-' + $mutexKey.Substring(0, 24)))
    $locked = $false
    try {
        $locked = $mutex.WaitOne([TimeSpan]::FromSeconds(20))
        if (-not $locked) { throw 'Gits accord ledger is busy; lock timeout.' }
        $records = @(Read-GitsLedger -LedgerPath $ledger)
        $previous = if ($records.Count -gt 0) { [string]$records[-1].Hash } else { '' }
        $payload = [ordered]@{
            Schema = 'gits-accord/v1'
            Sequence = [long]$records.Count + 1
            TimestampUtc = [DateTimeOffset]::UtcNow.ToString('o')
            Actor = [Environment]::UserName
            RepositoryRoot = $repo.Root
            Operation = $Operation
            Repository = [ordered]@{
                Branch = $repo.Branch
                Head = $repo.Head
                Upstream = $repo.Upstream
                IsClean = $repo.IsClean
                ChangeCount = $repo.ChangeCount
            }
            Evidence = $Evidence
            PreviousRecordSha256 = $previous
        }
        $canonical = $payload | ConvertTo-Json -Depth 20 -Compress
        $hash = Get-GitsHash -Bytes $script:Utf8NoBom.GetBytes($canonical)
        $line = [ordered]@{ PayloadJson = $canonical; PayloadSha256 = $hash } | ConvertTo-Json -Depth 20 -Compress
        $bytes = $script:Utf8NoBom.GetBytes($line + [Environment]::NewLine)
        $stream = New-Object IO.FileStream($ledger, [IO.FileMode]::Append, [IO.FileAccess]::Write, [IO.FileShare]::Read)
        try { $stream.Write($bytes, 0, $bytes.Length); $stream.Flush($true) }
        finally { $stream.Dispose() }
        [pscustomobject]@{ Written = $true; Sequence = $payload.Sequence; Hash = $hash; Ledger = $ledger; Repository = $repo }
    } finally {
        if ($locked) { $mutex.ReleaseMutex() }
        $mutex.Dispose()
    }
}

function Test-GitsAccord {
    [CmdletBinding()]
    param([string]$RepositoryPath = (Get-Location).Path, [string]$AccordRoot)
    $repo = Get-GitsRepository -Path $RepositoryPath
    $root = Get-GitsAccordRoot -RepositoryPath $repo.Root -AccordRoot $AccordRoot
    $ledger = Join-Path $root 'gits-accord.jsonl'
    try {
        $records = @(Read-GitsLedger -LedgerPath $ledger)
        [pscustomobject]@{
            Valid = $true
            RepositoryRoot = $repo.Root
            AccordRoot = $root
            Records = $records.Count
            LastHash = if ($records.Count -gt 0) { $records[-1].Hash } else { $null }
            CurrentRepository = $repo
            Guidance = if ($records.Count -eq 0) { 'No Gits records yet; call Write-GitsAccord with -Commit to begin.' } else { 'Hash chain and prior links are valid.' }
        }
    } catch {
        [pscustomobject]@{
            Valid = $false; RepositoryRoot = $repo.Root; AccordRoot = $root; Records = $null
            LastHash = $null; CurrentRepository = $repo
            Guidance = "Preserve the ledger and inspect its first failing line. $($_.Exception.Message)"
        }
    }
}

function Initialize-GitsRepository {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param([Parameter(Mandatory)][string]$Path, [string]$InitialBranch = 'main', [switch]$Commit)
    $policy = Get-GitsPolicy
    if (-not [bool]$policy.repository.allowInitialize) { throw 'Repository initialization is disabled by policy.' }
    if ($InitialBranch -notmatch '^[A-Za-z0-9][A-Za-z0-9._/-]{0,99}$' -or $InitialBranch.Contains('..')) {
        throw 'InitialBranch has invalid Git ref characters.'
    }
    if (-not $Commit) { return [pscustomobject]@{ Initialized = $false; Path = [IO.Path]::GetFullPath($Path); Branch = $InitialBranch; Guidance = 'Add -Commit to create a local Git repository.' } }
    $full = [IO.Path]::GetFullPath($Path)
    if ($PSCmdlet.ShouldProcess($full, "initialize local Git repository on $InitialBranch")) {
        if (-not (Test-Path -LiteralPath $full)) { [void](New-Item -ItemType Directory -Path $full -Force) }
        $result = @(& git -C $full init --initial-branch=$InitialBranch 2>&1)
        if ($LASTEXITCODE -ne 0) { throw "git init failed: $($result -join ' ')" }
        $repo = Get-GitsRepository -Path $full
        $accord = Write-GitsAccord -RepositoryPath $repo.Root -Operation 'InitializeRepository' `
            -Evidence @{ initialBranch = $InitialBranch; localOnly = $true } -Commit
        [pscustomobject]@{ Initialized = $true; Repository = $repo; Accord = $accord }
    }
}

function Invoke-GitsRead {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][ValidateSet('Status', 'Log', 'Diff', 'Branches', 'Tags')][string]$Operation,
        [string]$RepositoryPath = (Get-Location).Path,
        [ValidateRange(1,500)][int]$Limit = 25,
        [switch]$Commit
    )
    $repo = Get-GitsRepository -Path $RepositoryPath
    $arguments = switch ($Operation) {
        'Status' { @('status', '--short', '--branch') }
        'Log' { @('log', '--oneline', '--decorate', "-$Limit") }
        'Diff' { @('diff', '--stat', '--') }
        'Branches' { @('branch', '--list', '--no-color') }
        'Tags' { @('tag', '--list') }
    }
    $result = Invoke-GitsGit -RepositoryRoot $repo.Root -Arguments $arguments
    if ($result.ExitCode -ne 0) { throw "Git $Operation failed: $($result.Text)" }
    $receipt = Write-GitsAccord -RepositoryPath $repo.Root -Operation "Read/$Operation" `
        -Evidence @{ resultSha256 = Get-GitsHash -Bytes $script:Utf8NoBom.GetBytes($result.Text); lineCount = $result.Output.Count } `
        -Commit:$Commit
    [pscustomobject]@{ Operation = $Operation; Repository = $repo; Output = $result.Output; AccordPreview = $receipt }
}

function Invoke-GitsMutation {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory)][ValidateSet('Add', 'Commit', 'CreateBranch', 'SwitchBranch', 'CreateTag')][string]$Operation,
        [string]$RepositoryPath = (Get-Location).Path,
        [string[]]$Pathspec = @(),
        [string]$Message = '',
        [string]$Name = '',
        [switch]$AllowHooks,
        [switch]$Commit
    )
    $policy = Get-GitsPolicy
    $repo = Get-GitsRepository -Path $RepositoryPath
    if (-not $Commit) { return [pscustomobject]@{ Executed = $false; Operation = $Operation; Repository = $repo; Guidance = 'Add -Commit to apply this local Git mutation.' } }
    if ($Operation -eq 'Add' -and -not [bool]$policy.repository.allowLocalAdd) { throw 'Git add is disabled by policy.' }
    if ($Operation -eq 'Commit' -and -not [bool]$policy.repository.allowLocalCommit) { throw 'Git commit is disabled by policy.' }
    if ($Operation -eq 'CreateBranch' -and -not [bool]$policy.repository.allowBranchCreate) { throw 'Branch creation is disabled by policy.' }
    if ($Operation -eq 'SwitchBranch' -and -not [bool]$policy.repository.allowBranchSwitch) { throw 'Branch switching is disabled by policy.' }
    if ($Operation -eq 'CreateTag' -and -not [bool]$policy.repository.allowTagCreate) { throw 'Tag creation is disabled by policy.' }
    switch ($Operation) {
        'Add' {
            if ($Pathspec.Count -eq 0) { throw 'Add requires one or more explicit -Pathspec values; use . to stage all only if that is intended.' }
            $arguments = @('add', '--') + $Pathspec
        }
        'Commit' {
            if ([string]::IsNullOrWhiteSpace($Message)) { throw 'Commit requires -Message.' }
            if ($repo.CommitHooksMayExecute -and -not $AllowHooks) {
                throw "Repository hooks are present ($($repo.HookFiles -join ', ')). Inspect them and pass -AllowHooks to permit execution."
            }
            $arguments = @('commit', '-m', $Message)
        }
        'CreateBranch' {
            if ($Name -notmatch '^[A-Za-z0-9][A-Za-z0-9._/-]{0,99}$' -or $Name.Contains('..')) { throw 'Name is not a safe branch ref.' }
            $arguments = @('branch', $Name)
        }
        'SwitchBranch' {
            if ($Name -notmatch '^[A-Za-z0-9][A-Za-z0-9._/-]{0,99}$' -or $Name.Contains('..')) { throw 'Name is not a safe branch ref.' }
            $arguments = @('switch', $Name)
        }
        'CreateTag' {
            if ($Name -notmatch '^[A-Za-z0-9][A-Za-z0-9._/-]{0,99}$' -or $Name.Contains('..')) { throw 'Name is not a safe tag ref.' }
            $arguments = @('tag', $Name)
        }
    }
    $target = switch ($Operation) {
        'Add' { $Pathspec -join ', ' }
        'Commit' { $Message }
        default { $Name }
    }
    if (-not $PSCmdlet.ShouldProcess($repo.Root, "Git $Operation $target")) { return }
    $before = @{ head = $repo.Head; branch = $repo.Branch; clean = $repo.IsClean; changes = $repo.ChangeCount }
    $intent = Write-GitsAccord -RepositoryPath $repo.Root -Operation "Intent/$Operation" -Commit `
        -Evidence @{ target = $target; before = $before; allowedHookExecution = [bool]($Operation -eq 'Commit' -and $AllowHooks) }
    $result = Invoke-GitsGit -RepositoryRoot $repo.Root -Arguments $arguments
    if ($result.ExitCode -ne 0) {
        $failure = Write-GitsAccord -RepositoryPath $repo.Root -Operation "Failure/$Operation" -Commit `
            -Evidence @{ exitCode = $result.ExitCode; outputSha256 = Get-GitsHash -Bytes $script:Utf8NoBom.GetBytes($result.Text); intentSequence = $intent.Sequence }
        throw "Git $Operation failed (accord sequence $($failure.Sequence)): $($result.Text)"
    }
    $after = Get-GitsRepository -Path $repo.Root
    $receipt = Write-GitsAccord -RepositoryPath $repo.Root -Operation "Mutation/$Operation" -Commit `
        -Evidence @{ before = $before; afterHead = $after.Head; afterBranch = $after.Branch; afterClean = $after.IsClean; outputSha256 = Get-GitsHash -Bytes $script:Utf8NoBom.GetBytes($result.Text); intentSequence = $intent.Sequence }
    [pscustomobject]@{ Executed = $true; Operation = $Operation; Repository = $after; Output = $result.Output; Intent = $intent; Accord = $receipt }
}

function Start-Gits {
    [CmdletBinding()]
    param([string]$RepositoryPath = (Get-Location).Path)
    [pscustomobject]@{
        Name = 'Gits'
        Version = '1.0.0'
        Policy = Get-GitsPolicy
        Repository = Get-GitsRepository -Path $RepositoryPath
        Accord = Test-GitsAccord -RepositoryPath $RepositoryPath
        Mutations = @('Add', 'Commit', 'CreateBranch', 'SwitchBranch', 'CreateTag')
        RemoteOperations = 'Disabled by default and not implemented in this initial accord.'
        Examples = @(
            'Get-GitsRepository',
            'Test-GitsAccord',
            'Write-GitsAccord -RepositoryPath . -Operation Checkpoint -Commit',
            'Invoke-GitsRead -Operation Status',
            'Invoke-GitsMutation -Operation Add -Pathspec README.md -Commit'
        )
    }
}

Export-ModuleMember -Function @(
    'Get-GitsPolicy', 'Get-GitsRepository', 'Get-GitsAccordRoot', 'Write-GitsAccord',
    'Test-GitsAccord', 'Initialize-GitsRepository', 'Invoke-GitsRead',
    'Invoke-GitsMutation', 'Start-Gits'
)
