#requires -Version 5.1
[CmdletBinding()]
param([string]$RepositoryPath = (Get-Location).Path)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'Gits.psd1') -Force -ErrorAction Stop
$repo = Get-GitsRepository -Path $RepositoryPath
$accord = Test-GitsAccord -RepositoryPath $RepositoryPath
[pscustomobject]@{
    Schema = 'gits-self-test/v1'
    Passed = ($repo.Root -and $accord.Valid)
    RepositoryRoot = $repo.Root
    Branch = $repo.Branch
    Head = $repo.Head
    AccordValid = $accord.Valid
    AccordRecords = $accord.Records
    Guidance = $accord.Guidance
}
