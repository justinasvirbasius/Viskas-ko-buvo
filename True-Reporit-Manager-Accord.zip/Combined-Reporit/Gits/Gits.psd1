@{
    RootModule = 'Gits.psm1'
    ModuleVersion = '1.0.0'
    GUID = '32cdd8a5-d5e9-4c7e-8e40-0ef451661127'
    Author = 'Gits Accord'
    CompanyName = 'Independent'
    Copyright = 'Copyright (c) 2026. All rights reserved.'
    Description = 'A local, explicit-consent governance accord for Git repositories.'
    PowerShellVersion = '5.1'
    FunctionsToExport = @(
        'Get-GitsPolicy', 'Get-GitsRepository', 'Get-GitsAccordRoot',
        'Write-GitsAccord', 'Test-GitsAccord', 'Initialize-GitsRepository',
        'Invoke-GitsRead', 'Invoke-GitsMutation', 'Start-Gits'
    )
    CmdletsToExport = @()
    VariablesToExport = @()
    AliasesToExport = @()
    PrivateData = @{ PSData = @{ Tags = @('Git', 'Repository', 'Governance', 'Audit', 'PowerShell') } }
}
