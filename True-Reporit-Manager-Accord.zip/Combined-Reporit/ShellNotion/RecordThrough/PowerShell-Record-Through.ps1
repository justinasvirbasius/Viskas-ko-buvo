#requires -Version 5.1
<#
.SYNOPSIS
    Double-notion Record-Through regime with bounded capacity and accord checks.

.DESCRIPTION
    Writes every annotation twice: a primary record and a compact witness receipt.
    Both streams have independent SHA-256 chains. Accord verification checks each
    chain and confirms that every receipt identifies the matching primary record.
    Active files rotate before the configured byte capacity is exceeded.

    The Temporati regime binds event time, observation time, the prior observation,
    cadence, permitted time window, and local ordering verdict into both chains.
    Strict mode rejects a record when a temporal guarantee check fails.

    The rights annotation states authority, prior reference, use rights, consent,
    and retention intent. These are declarations for auditing; this script does
    not create, transfer, or adjudicate legal rights.

    The script records metadata only. It does not capture keystrokes, credentials,
    command output, or private system state unless such data is explicitly supplied
    in -Message or -Data.

.EXAMPLE
    .\PowerShell-Record-Through.ps1 -Action Record -Purpose Build `
      -Message 'Renderer validation completed' -PriorReference 'build-0041' `
      -Rights 'internal-use; preserve-attribution' -Data @{ Passed = 42; Failed = 0 }

.EXAMPLE
    .\PowerShell-Record-Through.ps1 -Action Status

.EXAMPLE
    .\PowerShell-Record-Through.ps1 -Action Verify -IncludeArchive
#>

[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [ValidateSet('Record', 'Status', 'Verify', 'Export')]
    [string]$Action = 'Record',

    [ValidateNotNullOrEmpty()]
    [string]$Purpose = 'General',

    [AllowEmptyString()]
    [string]$Message = '',

    [hashtable]$Data = @{},

    [AllowEmptyString()]
    [string]$PriorReference = '',

    [ValidateNotNullOrEmpty()]
    [string]$Authority = 'self-declared',

    [ValidateNotNullOrEmpty()]
    [string]$Rights = 'record-owner-controlled',

    [ValidateSet('affirmed', 'not-required', 'withheld')]
    [string]$Consent = 'affirmed',

    [ValidateNotNullOrEmpty()]
    [string]$Retention = 'bounded-by-capacity',

    [AllowEmptyString()]
    [string]$EventTimeUtc = '',

    [AllowEmptyString()]
    [string]$NotBeforeUtc = '',

    [AllowEmptyString()]
    [string]$NotAfterUtc = '',

    [ValidateSet('Strict', 'Observe')]
    [string]$TemporalMode = 'Strict',

    [ValidateRange(0, 86400)]
    [int]$MaxFutureSkewSeconds = 300,

    [ValidateRange(0, 86400)]
    [int]$MaxClockRegressionSeconds = 0,

    [ValidateRange(0, 86400000)]
    [int]$MinimumIntervalMilliseconds = 0,

    [ValidateRange(1, 4096)]
    [int]$CapacityMB = 32,

    [ValidateRange(1, 1000)]
    [int]$ArchiveCount = 8,

    [ValidateRange(128, 10485760)]
    [int]$MaxRecordBytes = 1048576,

    [string]$RootPath = (Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'RecordThrough'),

    [string]$ExportPath,

    [switch]$IncludeArchive,

    [switch]$PassThru
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$script:Schema = 'record-through/v3'
$script:WitnessSchema = 'record-through-witness/v2'
$script:Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$script:LedgerName = 'record-through.jsonl'
$script:WitnessName = 'record-through.witness.jsonl'
$script:StateName = 'record-through.state.json'
$script:ArchiveDirectoryName = 'archive'

function Get-Sha256Hex {
    param([Parameter(Mandatory)][byte[]]$Bytes)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return -join ($sha.ComputeHash($Bytes) | ForEach-Object { $_.ToString('x2') }) }
    finally { $sha.Dispose() }
}

function ConvertTo-CanonicalJson {
    param([Parameter(Mandatory)]$InputObject)
    # Properties are constructed in a fixed order before this function is called.
    return ($InputObject | ConvertTo-Json -Depth 20 -Compress)
}

function Initialize-Store {
    if (-not (Test-Path -LiteralPath $RootPath)) {
        [void](New-Item -ItemType Directory -Path $RootPath -Force)
    }
    $archivePath = Join-Path $RootPath $script:ArchiveDirectoryName
    if (-not (Test-Path -LiteralPath $archivePath)) {
        [void](New-Item -ItemType Directory -Path $archivePath -Force)
    }
    return [pscustomobject]@{
        Ledger  = Join-Path $RootPath $script:LedgerName
        Witness = Join-Path $RootPath $script:WitnessName
        State   = Join-Path $RootPath $script:StateName
        Archive = $archivePath
    }
}

function Read-State {
    param([Parameter(Mandatory)]$Paths)
    if (-not (Test-Path -LiteralPath $Paths.State)) {
        return [ordered]@{
            sequence = 0L; lastHash = ('0' * 64); witnessLastHash = ('0' * 64)
            lastObservedUtc = ''; generation = 1
        }
    }
    $state = Get-Content -LiteralPath $Paths.State -Raw -Encoding UTF8 | ConvertFrom-Json
    return [ordered]@{
        sequence   = [long]$state.sequence
        lastHash   = [string]$state.lastHash
        witnessLastHash = if ($state.PSObject.Properties.Name -contains 'witnessLastHash') {
            [string]$state.witnessLastHash
        } else { '0' * 64 }
        lastObservedUtc = if ($state.PSObject.Properties.Name -contains 'lastObservedUtc') {
            [string]$state.lastObservedUtc
        } else { '' }
        generation = [int]$state.generation
    }
}

function Write-StateAtomic {
    param([Parameter(Mandatory)]$Paths, [Parameter(Mandatory)]$State)
    $temporary = $Paths.State + '.tmp'
    [IO.File]::WriteAllText($temporary, (ConvertTo-CanonicalJson $State), $script:Utf8NoBom)
    Move-Item -LiteralPath $temporary -Destination $Paths.State -Force
}

function Remove-ExpiredArchives {
    param([Parameter(Mandatory)]$Paths)
    $archives = @(Get-ChildItem -LiteralPath $Paths.Archive -File -Filter 'record-through-g*.jsonl' |
        Sort-Object LastWriteTimeUtc -Descending)
    if ($archives.Count -gt $ArchiveCount) {
        foreach ($archive in ($archives | Select-Object -Skip $ArchiveCount)) {
            $witnessName = $archive.Name -replace '^record-through-', 'record-through-witness-'
            $witnessPath = Join-Path $Paths.Archive $witnessName
            Remove-Item -LiteralPath $archive.FullName -Force
            if (Test-Path -LiteralPath $witnessPath) { Remove-Item -LiteralPath $witnessPath -Force }
        }
    }
}

function Rotate-Ledger {
    param([Parameter(Mandatory)]$Paths, [Parameter(Mandatory)]$State)
    if (-not (Test-Path -LiteralPath $Paths.Ledger) -and
        -not (Test-Path -LiteralPath $Paths.Witness)) { return }
    $stamp = [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffZ')
    $ledgerName = 'record-through-g{0:D5}-{1}.jsonl' -f [int]$State.generation, $stamp
    $witnessName = 'record-through-witness-g{0:D5}-{1}.jsonl' -f [int]$State.generation, $stamp
    if (Test-Path -LiteralPath $Paths.Ledger) {
        Move-Item -LiteralPath $Paths.Ledger -Destination (Join-Path $Paths.Archive $ledgerName)
    }
    if (Test-Path -LiteralPath $Paths.Witness) {
        Move-Item -LiteralPath $Paths.Witness -Destination (Join-Path $Paths.Archive $witnessName)
    }
    $State.generation = [int]$State.generation + 1
    Remove-ExpiredArchives -Paths $Paths
}

function ConvertTo-UtcInstant {
    param([AllowEmptyString()][string]$Value, [Parameter(Mandatory)][string]$Name)
    if ([string]::IsNullOrWhiteSpace($Value)) { return $null }
    $parsed = [DateTimeOffset]::MinValue
    if (-not [DateTimeOffset]::TryParse(
        $Value, [Globalization.CultureInfo]::InvariantCulture,
        [Globalization.DateTimeStyles]::AllowWhiteSpaces, [ref]$parsed)) {
        throw "$Name must be a valid date/time with an explicit UTC offset."
    }
    if (-not ($Value -match '(Z|[+-][0-9]{2}:[0-9]{2})$')) {
        throw "$Name must include Z or an explicit UTC offset."
    }
    return $parsed.ToUniversalTime()
}

function New-TemporatiObject {
    param([Parameter(Mandatory)]$State)
    $observed = [DateTimeOffset]::UtcNow
    $event = ConvertTo-UtcInstant -Value $EventTimeUtc -Name 'EventTimeUtc'
    if ($null -eq $event) { $event = $observed }
    $notBefore = ConvertTo-UtcInstant -Value $NotBeforeUtc -Name 'NotBeforeUtc'
    $notAfter = ConvertTo-UtcInstant -Value $NotAfterUtc -Name 'NotAfterUtc'
    if ($null -ne $notBefore -and $null -ne $notAfter -and $notBefore -gt $notAfter) {
        throw 'NotBeforeUtc must not be later than NotAfterUtc.'
    }

    $prior = ConvertTo-UtcInstant -Value ([string]$State.lastObservedUtc) -Name 'state.lastObservedUtc'
    $elapsedMs = if ($null -eq $prior) { $null } else { [Math]::Round(($observed - $prior).TotalMilliseconds, 3) }
    $clockNonRegressive = ($null -eq $prior) -or
        ($observed -ge $prior.AddSeconds(-1 * $MaxClockRegressionSeconds))
    $cadenceSatisfied = ($null -eq $prior) -or ($elapsedMs -ge $MinimumIntervalMilliseconds)
    $insideWindow = (($null -eq $notBefore) -or ($event -ge $notBefore)) -and
        (($null -eq $notAfter) -or ($event -le $notAfter))
    $eventNotFuture = $event -le $observed.AddSeconds($MaxFutureSkewSeconds)
    $passed = $clockNonRegressive -and $cadenceSatisfied -and $insideWindow -and $eventNotFuture

    $temporati = [ordered]@{
        regime                     = 'temporati/v1'
        mode                       = $TemporalMode.ToLowerInvariant()
        observedUtc                = $observed.ToString('o')
        eventUtc                   = $event.ToString('o')
        priorObservedUtc           = if ($null -eq $prior) { '' } else { $prior.ToString('o') }
        elapsedMilliseconds        = $elapsedMs
        notBeforeUtc               = if ($null -eq $notBefore) { '' } else { $notBefore.ToString('o') }
        notAfterUtc                = if ($null -eq $notAfter) { '' } else { $notAfter.ToString('o') }
        minimumIntervalMilliseconds = $MinimumIntervalMilliseconds
        maxFutureSkewSeconds       = $MaxFutureSkewSeconds
        maxClockRegressionSeconds  = $MaxClockRegressionSeconds
        checks                     = [ordered]@{
            priorSequenceContinuous = ([long]$State.sequence -ge 0)
            clockNonRegressive       = $clockNonRegressive
            cadenceSatisfied         = $cadenceSatisfied
            insidePermittedWindow    = $insideWindow
            eventNotExcessivelyFuture = $eventNotFuture
        }
        verdict                    = if ($passed) { 'guaranteed' } else { 'violation-observed' }
        guaranteeScope             = 'local-observation-order-and-hash-continuity'
        clockTrust                 = 'system-clock-not-external-authority'
    }
    if (-not $passed -and $TemporalMode -eq 'Strict') {
        $failed = @($temporati.checks.Keys | Where-Object { -not $temporati.checks[$_] }) -join ', '
        throw "Temporati strict guarantee rejected the record. Failed: $failed"
    }
    return $temporati
}

function New-RecordObject {
    param([Parameter(Mandatory)]$State, [Parameter(Mandatory)]$Temporati)
    $core = [ordered]@{
        schema       = $script:Schema
        sequence     = [long]$State.sequence + 1
        generation   = [int]$State.generation
        timestampUtc = $Temporati.observedUtc
        purpose      = $Purpose.Trim()
        message      = $Message
        data         = if ($null -eq $Data) { @{} } else { $Data }
        rights       = [ordered]@{
            priorReference = $PriorReference.Trim()
            authority      = $Authority.Trim()
            rights         = $Rights.Trim()
            consent        = $Consent
            retention      = $Retention.Trim()
            legalEffect    = 'annotation-only'
        }
        temporati    = $Temporati
        host         = [ordered]@{
            machine    = [Environment]::MachineName
            user       = [Environment]::UserName
            processId  = $PID
            powershell = $PSVersionTable.PSVersion.ToString()
        }
        previousHash = [string]$State.lastHash
    }
    $hash = Get-Sha256Hex -Bytes $script:Utf8NoBom.GetBytes((ConvertTo-CanonicalJson $core))
    $record = [ordered]@{}
    foreach ($key in $core.Keys) { $record[$key] = $core[$key] }
    $record['hash'] = $hash
    return $record
}

function New-WitnessObject {
    param([Parameter(Mandatory)]$State, [Parameter(Mandatory)]$Record)
    $core = [ordered]@{
        schema              = $script:WitnessSchema
        sequence            = [long]$Record.sequence
        generation          = [int]$Record.generation
        timestampUtc        = [DateTime]::UtcNow.ToString('o')
        recordHash          = [string]$Record.hash
        purposeDigest       = Get-Sha256Hex -Bytes $script:Utf8NoBom.GetBytes([string]$Record.purpose)
        priorReferenceDigest = Get-Sha256Hex -Bytes $script:Utf8NoBom.GetBytes([string]$Record.rights.priorReference)
        temporatiDigest      = Get-Sha256Hex -Bytes $script:Utf8NoBom.GetBytes((ConvertTo-CanonicalJson $Record.temporati))
        accord              = 'primary-and-witness'
        previousWitnessHash = [string]$State.witnessLastHash
    }
    $hash = Get-Sha256Hex -Bytes $script:Utf8NoBom.GetBytes((ConvertTo-CanonicalJson $core))
    $witness = [ordered]@{}
    foreach ($key in $core.Keys) { $witness[$key] = $core[$key] }
    $witness['hash'] = $hash
    return $witness
}

function Add-Record {
    $paths = Initialize-Store
    $capacityBytes = [long]$CapacityMB * 1MB
    $mutexMaterial = $script:Utf8NoBom.GetBytes(([IO.Path]::GetFullPath($RootPath)).ToLowerInvariant())
    $mutexName = 'Local\RecordThrough-' + (Get-Sha256Hex $mutexMaterial).Substring(0, 24)
    $mutex = New-Object Threading.Mutex($false, $mutexName)
    $locked = $false
    try {
        $locked = $mutex.WaitOne([TimeSpan]::FromSeconds(15))
        if (-not $locked) { throw 'Record store is busy; lock timeout after 15 seconds.' }

        $state = Read-State -Paths $paths
        $temporati = New-TemporatiObject -State $state
        $record = New-RecordObject -State $state -Temporati $temporati
        $witness = New-WitnessObject -State $state -Record $record
        $line = (ConvertTo-CanonicalJson $record) + [Environment]::NewLine
        $witnessLine = (ConvertTo-CanonicalJson $witness) + [Environment]::NewLine
        $lineBytes = $script:Utf8NoBom.GetBytes($line)
        $witnessBytes = $script:Utf8NoBom.GetBytes($witnessLine)
        if (($lineBytes.Length + $witnessBytes.Length) -gt $MaxRecordBytes) {
            throw "Double-notion entry is $($lineBytes.Length + $witnessBytes.Length) bytes; MaxRecordBytes is $MaxRecordBytes."
        }
        if ($lineBytes.Length -gt $capacityBytes -or $witnessBytes.Length -gt $capacityBytes) {
            throw "The double-notion entry cannot fit within the configured capacity of $CapacityMB MB."
        }

        $currentLedgerBytes = if (Test-Path -LiteralPath $paths.Ledger) {
            (Get-Item -LiteralPath $paths.Ledger).Length
        } else { 0L }
        $currentWitnessBytes = if (Test-Path -LiteralPath $paths.Witness) {
            (Get-Item -LiteralPath $paths.Witness).Length
        } else { 0L }
        if (($currentLedgerBytes + $lineBytes.Length) -gt $capacityBytes -or
            ($currentWitnessBytes + $witnessBytes.Length) -gt $capacityBytes) {
            Rotate-Ledger -Paths $paths -State $state
            $record = New-RecordObject -State $state -Temporati $temporati
            $witness = New-WitnessObject -State $state -Record $record
            $line = (ConvertTo-CanonicalJson $record) + [Environment]::NewLine
            $witnessLine = (ConvertTo-CanonicalJson $witness) + [Environment]::NewLine
            $lineBytes = $script:Utf8NoBom.GetBytes($line)
            $witnessBytes = $script:Utf8NoBom.GetBytes($witnessLine)
        }

        if ($PSCmdlet.ShouldProcess($paths.Ledger, "append double-notion record for purpose '$Purpose'")) {
            $stream = New-Object IO.FileStream($paths.Ledger, [IO.FileMode]::Append,
                [IO.FileAccess]::Write, [IO.FileShare]::Read)
            try {
                $stream.Write($lineBytes, 0, $lineBytes.Length)
                $stream.Flush($true)
            } finally { $stream.Dispose() }

            $witnessStream = New-Object IO.FileStream($paths.Witness, [IO.FileMode]::Append,
                [IO.FileAccess]::Write, [IO.FileShare]::Read)
            try {
                $witnessStream.Write($witnessBytes, 0, $witnessBytes.Length)
                $witnessStream.Flush($true)
            } finally { $witnessStream.Dispose() }

            $state.sequence = [long]$record.sequence
            $state.lastHash = [string]$record.hash
            $state.witnessLastHash = [string]$witness.hash
            $state.lastObservedUtc = [string]$record.temporati.observedUtc
            Write-StateAtomic -Paths $paths -State $state
        }
        return [pscustomobject]@{ Record = [pscustomobject]$record; Witness = [pscustomobject]$witness }
    } finally {
        if ($locked) { $mutex.ReleaseMutex() }
        $mutex.Dispose()
    }
}

function Test-LedgerFile {
    param([Parameter(Mandatory)][string]$Path)
    $previousHash = $null
    $records = 0
    $errors = New-Object Collections.Generic.List[string]
    foreach ($line in [IO.File]::ReadLines($Path, $script:Utf8NoBom)) {
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        $records++
        try {
            $item = $line | ConvertFrom-Json
            $core = [ordered]@{
                schema       = $item.schema
                sequence     = [long]$item.sequence
                generation   = [int]$item.generation
                timestampUtc = $item.timestampUtc
                purpose      = $item.purpose
                message      = $item.message
                data         = $item.data
            }
            if ($item.PSObject.Properties.Name -contains 'rights') { $core['rights'] = $item.rights }
            if ($item.PSObject.Properties.Name -contains 'temporati') { $core['temporati'] = $item.temporati }
            $core['host'] = $item.host
            $core['previousHash'] = $item.previousHash
            $actual = Get-Sha256Hex -Bytes $script:Utf8NoBom.GetBytes((ConvertTo-CanonicalJson $core))
            if ($actual -ne [string]$item.hash) { $errors.Add("record $records: hash mismatch") }
            if ($null -ne $previousHash -and [string]$item.previousHash -ne $previousHash) {
                $errors.Add("record $records: broken previousHash link")
            }
            $previousHash = [string]$item.hash
        } catch { $errors.Add("record $records: $($_.Exception.Message)") }
    }
    [pscustomobject]@{
        Path    = $Path
        Records = $records
        Valid   = ($errors.Count -eq 0)
        Errors  = @($errors)
    }
}

function Test-WitnessFile {
    param([Parameter(Mandatory)][string]$Path)
    $previousHash = $null
    $items = New-Object Collections.Generic.List[object]
    $errors = New-Object Collections.Generic.List[string]
    $position = 0
    foreach ($line in [IO.File]::ReadLines($Path, $script:Utf8NoBom)) {
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        $position++
        try {
            $item = $line | ConvertFrom-Json
            $core = [ordered]@{
                schema               = $item.schema
                sequence             = [long]$item.sequence
                generation           = [int]$item.generation
                timestampUtc         = $item.timestampUtc
                recordHash           = $item.recordHash
                purposeDigest        = $item.purposeDigest
                priorReferenceDigest = $item.priorReferenceDigest
            }
            if ($item.PSObject.Properties.Name -contains 'temporatiDigest') {
                $core['temporatiDigest'] = $item.temporatiDigest
            }
            $core['accord'] = $item.accord
            $core['previousWitnessHash'] = $item.previousWitnessHash
            $actual = Get-Sha256Hex -Bytes $script:Utf8NoBom.GetBytes((ConvertTo-CanonicalJson $core))
            if ($actual -ne [string]$item.hash) { $errors.Add("witness $position`: hash mismatch") }
            if ($null -ne $previousHash -and [string]$item.previousWitnessHash -ne $previousHash) {
                $errors.Add("witness $position`: broken previousWitnessHash link")
            }
            $previousHash = [string]$item.hash
            $items.Add($item)
        } catch { $errors.Add("witness $position`: $($_.Exception.Message)") }
    }
    [pscustomobject]@{ Path = $Path; Items = @($items); Valid = ($errors.Count -eq 0); Errors = @($errors) }
}

function Test-AccordPair {
    param([Parameter(Mandatory)]$Pair)
    $ledgerTest = Test-LedgerFile -Path $Pair.Ledger
    $errors = New-Object Collections.Generic.List[string]
    foreach ($errorText in $ledgerTest.Errors) { $errors.Add("ledger: $errorText") }
    if ([string]::IsNullOrWhiteSpace($Pair.Witness) -or -not (Test-Path -LiteralPath $Pair.Witness)) {
        $errors.Add('witness file is missing')
        return [pscustomobject]@{
            Ledger = $Pair.Ledger; Witness = $Pair.Witness; Records = $ledgerTest.Records
            Witnesses = 0; Valid = $false; Errors = @($errors)
        }
    }

    $witnessTest = Test-WitnessFile -Path $Pair.Witness
    foreach ($errorText in $witnessTest.Errors) { $errors.Add("witness: $errorText") }
    $recordItems = New-Object Collections.Generic.List[object]
    foreach ($line in [IO.File]::ReadLines($Pair.Ledger, $script:Utf8NoBom)) {
        if (-not [string]::IsNullOrWhiteSpace($line)) { $recordItems.Add(($line | ConvertFrom-Json)) }
    }
    if ($recordItems.Count -ne $witnessTest.Items.Count) {
        $errors.Add("count mismatch: $($recordItems.Count) records, $($witnessTest.Items.Count) witnesses")
    }
    $pairCount = [Math]::Min($recordItems.Count, $witnessTest.Items.Count)
    for ($index = 0; $index -lt $pairCount; $index++) {
        $record = $recordItems[$index]
        $witness = $witnessTest.Items[$index]
        if ([long]$record.sequence -ne [long]$witness.sequence) {
            $errors.Add("pair $($index + 1): sequence mismatch")
        }
        if ([string]$record.hash -ne [string]$witness.recordHash) {
            $errors.Add("pair $($index + 1): recordHash mismatch")
        }
        $purposeDigest = Get-Sha256Hex -Bytes $script:Utf8NoBom.GetBytes([string]$record.purpose)
        if ($purposeDigest -ne [string]$witness.purposeDigest) {
            $errors.Add("pair $($index + 1): purposeDigest mismatch")
        }
        $prior = if ($record.PSObject.Properties.Name -contains 'rights') {
            [string]$record.rights.priorReference
        } else { '' }
        $priorDigest = Get-Sha256Hex -Bytes $script:Utf8NoBom.GetBytes($prior)
        if ($priorDigest -ne [string]$witness.priorReferenceDigest) {
            $errors.Add("pair $($index + 1): priorReferenceDigest mismatch")
        }
        if ($record.PSObject.Properties.Name -contains 'temporati') {
            $temporalDigest = Get-Sha256Hex -Bytes $script:Utf8NoBom.GetBytes((ConvertTo-CanonicalJson $record.temporati))
            if (-not ($witness.PSObject.Properties.Name -contains 'temporatiDigest') -or
                $temporalDigest -ne [string]$witness.temporatiDigest) {
                $errors.Add("pair $($index + 1): temporatiDigest mismatch")
            }
            if ([string]$record.temporati.verdict -notin @('guaranteed', 'violation-observed')) {
                $errors.Add("pair $($index + 1): invalid Temporati verdict")
            }
        }
    }
    [pscustomobject]@{
        Ledger = $Pair.Ledger; Witness = $Pair.Witness; Records = $recordItems.Count
        Witnesses = $witnessTest.Items.Count; Valid = ($errors.Count -eq 0); Errors = @($errors)
    }
}

function Get-StorePairs {
    param([Parameter(Mandatory)]$Paths)
    $pairs = @()
    if ($IncludeArchive) {
        foreach ($ledger in @(Get-ChildItem -LiteralPath $Paths.Archive -File -Filter 'record-through-g*.jsonl' |
            Sort-Object Name)) {
            $witnessName = $ledger.Name -replace '^record-through-', 'record-through-witness-'
            $witnessPath = Join-Path $Paths.Archive $witnessName
            $pairs += [pscustomobject]@{ Ledger = $ledger.FullName; Witness = $witnessPath }
        }
    }
    if (Test-Path -LiteralPath $Paths.Ledger) {
        $pairs += [pscustomobject]@{ Ledger = $Paths.Ledger; Witness = $Paths.Witness }
    }
    return @($pairs)
}

function Test-TemporatiContinuity {
    param([Parameter(Mandatory)][object[]]$Pairs)
    $errors = New-Object Collections.Generic.List[string]
    $priorRecord = $null
    $priorWitness = $null
    $checked = 0
    $witnessChecked = 0
    foreach ($pair in $Pairs) {
        $recordItems = New-Object Collections.Generic.List[object]
        foreach ($line in [IO.File]::ReadLines($pair.Ledger, $script:Utf8NoBom)) {
            if (-not [string]::IsNullOrWhiteSpace($line)) { $recordItems.Add(($line | ConvertFrom-Json)) }
        }
        $witnessItems = New-Object Collections.Generic.List[object]
        if (Test-Path -LiteralPath $pair.Witness) {
            foreach ($line in [IO.File]::ReadLines($pair.Witness, $script:Utf8NoBom)) {
                if (-not [string]::IsNullOrWhiteSpace($line)) { $witnessItems.Add(($line | ConvertFrom-Json)) }
            }
        }
        foreach ($record in $recordItems) {
            $checked++
            if ($null -ne $priorRecord) {
                if ([long]$record.sequence -ne ([long]$priorRecord.sequence + 1)) {
                    $errors.Add("sequence $($record.sequence): prior sequence is not continuous")
                }
                if ([string]$record.previousHash -ne [string]$priorRecord.hash) {
                    $errors.Add("sequence $($record.sequence): prior record hash is not continuous")
                }
                if ($record.PSObject.Properties.Name -contains 'temporati' -and
                    $priorRecord.PSObject.Properties.Name -contains 'temporati') {
                    $currentObserved = ConvertTo-UtcInstant -Value ([string]$record.temporati.observedUtc) -Name 'temporati.observedUtc'
                    $priorObserved = ConvertTo-UtcInstant -Value ([string]$priorRecord.temporati.observedUtc) -Name 'prior.temporati.observedUtc'
                    if ($currentObserved -lt $priorObserved.AddSeconds(-1 * [int]$record.temporati.maxClockRegressionSeconds)) {
                        $errors.Add("sequence $($record.sequence): observed time regressed beyond tolerance")
                    }
                    if ([string]$record.temporati.priorObservedUtc -ne $priorObserved.ToString('o')) {
                        $errors.Add("sequence $($record.sequence): priorObservedUtc does not match")
                    }
                }
            }
            $priorRecord = $record
        }
        foreach ($witness in $witnessItems) {
            $witnessChecked++
            if ($null -ne $priorWitness -and
                [string]$witness.previousWitnessHash -ne [string]$priorWitness.hash) {
                $errors.Add("witness sequence $($witness.sequence): prior witness hash is not continuous")
            }
            $priorWitness = $witness
        }
    }
    [pscustomobject]@{
        Ledger = '[all selected generations]'; Witness = '[all selected generations]'
        Records = $checked; Witnesses = $witnessChecked; Valid = ($errors.Count -eq 0); Errors = @($errors)
        Check = 'temporati-prior-continuity'
    }
}

$paths = Initialize-Store
switch ($Action) {
    'Record' {
        $result = Add-Record
        if ($PassThru) { $result } else {
            [pscustomobject]@{
                Recorded = $true
                Accord = 'primary-and-witness'
                Sequence = $result.Record.sequence
                RecordHash = $result.Record.hash
                WitnessHash = $result.Witness.hash
                Purpose = $result.Record.purpose
            }
        }
    }
    'Status' {
        $state = Read-State -Paths $paths
        $activeBytes = if (Test-Path -LiteralPath $paths.Ledger) { (Get-Item $paths.Ledger).Length } else { 0L }
        $witnessBytes = if (Test-Path -LiteralPath $paths.Witness) { (Get-Item $paths.Witness).Length } else { 0L }
        $archives = @(Get-ChildItem -LiteralPath $paths.Archive -File -Filter 'record-through-g*.jsonl')
        $witnessArchives = @(Get-ChildItem -LiteralPath $paths.Archive -File -Filter 'record-through-witness-g*.jsonl')
        [pscustomobject]@{
            Schema          = $script:Schema
            WitnessSchema   = $script:WitnessSchema
            Accord          = 'primary-and-witness'
            RootPath        = $RootPath
            Sequence        = $state.sequence
            Generation      = $state.generation
            CapacityBytes   = [long]$CapacityMB * 1MB
            ActiveBytes     = $activeBytes
            WitnessBytes    = $witnessBytes
            RemainingBytes  = [Math]::Max(0L, ([long]$CapacityMB * 1MB) - $activeBytes)
            WitnessRemainingBytes = [Math]::Max(0L, ([long]$CapacityMB * 1MB) - $witnessBytes)
            ArchiveFiles    = $archives.Count
            WitnessArchiveFiles = $witnessArchives.Count
            ArchiveBytes    = [long](($archives + $witnessArchives | Measure-Object Length -Sum).Sum)
            LastHash        = $state.lastHash
            LastWitnessHash = $state.witnessLastHash
            LastObservedUtc = $state.lastObservedUtc
            TemporalMode    = $TemporalMode
            TemporatiGuarantee = 'local-observation-order-and-hash-continuity'
        }
    }
    'Verify' {
        $pairs = Get-StorePairs -Paths $paths
        if ($pairs.Count -eq 0) { [pscustomobject]@{ Valid = $true; Records = 0; Message = 'No records.' }; break }
        $results = @($pairs | ForEach-Object { Test-AccordPair -Pair $_ })
        $results += Test-TemporatiContinuity -Pairs $pairs
        $results
        if (@($results | Where-Object { -not $_.Valid }).Count -gt 0) { $global:LASTEXITCODE = 2 }
    }
    'Export' {
        if ([string]::IsNullOrWhiteSpace($ExportPath)) { throw '-ExportPath is required for Export.' }
        $pairs = Get-StorePairs -Paths $paths
        $export = [ordered]@{
            schema      = 'record-through/export-v2'
            exportedUtc = [DateTime]::UtcNow.ToString('o')
            sourceRoot  = $RootPath
            records     = @($pairs | ForEach-Object {
                foreach ($line in [IO.File]::ReadLines($_.Ledger, $script:Utf8NoBom)) {
                    if (-not [string]::IsNullOrWhiteSpace($line)) { $line | ConvertFrom-Json }
                }
            })
            witnesses   = @($pairs | ForEach-Object {
                if (Test-Path -LiteralPath $_.Witness) {
                    foreach ($line in [IO.File]::ReadLines($_.Witness, $script:Utf8NoBom)) {
                        if (-not [string]::IsNullOrWhiteSpace($line)) { $line | ConvertFrom-Json }
                    }
                }
            })
        }
        if ($PSCmdlet.ShouldProcess($ExportPath, 'write record export')) {
            $parent = Split-Path -Parent $ExportPath
            if ($parent -and -not (Test-Path -LiteralPath $parent)) { [void](New-Item -ItemType Directory -Path $parent -Force) }
            [IO.File]::WriteAllText($ExportPath, ($export | ConvertTo-Json -Depth 20), $script:Utf8NoBom)
        }
        [pscustomobject]@{
            Exported = $true; Path = $ExportPath
            Records = $export.records.Count; Witnesses = $export.witnesses.Count
        }
    }
}
