#requires -Version 5.1
<#
.SYNOPSIS
    Windows notation-drive UI for the Record-Through accord.

.DESCRIPTION
    A local Windows Forms control panel for recording an annotated entry,
    verifying the accord, viewing guidance, and opening the record drive.
    It does not elevate privileges or collect data beyond fields the operator enters.
#>

[CmdletBinding()]
param(
    [string]$RootPath = (Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'RecordThrough')
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$script:IsWindowsPlatform = [Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT

if (-not $script:IsWindowsPlatform) { throw 'The notation-drive UI requires Windows PowerShell or PowerShell on Windows.' }
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$recordScript = Join-Path $PSScriptRoot 'PowerShell-Record-Through.ps1'
$verifyScript = Join-Path $PSScriptRoot 'PowerShell-Record-Through-Verify.ps1'
$rollerScript = Join-Path $PSScriptRoot 'PowerShell-Record-Through-Roller.ps1'
if (-not (Test-Path -LiteralPath $recordScript) -or -not (Test-Path -LiteralPath $verifyScript) -or
    -not (Test-Path -LiteralPath $rollerScript)) {
    throw 'Keep the UI beside the Record-Through core, verifier, and roller scripts.'
}

function Add-Label {
    param([string]$Text, [int]$Left, [int]$Top, [int]$Width = 130)
    $label = New-Object Windows.Forms.Label
    $label.Text = $Text; $label.Left = $Left; $label.Top = $Top; $label.Width = $Width
    $label.Height = 22; $label.TextAlign = 'MiddleLeft'
    $form.Controls.Add($label)
}

function Add-TextBox {
    param([int]$Left, [int]$Top, [int]$Width, [int]$Height = 24, [switch]$Multiline)
    $box = New-Object Windows.Forms.TextBox
    $box.Left = $Left; $box.Top = $Top; $box.Width = $Width; $box.Height = $Height
    $box.Multiline = [bool]$Multiline
    if ($Multiline) { $box.ScrollBars = 'Vertical' }
    $form.Controls.Add($box)
    return $box
}

function Add-Button {
    param([string]$Text, [int]$Left, [int]$Top, [int]$Width)
    $button = New-Object Windows.Forms.Button
    $button.Text = $Text; $button.Left = $Left; $button.Top = $Top; $button.Width = $Width; $button.Height = 32
    $form.Controls.Add($button)
    return $button
}

function Write-Status {
    param([string]$Text)
    $statusBox.Text = ('[{0}] {1}' -f [DateTimeOffset]::UtcNow.ToString('u'), $Text) + [Environment]::NewLine + $statusBox.Text
}

function Get-DataObject {
    $text = $dataBox.Text.Trim()
    if ([string]::IsNullOrWhiteSpace($text)) { return @{} }
    try {
        $object = $text | ConvertFrom-Json -ErrorAction Stop
        $table = @{}
        foreach ($property in $object.PSObject.Properties) { $table[$property.Name] = $property.Value }
        return $table
    } catch { throw 'Data must be a JSON object, for example: {"stage":"alpha","count":2}' }
}

$form = New-Object Windows.Forms.Form
$form.Text = 'Record-Through — Notation Drive'
$form.StartPosition = 'CenterScreen'
$form.Size = New-Object Drawing.Size(840, 770)
$form.MinimumSize = New-Object Drawing.Size(840, 770)
$form.Font = New-Object Drawing.Font('Segoe UI', 9)

Add-Label 'Notation drive' 16 18
$rootBox = Add-TextBox 150 16 640
$rootBox.Text = $RootPath
Add-Label 'Purpose' 16 54
$purposeBox = Add-TextBox 150 52 640
$purposeBox.Text = 'General'
Add-Label 'Message' 16 90
$messageBox = Add-TextBox 150 88 640 64 -Multiline
Add-Label 'Prior reference' 16 162
$priorBox = Add-TextBox 150 160 640
Add-Label 'Authority' 16 198
$authorityBox = Add-TextBox 150 196 300
$authorityBox.Text = 'self-declared'
Add-Label 'Rights annotation' 330 198 120
$rightsBox = Add-TextBox 450 196 340
$rightsBox.Text = 'record-owner-controlled'
Add-Label 'Event UTC (optional)' 16 234
$eventBox = Add-TextBox 150 232 250
$eventBox.Text = ''
Add-Label 'Data JSON' 415 234
$dataBox = Add-TextBox 485 232 305
$dataBox.Text = '{}'
Add-Label 'Temporal mode' 16 270
$modeBox = New-Object Windows.Forms.ComboBox
$modeBox.Left = 150; $modeBox.Top = 268; $modeBox.Width = 120
$modeBox.DropDownStyle = 'DropDownList'
[void]$modeBox.Items.Add('Strict'); [void]$modeBox.Items.Add('Observe'); $modeBox.SelectedIndex = 0
$form.Controls.Add($modeBox)
$includeArchive = New-Object Windows.Forms.CheckBox
$includeArchive.Text = 'Include archived generations during verification'
$includeArchive.Left = 300; $includeArchive.Top = 270; $includeArchive.Width = 310
$form.Controls.Add($includeArchive)
$requireAdmin = New-Object Windows.Forms.CheckBox
$requireAdmin.Text = 'Require administrator for verification'
$requireAdmin.Left = 610; $requireAdmin.Top = 270; $requireAdmin.Width = 200
$form.Controls.Add($requireAdmin)

Add-Label 'Roll count' 16 306
$rollCountBox = Add-TextBox 150 304 80
$rollCountBox.Text = '5'
Add-Label 'Interval seconds' 250 306 105
$rollIntervalBox = Add-TextBox 360 304 80
$rollIntervalBox.Text = '30'

$recordButton = Add-Button 'Write notation' 16 342 150
$rollerButton = Add-Button 'Run record roller' 176 342 150
$verifyButton = Add-Button 'Verify accord' 336 342 150
$driveButton = Add-Button 'Open notation drive' 496 342 170
$clearButton = Add-Button 'Clear status' 676 342 114

Add-Label 'Guidance and result' 16 392 180
$statusBox = Add-TextBox 16 416 774 290 -Multiline
$statusBox.ReadOnly = $true

$recordButton.Add_Click({
    try {
        $data = Get-DataObject
        $invoke = @{
            Action = 'Record'; RootPath = $rootBox.Text.Trim(); Purpose = $purposeBox.Text.Trim()
            Message = $messageBox.Text; Data = $data; PriorReference = $priorBox.Text.Trim()
            Authority = $authorityBox.Text.Trim(); Rights = $rightsBox.Text.Trim()
            EventTimeUtc = $eventBox.Text.Trim(); TemporalMode = [string]$modeBox.SelectedItem
            PassThru = $true; ErrorAction = 'Stop'
        }
        $outcome = & $recordScript @invoke
        Write-Status ("Notation written: sequence {0}; record {1}; witness {2}." -f $outcome.Record.sequence, $outcome.Record.hash, $outcome.Witness.hash)
    } catch { Write-Status ("WRITE BLOCKED: {0}" -f $_.Exception.Message) }
})

$rollerButton.Add_Click({
    try {
        $count = 0; $interval = 0
        if (-not [int]::TryParse($rollCountBox.Text, [ref]$count) -or $count -lt 1 -or $count -gt 10000) {
            throw 'Roll count must be between 1 and 10000.'
        }
        if (-not [int]::TryParse($rollIntervalBox.Text, [ref]$interval) -or $interval -lt 0 -or $interval -gt 86400) {
            throw 'Interval seconds must be between 0 and 86400.'
        }
        $data = Get-DataObject
        Write-Status "ROLLER START: $count records at $interval-second interval. The UI remains busy until the finite run completes."
        $invoke = @{
            RootPath = $rootBox.Text.Trim(); Purpose = $purposeBox.Text.Trim(); Message = $messageBox.Text
            Data = $data; PriorReference = $priorBox.Text.Trim(); Authority = $authorityBox.Text.Trim()
            Rights = $rightsBox.Text.Trim(); Count = $count; IntervalSeconds = $interval
            TemporalMode = [string]$modeBox.SelectedItem; VerifyAfter = $true; PassThru = $true; ErrorAction = 'Stop'
        }
        $result = & $rollerScript @invoke
        Write-Status ("ROLLER {0}: {1} recorded, {2} failed. Roll ID {3}." -f
            $(if ($result.Complete) { 'COMPLETE' } else { 'INCOMPLETE' }), $result.RecordedCount, $result.FailedCount, $result.RollerId)
        if ($null -ne $result.Verification) {
            Write-Status ("ROLLER VERIFY {0}." -f $result.Verification.overall.ToUpperInvariant())
        }
    } catch { Write-Status ("ROLLER BLOCKED: {0}" -f $_.Exception.Message) }
})

$verifyButton.Add_Click({
    try {
        $invoke = @{
            RootPath = $rootBox.Text.Trim(); IncludeArchive = $includeArchive.Checked
            RequireAdministrator = $requireAdmin.Checked; PassThru = $true; ErrorAction = 'Stop'
        }
        $report = & $verifyScript @invoke
        $failCount = @($report.checks | Where-Object { $_.Status -eq 'Fail' }).Count
        $warningCount = @($report.checks | Where-Object { $_.Status -eq 'Warn' }).Count
        Write-Status ("VERIFY {0}: {1} failed, {2} warnings." -f $report.overall.ToUpperInvariant(), $failCount, $warningCount)
        foreach ($item in $report.guidance) { Write-Status ("{0} — {1}: {2}" -f $item.Status, $item.Name, $item.Guidance) }
    } catch { Write-Status ("VERIFY BLOCKED: {0}" -f $_.Exception.Message) }
})

$driveButton.Add_Click({
    try {
        $drive = $rootBox.Text.Trim()
        if (-not (Test-Path -LiteralPath $drive)) { [void](New-Item -ItemType Directory -Path $drive -Force) }
        Start-Process -FilePath explorer.exe -ArgumentList @($drive)
        Write-Status "Opened notation drive: $drive"
    } catch { Write-Status ("OPEN DRIVE BLOCKED: {0}" -f $_.Exception.Message) }
})

$clearButton.Add_Click({ $statusBox.Clear() })
Write-Status 'Ready. Write a notation, then verify the accord. Rights are recorded as audit annotations.'
[void]$form.ShowDialog()
