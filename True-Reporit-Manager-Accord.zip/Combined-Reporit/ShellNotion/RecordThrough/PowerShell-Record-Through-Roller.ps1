#requires -Version 5.1
<#
.SYNOPSIS
    Finite, interval-based record roller for the Record-Through accord.

.DESCRIPTION
    Writes a bounded sequence of related annotations through the primary record,
    witness, rights, and Temporati checks. It is a foreground process: it does not
    install a task, service, daemon, or hidden loop. Every roll is individually
    verified by the core writer before the next roll begins.

.EXAMPLE
    .\PowerShell-Record-Through-Roller.ps1 -Purpose 'Build heartbeat' `
      -Message 'Build remains active' -Count 5 -IntervalSeconds 30 -VerifyAfter
#>

[CmdletBinding()]
param(
    [string]$RootPath = (Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'RecordThrough'),

    [ValidateNotNullOrEmpty()]
    [string]$Purpose = 'Roller',

    [AllowEmptyString()]
    [string]$Message = 'Rolling record',

    [hashtable]$Data = @{},

    [AllowEmptyString()]
    [string]$PriorReference = '',

    [ValidateNotNullOrEmpty()]
    [string]$Authority = 'self-declared',

    [ValidateNotNullOrEmpty()]
    [string]$Rights = 'record-owner-controlled',

    [ValidateSet('affirmed', 'not-required', 'withheld')]
    [string]$Consent = 'affirmed',

    [ValidateNotNullOrEmpty()]
    [string]$Retention = 'bounded-by-capacity',

    [ValidateRange(1, 10000)]
    [int]$Count = 5,

    [ValidateRange(0, 86400)]
    [int]$IntervalSeconds = 30,

    [ValidateSet('Strict', 'Observe')]
    [string]$TemporalMode = 'Strict',

    [switch]$ContinueOnError,

    [switch]$VerifyAfter,

    [switch]$PassThru
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$recordScript = Join-Path $PSScriptRoot 'PowerShell-Record-Through.ps1'
$verifyScript = Join-Path $PSScriptRoot 'PowerShell-Record-Through-Verify.ps1'
if (-not (Test-Path -LiteralPath $recordScript)) { throw "Core accord script is missing: $recordScript" }

$rollId = [Guid]::NewGuid().ToString('N')
$outcomes = New-Object Collections.Generic.List[object]
$intervalMs = [Math]::Min(86400000, $IntervalSeconds * 1000)

for ($index = 1; $index -le $Count; $index++) {
    $rollData = @{}
    foreach ($key in $Data.Keys) { $rollData[$key] = $Data[$key] }
    $rollData['rollerId'] = $rollId
    $rollData['rollerIndex'] = $index
    $rollData['rollerCount'] = $Count
    $rollData['rollerIntervalSeconds'] = $IntervalSeconds

    $rollMessage = if ([string]::IsNullOrWhiteSpace($Message)) {
        "Record roller $index of $Count"
    } else { "$Message [roll $index/$Count]" }

    try {
        $invoke = @{
            Action = 'Record'; RootPath = $RootPath; Purpose = $Purpose; Message = $rollMessage
            Data = $rollData; PriorReference = $PriorReference; Authority = $Authority; Rights = $Rights
            Consent = $Consent; Retention = $Retention; TemporalMode = $TemporalMode
            MinimumIntervalMilliseconds = $intervalMs; PassThru = $true; ErrorAction = 'Stop'
        }
        $result = & $recordScript @invoke
        $outcomes.Add([pscustomobject]@{
            Index = $index; Status = 'recorded'; Sequence = $result.Record.sequence
            RecordHash = $result.Record.hash; WitnessHash = $result.Witness.hash; Error = ''
        })
    } catch {
        $outcomes.Add([pscustomobject]@{
            Index = $index; Status = 'failed'; Sequence = $null; RecordHash = ''; WitnessHash = ''
            Error = $_.Exception.Message
        })
        if (-not $ContinueOnError) { break }
    }

    if ($index -lt $Count -and $IntervalSeconds -gt 0) { Start-Sleep -Seconds $IntervalSeconds }
}

$verification = $null
if ($VerifyAfter) {
    if (-not (Test-Path -LiteralPath $verifyScript)) { throw "Verification script is missing: $verifyScript" }
    $verification = & $verifyScript -RootPath $RootPath -PassThru -ErrorAction Stop
}

$failed = @($outcomes | Where-Object { $_.Status -eq 'failed' })
$summary = [pscustomobject]@{
    Schema = 'record-through-roller/v1'
    RollerId = $rollId
    RequestedCount = $Count
    RecordedCount = @($outcomes | Where-Object { $_.Status -eq 'recorded' }).Count
    FailedCount = $failed.Count
    Complete = ($outcomes.Count -eq $Count -and $failed.Count -eq 0)
    Outcomes = @($outcomes)
    Verification = $verification
}

if ($failed.Count -gt 0) { $global:LASTEXITCODE = 2 }
if ($PassThru) { $summary } else {
    [pscustomobject]@{
        RollerId = $summary.RollerId; Complete = $summary.Complete
        RecordedCount = $summary.RecordedCount; FailedCount = $summary.FailedCount
    }
}
