#requires -Version 5.1
<#
.SYNOPSIS
    Start-to-finish verification and guidance procedure for Record-Through.

.DESCRIPTION
    Checks the Record-Through accord from its local store outward:
      1. verifier identity and optional administrator requirement;
      2. required ledger, witness, state, and archive properties;
      3. configured capacity of the active primary and witness files;
      4. primary, witness, rights, and Temporati verification through the
         accompanying PowerShell-Record-Through.ps1 script;
      5. actionable guidance for every failure or warning.

    Administrator status is inspected but never bypassed or elevated. Rights
    fields remain audit declarations; they do not grant or determine legal rights.

.EXAMPLE
    .\PowerShell-Record-Through-Verify.ps1 -RootPath C:\RecordThrough -IncludeArchive

.EXAMPLE
    .\PowerShell-Record-Through-Verify.ps1 -RequireAdministrator -CapacityMB 32 `
      -IncludeArchive -ReportPath .\record-through-verification.json
#>

[CmdletBinding()]
param(
    [string]$RootPath = (Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'RecordThrough'),

    [ValidateRange(1, 4096)]
    [int]$CapacityMB = 32,

    [switch]$IncludeArchive,

    [switch]$RequireAdministrator,

    [switch]$RequireNoBroadWrite,

    [string]$ReportPath,

    [switch]$PassThru
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$script:IsWindowsPlatform = [Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT

function New-Check {
    param(
        [Parameter(Mandatory)][ValidateSet('Pass', 'Fail', 'Warn', 'Info')][string]$Status,
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Evidence,
        [Parameter(Mandatory)][string]$Guidance
    )
    [pscustomobject]@{ Status = $Status; Name = $Name; Evidence = $Evidence; Guidance = $Guidance }
}

function Test-Administrator {
    if (-not $script:IsWindowsPlatform) {
        return [pscustomobject]@{ Supported = $false; IsAdministrator = $false; Identity = [Environment]::UserName }
    }
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    [pscustomobject]@{
        Supported = $true
        IsAdministrator = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        Identity = $identity.Name
    }
}

function Get-BroadWriteFinding {
    param([Parameter(Mandatory)][string]$Path)
    if (-not $script:IsWindowsPlatform) { return $null }
    try {
        $risky = @(Get-Acl -LiteralPath $Path | Select-Object -ExpandProperty Access | Where-Object {
            $_.AccessControlType -eq 'Allow' -and
            $_.IdentityReference.Value -match '(^|\\)(Everyone|Users|Authenticated Users)$' -and
            ($_.FileSystemRights.ToString() -match 'FullControl|Modify|Write')
        })
        return $risky
    } catch { return @("ACL inspection failed: $($_.Exception.Message)") }
}

$scriptPath = Join-Path $PSScriptRoot 'PowerShell-Record-Through.ps1'
$ledgerPath = Join-Path $RootPath 'record-through.jsonl'
$witnessPath = Join-Path $RootPath 'record-through.witness.jsonl'
$statePath = Join-Path $RootPath 'record-through.state.json'
$archivePath = Join-Path $RootPath 'archive'
$checks = New-Object Collections.Generic.List[object]

if (-not (Test-Path -LiteralPath $scriptPath)) {
    throw "Required accord script is missing: $scriptPath"
}

$admin = Test-Administrator
if (-not $admin.Supported) {
    $checks.Add((New-Check -Status 'Info' -Name 'administrator-status' -Evidence 'Administrator check is Windows-only.' -Guidance 'Run this procedure on Windows to evaluate Windows administrator status.'))
} elseif ($admin.IsAdministrator) {
    $checks.Add((New-Check -Status 'Pass' -Name 'administrator-status' -Evidence "Running as $($admin.Identity)." -Guidance 'No administrator action is required.'))
} elseif ($RequireAdministrator) {
    $checks.Add((New-Check -Status 'Fail' -Name 'administrator-status' -Evidence "Running as $($admin.Identity), without Administrator membership." -Guidance 'Open PowerShell with Run as administrator, then rerun the verifier.'))
} else {
    $checks.Add((New-Check -Status 'Warn' -Name 'administrator-status' -Evidence "Running as $($admin.Identity), without Administrator membership." -Guidance 'Administrator rights are not required for read-only verification; use an elevated prompt only if your policy requires it.'))
}

if (-not (Test-Path -LiteralPath $RootPath)) {
    $checks.Add((New-Check -Status 'Fail' -Name 'store-root' -Evidence "Missing: $RootPath" -Guidance 'Create records first or pass the correct -RootPath.'))
} else {
    $checks.Add((New-Check -Status 'Pass' -Name 'store-root' -Evidence $RootPath -Guidance 'Store root is present.'))
    foreach ($required in @(
        [pscustomobject]@{ Name = 'primary-ledger'; Path = $ledgerPath },
        [pscustomobject]@{ Name = 'witness-ledger'; Path = $witnessPath },
        [pscustomobject]@{ Name = 'state'; Path = $statePath }
    )) {
        if (Test-Path -LiteralPath $required.Path) {
            $checks.Add((New-Check -Status 'Pass' -Name $required.Name -Evidence $required.Path -Guidance 'Required accord property is present.'))
        } else {
            $checks.Add((New-Check -Status 'Fail' -Name $required.Name -Evidence "Missing: $($required.Path)" -Guidance 'Do not fabricate this file. Restore it from a verified backup or begin a new ledger.'))
        }
    }

    $capacityBytes = [long]$CapacityMB * 1MB
    foreach ($active in @(
        [pscustomobject]@{ Name = 'primary-capacity'; Path = $ledgerPath },
        [pscustomobject]@{ Name = 'witness-capacity'; Path = $witnessPath }
    )) {
        if (Test-Path -LiteralPath $active.Path) {
            $length = (Get-Item -LiteralPath $active.Path).Length
            if ($length -le $capacityBytes) {
                $checks.Add((New-Check -Status 'Pass' -Name $active.Name -Evidence "$length of $capacityBytes bytes used." -Guidance 'Capacity is within the configured bound.'))
            } else {
                $checks.Add((New-Check -Status 'Fail' -Name $active.Name -Evidence "$length of $capacityBytes bytes used." -Guidance 'Stop writing, preserve the evidence, and rotate or archive through the accord policy.'))
            }
        }
    }

    if (Test-Path -LiteralPath $archivePath) {
        $checks.Add((New-Check -Status 'Pass' -Name 'archive-directory' -Evidence $archivePath -Guidance 'Archive directory is present.'))
    } elseif ($IncludeArchive) {
        $checks.Add((New-Check -Status 'Warn' -Name 'archive-directory' -Evidence "Missing: $archivePath" -Guidance 'No archived generations can be included until the archive directory exists.'))
    }

    $broadWrite = Get-BroadWriteFinding -Path $RootPath
    if ($null -eq $broadWrite) {
        $checks.Add((New-Check -Status 'Info' -Name 'store-acl' -Evidence 'ACL broad-write check is Windows-only.' -Guidance 'Use NTFS ACL review on Windows when your policy requires it.'))
    } elseif ($broadWrite.Count -eq 0) {
        $checks.Add((New-Check -Status 'Pass' -Name 'store-acl' -Evidence 'No broad write grant was detected for Everyone, Users, or Authenticated Users.' -Guidance 'Keep the store writable only by intended operators.'))
    } elseif ($RequireNoBroadWrite) {
        $checks.Add((New-Check -Status 'Fail' -Name 'store-acl' -Evidence ($broadWrite | Out-String).Trim() -Guidance 'Restrict broad write permissions after confirming the intended owners and backup plan.'))
    } else {
        $checks.Add((New-Check -Status 'Warn' -Name 'store-acl' -Evidence ($broadWrite | Out-String).Trim() -Guidance 'Review broad write permissions; enable -RequireNoBroadWrite to make this a failure.'))
    }
}

$accordResults = @()
if ((Test-Path -LiteralPath $ledgerPath) -and (Test-Path -LiteralPath $witnessPath)) {
    try {
        $invoke = @{ Action = 'Verify'; RootPath = $RootPath; ErrorAction = 'Stop' }
        if ($IncludeArchive) { $invoke['IncludeArchive'] = $true }
        $accordResults = @(& $scriptPath @invoke)
        foreach ($result in $accordResults) {
            if ($result.Valid) {
                $checks.Add((New-Check -Status 'Pass' -Name 'accord-integrity' -Evidence "Verified $($result.Records) records and $($result.Witnesses) witnesses: $($result.Ledger)" -Guidance 'Accord links, receipts, and selected Temporati continuity checks passed.'))
            } else {
                $detail = @($result.Errors) -join '; '
                $checks.Add((New-Check -Status 'Fail' -Name 'accord-integrity' -Evidence $detail -Guidance 'Preserve the files unchanged, export a copy, identify the first failing generation, and restore only from verified evidence.'))
            }
        }
    } catch {
        $checks.Add((New-Check -Status 'Fail' -Name 'accord-execution' -Evidence $_.Exception.Message -Guidance 'Confirm the companion script is intact and rerun from a PowerShell 5.1 or newer environment.'))
    }
}

$failed = @($checks | Where-Object { $_.Status -eq 'Fail' })
$warnings = @($checks | Where-Object { $_.Status -eq 'Warn' })
$report = [ordered]@{
    schema = 'record-through-verification/v1'
    verifiedUtc = [DateTimeOffset]::UtcNow.ToString('o')
    overall = if ($failed.Count -gt 0) { 'fail' } elseif ($warnings.Count -gt 0) { 'warn' } else { 'pass' }
    properties = [ordered]@{
        rootPath = $RootPath
        capacityMB = $CapacityMB
        includeArchive = [bool]$IncludeArchive
        requireAdministrator = [bool]$RequireAdministrator
        requireNoBroadWrite = [bool]$RequireNoBroadWrite
        administrator = $admin
    }
    checks = @($checks)
    accord = @($accordResults)
    guidance = @($checks | Where-Object { $_.Status -ne 'Pass' } | Select-Object Status, Name, Guidance)
}

if (-not [string]::IsNullOrWhiteSpace($ReportPath)) {
    $parent = Split-Path -Parent $ReportPath
    if ($parent -and -not (Test-Path -LiteralPath $parent)) { [void](New-Item -ItemType Directory -Path $parent -Force) }
    [IO.File]::WriteAllText($ReportPath, ($report | ConvertTo-Json -Depth 20), (New-Object System.Text.UTF8Encoding($false)))
}

if ($failed.Count -gt 0) { $global:LASTEXITCODE = 2 }
if ($PassThru) { [pscustomobject]$report } else {
    [pscustomobject]@{
        Overall = $report.overall
        FailedChecks = $failed.Count
        WarningChecks = $warnings.Count
        Guidance = $report.guidance
        ReportPath = $ReportPath
    }
}
