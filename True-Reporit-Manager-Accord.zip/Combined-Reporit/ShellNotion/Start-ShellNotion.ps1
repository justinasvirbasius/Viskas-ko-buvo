#requires -Version 5.1
[CmdletBinding()]
param([switch]$ListWindows)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$manifest = Join-Path $PSScriptRoot 'ShellNotion.psd1'
Import-Module $manifest -Force -ErrorAction Stop
Start-ShellNotion -ListWindows:$ListWindows
