# ShellNotion

ShellNotion is a governance module around ordinary PowerShell. It keeps normal scriptblock semantics and adds explicit dry-run analysis, stream inspection, Windows window controls, policy gates, and Record-Through evidence.

It is not a replacement PowerShell engine, a security boundary, or a legal authority. It does not elevate privileges, install a service, enable remoting, or bypass execution policy.

## Start

```powershell
Set-ExecutionPolicy -Scope Process RemoteSigned
Import-Module .\ShellNotion.psd1 -Force
Start-ShellNotion
```

`Set-ExecutionPolicy` is optional and should only be used when local policy permits the downloaded script. You can instead unblock or sign the files according to your Windows policy.

## Categories

| Category | Command | Function |
| --- | --- | --- |
| Shadow | `Test-SNShadow` | Parses commands and classifies risk without executing. |
| Current | `Get-SNCurrent` | Shows process, host, identity, language mode, policy, and accord root. |
| Light | `Get-SNLight` | Reports module, policy, verifier, and Windows readiness. |
| Echoscopy | `Invoke-SNEchoscopy` | Executes committed scriptblocks, classifies streams, and records an output digest. |
| Currents | `Get-SNCurrents` | Documents PowerShell's success, error, warning, verbose, debug, information, and progress streams. |
| Window | `Get-SNWindow`, `Set-SNWindowState`, `Move-SNWindow` | Lists and controls existing top-level Windows windows. |
| ForwardPass | `Invoke-SNForwardPass`, `Test-SNForwardPass` | Integrates once-was/current/forward snapshots, process/service expectations, annotated graphs, September matrices, Gavornricht governance, and blind-through commitments. |
| Gits | `Import-Module ..\Gits\Gits.psd1` | Separate local repository accord; see `..\Gits\README.md`. |
| Reporitor | `Import-Module ..\Reporitor\Reporitor.psd1` | Separate GitHub manager and reporting bot; see `..\Reporitor\README.md`. |
| Accord | `Write-SNNotation`, `Test-SNAccord` | Writes and verifies double-notion Record-Through evidence. |

## Shadow and echoscopy

```powershell
$shadow = Test-SNShadow { Get-Process | Sort-Object CPU -Descending }

Invoke-SNEchoscopy -Name 'process-view' `
  -ScriptBlock { Get-Process | Sort-Object CPU -Descending | Select-Object -First 10 } `
  -Commit -IncludeOutput
```

No command runs without `-Commit`. Commands listed as elevated risk in `ShellNotion.policy.json` also require `-AllowElevatedRisk`. Commands listed as blocked cannot be committed until the policy changes.

Dynamic commands and invocation operators require `-AllowReviewRisk` after inspection. Each committed echoscopy writes an intent receipt before execution and a result receipt afterward; if the Record-Through accord is disabled or unavailable, governed execution fails closed.

Echoscopy records the command hash, duration, stream counts, output digest, and accord receipt. Raw output is returned only with `-IncludeOutput` and is never written to Record-Through by default.

## Govern windows

```powershell
$window = Get-SNWindow -Title 'Notepad' | Select-Object -First 1
$window | Set-SNWindowState -State Restore          # preview
$window | Set-SNWindowState -State Restore -Commit  # apply
$window | Move-SNWindow -X 40 -Y 40 -Width 1000 -Height 700 -Commit
```

Window controls require Windows, a valid current window handle, policy permission, and explicit commitment. They do not launch, terminate, inject into, or read the content of another process.

## Accord root

By default, evidence is written beneath `%LOCALAPPDATA%\RecordThrough`. To choose another root for the current session:

```powershell
$env:SHELLNOTION_RECORD_ROOT = 'D:\Accords\RecordThrough'
```

Then use:

```powershell
Write-SNNotation -Purpose 'Build' -Message 'Stage completed' -PriorReference 'stage-7'
Test-SNAccord -IncludeArchive
```

## Self-test

```powershell
.\Test-ShellNotion.ps1
.\Test-ShellNotion.ps1 -CommitProbe
```

The default test is read-only. `-CommitProbe` executes a small local scriptblock and writes an accord receipt.

## Forward Pass integration

```powershell
Invoke-SNForwardPass -HumanNote 'Start renderer' `
  -AssistantProposal 'Check the next capture' `
  -ExpectedProcess renderer -Commit

Test-SNForwardPass
```

Pass `-GraphGroup`, `-GraphLink`, and `-CategoryAnnotation` to validate and record the annotation topology. Pass `-SeptemberMatrix` cells and `-GavornRicht` governance rules to bind matrix weights to the prior record. Each matrix requires at least one governance rule. The script-environment annotation is data-only and evaluation-disabled. Snapshot records and readable Markdown reports live under `%LOCALAPPDATA%\ForwardPass` by default; set `SHELLNOTION_FORWARD_ROOT` to select another location.

The snapshot reports machine observations. Human notes and assistant proposals are labeled as supplied, not machine-verified. Forward expectations remain proposals until the next capture checks them.
