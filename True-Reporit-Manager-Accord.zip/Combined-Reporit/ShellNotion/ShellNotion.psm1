#requires -Version 5.1
Set-StrictMode -Version Latest
$script:ModuleRoot = $PSScriptRoot
$script:PolicyPath = Join-Path $PSScriptRoot 'ShellNotion.policy.json'
$script:RecordScript = Join-Path $PSScriptRoot 'RecordThrough\PowerShell-Record-Through.ps1'
$script:VerifyScript = Join-Path $PSScriptRoot 'RecordThrough\PowerShell-Record-Through-Verify.ps1'
$script:ForwardPassScript = Join-Path $PSScriptRoot 'ForwardPass\PowerShell-Forward-Pass.ps1'
$script:GitsManifest = Join-Path $PSScriptRoot '..\Gits\Gits.psd1'
$script:ReporitorManifest = Join-Path $PSScriptRoot '..\Reporitor\Reporitor.psd1'
$script:IsWindowsPlatform = [Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT
$script:Utf8NoBom = New-Object Text.UTF8Encoding($false)

function Get-SNHashText {
    param([Parameter(Mandatory)][AllowEmptyString()][string]$Text)
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        return -join ($sha.ComputeHash($script:Utf8NoBom.GetBytes($Text)) | ForEach-Object { $_.ToString('x2') })
    } finally { $sha.Dispose() }
}

function Get-SNRecordRoot {
    if (-not [string]::IsNullOrWhiteSpace($env:SHELLNOTION_RECORD_ROOT)) {
        return $env:SHELLNOTION_RECORD_ROOT
    }
    return Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'RecordThrough'
}

function Get-SNPolicy {
    [CmdletBinding()]
    param()
    if (-not (Test-Path -LiteralPath $script:PolicyPath)) {
        throw "ShellNotion policy is missing: $script:PolicyPath"
    }
    Get-Content -LiteralPath $script:PolicyPath -Raw -Encoding UTF8 | ConvertFrom-Json
}

function Get-SNCategory {
    [CmdletBinding()]
    param()
    @(
        [pscustomobject]@{ Name = 'Shadow'; Purpose = 'Parse and classify a scriptblock without executing it.'; Mutates = $false },
        [pscustomobject]@{ Name = 'Current'; Purpose = 'Describe the live PowerShell process, runspace, identity, and policy.'; Mutates = $false },
        [pscustomobject]@{ Name = 'Light'; Purpose = 'Expose diagnostics and readiness signals.'; Mutates = $false },
        [pscustomobject]@{ Name = 'Echoscopy'; Purpose = 'Execute only after commitment and classify every emitted PowerShell stream.'; Mutates = $true },
        [pscustomobject]@{ Name = 'Currents'; Purpose = 'Document and govern Success, Error, Warning, Verbose, Debug, Information, and Progress currents.'; Mutates = $false },
        [pscustomobject]@{ Name = 'Window'; Purpose = 'List, move, restore, minimize, maximize, show, or hide top-level Windows windows.'; Mutates = $true },
        [pscustomobject]@{ Name = 'ForwardPass'; Purpose = 'Capture once-was, happening-now, prior expectations, annotation graphs, matrix governance, and forward proposals.'; Mutates = $true },
        [pscustomobject]@{ Name = 'Gits'; Purpose = 'Separate repository accord for Git state, local mutations, and hash-linked audit evidence.'; Mutates = $true },
        [pscustomobject]@{ Name = 'Reporitor'; Purpose = 'Separate GitHub repository manager and finite reporting bot with its own hash-linked accord.'; Mutates = $true },
        [pscustomobject]@{ Name = 'Accord'; Purpose = 'Write and verify Record-Through evidence.'; Mutates = $true }
    )
}

function Test-SNAdministrator {
    if (-not $script:IsWindowsPlatform) { return $false }
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-SNCurrent {
    [CmdletBinding()]
    param()
    [pscustomobject]@{
        Schema = 'shell-notion-current/v1'
        TimestampUtc = [DateTimeOffset]::UtcNow.ToString('o')
        ProcessId = $PID
        User = [Environment]::UserName
        Machine = [Environment]::MachineName
        IsWindows = $script:IsWindowsPlatform
        IsAdministrator = Test-SNAdministrator
        PowerShellVersion = $PSVersionTable.PSVersion.ToString()
        Edition = if ($PSVersionTable.PSObject.Properties.Name -contains 'PSEdition') { $PSVersionTable.PSEdition } else { 'Desktop' }
        Host = $Host.Name
        LanguageMode = $ExecutionContext.SessionState.LanguageMode.ToString()
        ExecutionPolicy = if ($script:IsWindowsPlatform) { Get-ExecutionPolicy } else { 'NotApplicable' }
        WorkingDirectory = (Get-Location).Path
        ModuleRoot = $script:ModuleRoot
        AccordRoot = Get-SNRecordRoot
    }
}

function Get-SNLight {
    [CmdletBinding()]
    param()
    $policyReady = $false
    try { $null = Get-SNPolicy; $policyReady = $true } catch { $policyReady = $false }
    $recordReady = Test-Path -LiteralPath $script:RecordScript
    $verifyReady = Test-Path -LiteralPath $script:VerifyScript
    $forwardReady = Test-Path -LiteralPath $script:ForwardPassScript
    $gitsReady = Test-Path -LiteralPath $script:GitsManifest
    $reporitorReady = Test-Path -LiteralPath $script:ReporitorManifest
    $windowReady = $script:IsWindowsPlatform
    $signals = @(
        [pscustomobject]@{ Signal = 'Policy'; Ready = $policyReady; Guidance = if ($policyReady) { 'Loaded.' } else { 'Restore ShellNotion.policy.json.' } },
        [pscustomobject]@{ Signal = 'RecordThrough'; Ready = $recordReady; Guidance = if ($recordReady) { 'Writer available.' } else { 'Keep the RecordThrough folder beside the module.' } },
        [pscustomobject]@{ Signal = 'Verification'; Ready = $verifyReady; Guidance = if ($verifyReady) { 'Verifier available.' } else { 'Restore the Record-Through verifier.' } },
        [pscustomobject]@{ Signal = 'ForwardPass'; Ready = $forwardReady; Guidance = if ($forwardReady) { 'Forward Pass capture and verification available.' } else { 'Keep PowerShell-Forward-Pass.ps1 in the ForwardPass folder.' } },
        [pscustomobject]@{ Signal = 'Gits'; Ready = $gitsReady; Guidance = if ($gitsReady) { 'Separate repository accord available.' } else { 'Keep the Gits folder beside ShellNotion.' } },
        [pscustomobject]@{ Signal = 'Reporitor'; Ready = $reporitorReady; Guidance = if ($reporitorReady) { 'Separate GitHub repository manager available.' } else { 'Keep the Reporitor folder beside ShellNotion.' } },
        [pscustomobject]@{ Signal = 'WindowApi'; Ready = $windowReady; Guidance = if ($windowReady) { 'Windows controls available.' } else { 'Window controls require Windows.' } }
    )
    [pscustomobject]@{
        Schema = 'shell-notion-light/v1'
        Ready = @($signals | Where-Object { -not $_.Ready }).Count -eq 0
        Signals = $signals
        Current = Get-SNCurrent
    }
}

function Get-SNCurrents {
    [CmdletBinding()]
    param()
    @(
        [pscustomobject]@{ Number = 1; Name = 'Success'; Preference = 'Pipeline'; Meaning = 'Ordinary objects'; EchoscopyType = 'Success' },
        [pscustomobject]@{ Number = 2; Name = 'Error'; Preference = 'ErrorActionPreference'; Meaning = 'ErrorRecord objects'; EchoscopyType = 'Error' },
        [pscustomobject]@{ Number = 3; Name = 'Warning'; Preference = 'WarningPreference'; Meaning = 'Warnings'; EchoscopyType = 'Warning' },
        [pscustomobject]@{ Number = 4; Name = 'Verbose'; Preference = 'VerbosePreference'; Meaning = 'Detailed operation messages'; EchoscopyType = 'Verbose' },
        [pscustomobject]@{ Number = 5; Name = 'Debug'; Preference = 'DebugPreference'; Meaning = 'Developer diagnostics'; EchoscopyType = 'Debug' },
        [pscustomobject]@{ Number = 6; Name = 'Information'; Preference = 'InformationPreference'; Meaning = 'Information and host messages'; EchoscopyType = 'Information' },
        [pscustomobject]@{ Number = 0; Name = 'Progress'; Preference = 'ProgressPreference'; Meaning = 'Transient progress state'; EchoscopyType = 'Not captured by ordinary redirection' }
    )
}

function Test-SNShadow {
    [CmdletBinding()]
    param([Parameter(Mandatory, ValueFromPipeline)][scriptblock]$ScriptBlock)
    process {
        $policy = Get-SNPolicy
        $text = $ScriptBlock.ToString()
        $tokens = $null
        $parseErrors = $null
        $ast = [System.Management.Automation.Language.Parser]::ParseInput($text, [ref]$tokens, [ref]$parseErrors)
        $commands = @($ast.FindAll({
            param($node)
            $node -is [System.Management.Automation.Language.CommandAst]
        }, $true) | ForEach-Object { $_.GetCommandName() } | Where-Object { $_ } | Sort-Object -Unique)
        $dynamicCommands = @($ast.FindAll({
            param($node)
            $node -is [System.Management.Automation.Language.CommandAst] -and [string]::IsNullOrWhiteSpace($node.GetCommandName())
        }, $true)).Count
        $blocked = @($commands | Where-Object { $policy.execution.blockedCommands -contains $_ })
        $elevated = @($commands | Where-Object { $policy.execution.elevatedRiskCommands -contains $_ })
        $hasInvocationOperator = @($ast.FindAll({
            param($node)
            $node -is [System.Management.Automation.Language.CommandAst] -and
                $node.InvocationOperator -in @(
                    [System.Management.Automation.Language.TokenKind]::Ampersand,
                    [System.Management.Automation.Language.TokenKind]::Dot
                )
        }, $true)).Count -gt 0
        $risk = if (@($parseErrors).Count -gt 0 -or $blocked.Count -gt 0) {
            'Blocked'
        } elseif ($elevated.Count -gt 0) {
            'Elevated'
        } elseif ($dynamicCommands -gt 0 -or $hasInvocationOperator) {
            'Review'
        } else { 'Standard' }
        [pscustomobject]@{
            Schema = 'shell-notion-shadow/v1'
            CommandHash = Get-SNHashText -Text $text
            Risk = $risk
            Commands = $commands
            BlockedCommands = $blocked
            ElevatedRiskCommands = $elevated
            DynamicCommandCount = $dynamicCommands
            HasInvocationOperator = $hasInvocationOperator
            ParseErrors = @($parseErrors | ForEach-Object { $_.Message })
            Executed = $false
            Guidance = switch ($risk) {
                'Blocked' { 'Correct parse errors or change the policy; blocked commands cannot be committed.' }
                'Elevated' { 'Inspect the exact targets and add -AllowElevatedRisk only when the mutation is intended.' }
                'Review' { 'Resolve dynamic commands and invocation operators before commitment when possible.' }
                default { 'Use Invoke-SNEchoscopy -Commit to execute under the accord.' }
            }
        }
    }
}

function Get-SNStreamName {
    param($InputObject)
    if ($InputObject -is [System.Management.Automation.ErrorRecord]) { return 'Error' }
    if ($InputObject -is [System.Management.Automation.WarningRecord]) { return 'Warning' }
    if ($InputObject -is [System.Management.Automation.VerboseRecord]) { return 'Verbose' }
    if ($InputObject -is [System.Management.Automation.DebugRecord]) { return 'Debug' }
    if ($InputObject -is [System.Management.Automation.InformationRecord]) { return 'Information' }
    return 'Success'
}

function Write-SNAccordInternal {
    param(
        [Parameter(Mandatory)][string]$Category,
        [Parameter(Mandatory)][string]$Message,
        [Parameter(Mandatory)][hashtable]$Data,
        [Parameter(Mandatory)][string]$PriorReference
    )
    $policy = Get-SNPolicy
    if (-not [bool]$policy.accord.enabled) {
        throw 'Record-Through accord is disabled by policy; governed operations fail closed.'
    }
    if (-not (Test-Path -LiteralPath $script:RecordScript)) {
        throw "Record-Through writer is unavailable: $script:RecordScript"
    }
    & $script:RecordScript -Action Record -RootPath (Get-SNRecordRoot) `
        -Purpose "ShellNotion/$Category" -Message $Message -Data $Data `
        -PriorReference $PriorReference -Authority ([string]$policy.accord.authority) `
        -Rights ([string]$policy.accord.rights) -Retention ([string]$policy.accord.retention) `
        -TemporalMode Strict -PassThru -ErrorAction Stop
}

function Invoke-SNEchoscopy {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory, ValueFromPipeline)][scriptblock]$ScriptBlock,
        [string]$Name = 'unnamed-operation',
        [switch]$Commit,
        [switch]$AllowElevatedRisk,
        [switch]$AllowReviewRisk,
        [switch]$IncludeOutput
    )
    process {
        $policy = Get-SNPolicy
        $shadow = Test-SNShadow -ScriptBlock $ScriptBlock
        $operationId = [Guid]::NewGuid().ToString('N')
        if ($shadow.Risk -eq 'Blocked') {
            throw "Shadow blocked the operation. $($shadow.Guidance)"
        }
        if ($shadow.Risk -eq 'Elevated' -and -not $AllowElevatedRisk) {
            throw "Elevated-risk command detected: $($shadow.ElevatedRiskCommands -join ', '). Inspect targets, then use -AllowElevatedRisk if intended."
        }
        if ($shadow.Risk -eq 'Review' -and -not $AllowReviewRisk) {
            throw 'Shadow found a dynamic command or invocation operator. Inspect the exact target, then pass -AllowReviewRisk if intended.'
        }
        if (-not $Commit) {
            $null = Write-SNAccordInternal -Category 'Shadow' -Message "Shadowed $Name without execution." `
                -Data @{ operationId = $operationId; commandHash = $shadow.CommandHash; risk = $shadow.Risk; executed = $false } `
                -PriorReference $operationId
            return [pscustomobject]@{ OperationId = $operationId; Executed = $false; Shadow = $shadow; Guidance = 'Add -Commit to execute.' }
        }
        if (-not $PSCmdlet.ShouldProcess($Name, 'Execute scriptblock under ShellNotion echoscopy')) {
            return [pscustomobject]@{ OperationId = $operationId; Executed = $false; Shadow = $shadow; Guidance = 'ShouldProcess declined execution.' }
        }

        $intent = Write-SNAccordInternal -Category 'EchoscopyIntent' -Message "Authorized execution intent for $Name." `
            -Data @{ operationId = $operationId; commandHash = $shadow.CommandHash; risk = $shadow.Risk; elevatedRiskAcknowledged = [bool]$AllowElevatedRisk; reviewRiskAcknowledged = [bool]$AllowReviewRisk } `
            -PriorReference $operationId

        $stopwatch = [Diagnostics.Stopwatch]::StartNew()
        $all = New-Object Collections.Generic.List[object]
        $terminatingError = $null
        try {
            & $ScriptBlock *>&1 | ForEach-Object { $all.Add($_) }
        } catch {
            $terminatingError = $_
            $all.Add($_)
        } finally { $stopwatch.Stop() }

        $maximum = [int]$policy.execution.maxCapturedItems
        $captured = @($all | Select-Object -First $maximum)
        $counts = [ordered]@{ Success = 0; Error = 0; Warning = 0; Verbose = 0; Debug = 0; Information = 0 }
        foreach ($item in $captured) { $counts[(Get-SNStreamName $item)]++ }
        $digestText = @($captured | ForEach-Object { '{0}:{1}' -f (Get-SNStreamName $_), $_.ToString() }) -join "`n"
        $resultData = @{
            operationId = $operationId
            commandHash = $shadow.CommandHash
            risk = $shadow.Risk
            executed = $true
            durationMilliseconds = $stopwatch.Elapsed.TotalMilliseconds
            emittedItems = $all.Count
            capturedItems = $captured.Count
            truncated = $all.Count -gt $captured.Count
            streamCounts = $counts
            outputDigest = Get-SNHashText -Text $digestText
            terminatingError = $null -ne $terminatingError
        }
        $receipt = Write-SNAccordInternal -Category 'Echoscopy' -Message "Executed $Name under governed commitment." `
            -Data ($resultData + @{ intentSequence = $intent.Record.sequence }) -PriorReference $operationId
        [pscustomobject]@{
            Schema = 'shell-notion-echoscopy/v1'
            OperationId = $operationId
            Executed = $true
            Shadow = $shadow
            DurationMilliseconds = [Math]::Round($stopwatch.Elapsed.TotalMilliseconds, 3)
            StreamCounts = [pscustomobject]$counts
            EmittedItems = $all.Count
            CapturedItems = $captured.Count
            Truncated = $all.Count -gt $captured.Count
            OutputDigest = $resultData.outputDigest
            IntentSequence = $intent.Record.sequence
            Output = if ($IncludeOutput) { $captured } else { @() }
            AccordSequence = if ($null -ne $receipt) { $receipt.Record.sequence } else { $null }
        }
    }
}

function Initialize-SNWindowApi {
    if (-not $script:IsWindowsPlatform) { throw 'ShellNotion window controls require Windows.' }
    if ('ShellNotion.Native.WindowApi' -as [type]) { return }
    Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

namespace ShellNotion.Native {
    public sealed class WindowInfo {
        public IntPtr Handle { get; set; }
        public string Title { get; set; }
        public int ProcessId { get; set; }
        public bool Visible { get; set; }
    }

    public static class WindowApi {
        private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
        [DllImport("user32.dll")] private static extern bool EnumWindows(EnumWindowsProc callback, IntPtr lParam);
        [DllImport("user32.dll", CharSet=CharSet.Unicode)] private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);
        [DllImport("user32.dll")] private static extern int GetWindowTextLength(IntPtr hWnd);
        [DllImport("user32.dll")] private static extern bool IsWindowVisible(IntPtr hWnd);
        [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);
        [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr hWnd);
        [DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int command);
        [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr insertAfter, int x, int y, int width, int height, uint flags);

        public static WindowInfo[] GetWindows() {
            var result = new List<WindowInfo>();
            EnumWindows(delegate(IntPtr handle, IntPtr state) {
                int length = GetWindowTextLength(handle);
                var title = new StringBuilder(length + 1);
                GetWindowText(handle, title, title.Capacity);
                uint processId;
                GetWindowThreadProcessId(handle, out processId);
                if (title.Length > 0) {
                    result.Add(new WindowInfo { Handle=handle, Title=title.ToString(), ProcessId=(int)processId, Visible=IsWindowVisible(handle) });
                }
                return true;
            }, IntPtr.Zero);
            return result.ToArray();
        }
    }
}
'@
}

function Get-SNWindow {
    [CmdletBinding()]
    param([string]$Title, [int]$ProcessId)
    Initialize-SNWindowApi
    $items = @([ShellNotion.Native.WindowApi]::GetWindows())
    if (-not [string]::IsNullOrWhiteSpace($Title)) { $items = @($items | Where-Object { $_.Title -like "*$Title*" }) }
    if ($ProcessId -gt 0) { $items = @($items | Where-Object { $_.ProcessId -eq $ProcessId }) }
    $items | Select-Object @{n='Handle';e={$_.Handle.ToInt64()}}, Title, ProcessId, Visible
}

function Set-SNWindowState {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)][long]$Handle,
        [Parameter(Mandatory)][ValidateSet('Hide', 'Show', 'Minimize', 'Maximize', 'Restore')][string]$State,
        [switch]$Commit
    )
    process {
        Initialize-SNWindowApi
        $policy = Get-SNPolicy
        if (-not [bool]$policy.windows.allowStateChange) { throw 'Window state changes are disabled by policy.' }
        $pointer = [IntPtr]$Handle
        if (-not [ShellNotion.Native.WindowApi]::IsWindow($pointer)) { throw "Window handle is invalid: $Handle" }
        if (-not $Commit) {
            return [pscustomobject]@{ Handle = $Handle; RequestedState = $State; Executed = $false; Guidance = 'Add -Commit to apply the state.' }
        }
        if ($PSCmdlet.ShouldProcess("window $Handle", "Set state to $State")) {
            $operationId = [Guid]::NewGuid().ToString('N')
            $intent = Write-SNAccordInternal -Category 'WindowIntent' -Message "Authorized window state intent: $State." `
                -Data @{ operationId = $operationId; handle = $Handle; state = $State } -PriorReference $operationId
            $codes = @{ Hide = 0; Show = 5; Minimize = 6; Maximize = 3; Restore = 9 }
            $success = [ShellNotion.Native.WindowApi]::ShowWindowAsync($pointer, [int]$codes[$State])
            $null = Write-SNAccordInternal -Category 'Window' -Message "Window state changed to $State." `
                -Data @{ operationId = $operationId; handle = $Handle; state = $State; success = $success; intentSequence = $intent.Record.sequence } -PriorReference $operationId
            [pscustomobject]@{ Handle = $Handle; RequestedState = $State; Executed = $true; Success = $success; OperationId = $operationId; IntentSequence = $intent.Record.sequence }
        }
    }
}

function Move-SNWindow {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)][long]$Handle,
        [Parameter(Mandatory)][ValidateRange(-32768,32768)][int]$X,
        [Parameter(Mandatory)][ValidateRange(-32768,32768)][int]$Y,
        [Parameter(Mandatory)][ValidateRange(1,32768)][int]$Width,
        [Parameter(Mandatory)][ValidateRange(1,32768)][int]$Height,
        [switch]$Commit
    )
    process {
        Initialize-SNWindowApi
        $policy = Get-SNPolicy
        if (-not [bool]$policy.windows.allowMove) { throw 'Window movement is disabled by policy.' }
        if ($Width -lt [int]$policy.windows.minimumWidth -or $Height -lt [int]$policy.windows.minimumHeight) {
            throw "Window size is below policy minimum $($policy.windows.minimumWidth)x$($policy.windows.minimumHeight)."
        }
        $pointer = [IntPtr]$Handle
        if (-not [ShellNotion.Native.WindowApi]::IsWindow($pointer)) { throw "Window handle is invalid: $Handle" }
        if (-not $Commit) {
            return [pscustomobject]@{ Handle = $Handle; X = $X; Y = $Y; Width = $Width; Height = $Height; Executed = $false; Guidance = 'Add -Commit to move the window.' }
        }
        if ($PSCmdlet.ShouldProcess("window $Handle", "Move to $X,$Y at ${Width}x$Height")) {
            $operationId = [Guid]::NewGuid().ToString('N')
            $intent = Write-SNAccordInternal -Category 'WindowIntent' -Message 'Authorized window geometry intent.' `
                -Data @{ operationId = $operationId; handle = $Handle; x = $X; y = $Y; width = $Width; height = $Height } `
                -PriorReference $operationId
            $success = [ShellNotion.Native.WindowApi]::SetWindowPos($pointer, [IntPtr]::Zero, $X, $Y, $Width, $Height, 0x0014)
            $null = Write-SNAccordInternal -Category 'Window' -Message 'Window position changed.' `
                -Data @{ operationId = $operationId; handle = $Handle; x = $X; y = $Y; width = $Width; height = $Height; success = $success; intentSequence = $intent.Record.sequence } `
                -PriorReference $operationId
            [pscustomobject]@{ Handle = $Handle; X = $X; Y = $Y; Width = $Width; Height = $Height; Executed = $true; Success = $success; OperationId = $operationId; IntentSequence = $intent.Record.sequence }
        }
    }
}

function Write-SNNotation {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Purpose,
        [string]$Message = '',
        [hashtable]$Data = @{},
        [string]$PriorReference = ''
    )
    Write-SNAccordInternal -Category $Purpose -Message $Message -Data $Data -PriorReference $PriorReference
}

function Test-SNAccord {
    [CmdletBinding()]
    param([switch]$IncludeArchive, [switch]$RequireAdministrator, [switch]$RequireNoBroadWrite)
    if (-not (Test-Path -LiteralPath $script:VerifyScript)) { throw "Record-Through verifier is unavailable: $script:VerifyScript" }
    $invoke = @{ RootPath = Get-SNRecordRoot; PassThru = $true; ErrorAction = 'Stop' }
    if ($IncludeArchive) { $invoke['IncludeArchive'] = $true }
    if ($RequireAdministrator) { $invoke['RequireAdministrator'] = $true }
    if ($RequireNoBroadWrite) { $invoke['RequireNoBroadWrite'] = $true }
    & $script:VerifyScript @invoke
}

function Invoke-SNForwardPass {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [string]$HumanNote = '',
        [string]$AssistantProposal = '',
        [string[]]$ExpectedProcess = @(),
        [string[]]$ExpectedService = @(),
        [string[]]$GraphGroup = @(),
        [string[]]$GraphLink = @(),
        [string[]]$CategoryAnnotation = @(),
        [string[]]$SeptemberMatrix = @(),
        [string[]]$GavornRicht = @(),
        [string]$ScriptEnvironment = 'shellnotion-forward',
        [switch]$Commit,
        [switch]$VerifyOnly
    )
    if (-not (Test-Path -LiteralPath $script:ForwardPassScript)) {
        throw "Forward Pass script is unavailable: $script:ForwardPassScript"
    }
    $root = if (-not [string]::IsNullOrWhiteSpace($env:SHELLNOTION_FORWARD_ROOT)) {
        $env:SHELLNOTION_FORWARD_ROOT
    } else {
        Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'ForwardPass'
    }
    if ($VerifyOnly) {
        return & $script:ForwardPassScript -DataDirectory $root -Verify -ErrorAction Stop
    }
    if (-not $Commit) {
        return [pscustomobject]@{
            Executed = $false
            DataDirectory = $root
            Guidance = 'Forward Pass reads process and service inventory and writes a snapshot. Inspect its scope, then pass -Commit to proceed.'
        }
    }
    if (-not $PSCmdlet.ShouldProcess($root, 'Collect read-only process/service snapshot and write a Forward Pass annotation')) {
        return [pscustomobject]@{ Executed = $false; DataDirectory = $root; Guidance = 'ShouldProcess declined the capture.' }
    }
    $result = & $script:ForwardPassScript -DataDirectory $root `
        -HumanNote $HumanNote -AssistantProposal $AssistantProposal `
        -ExpectedProcess $ExpectedProcess -ExpectedService $ExpectedService `
        -GraphGroup $GraphGroup -GraphLink $GraphLink `
        -CategoryAnnotation $CategoryAnnotation -SeptemberMatrix $SeptemberMatrix `
        -GavornRicht $GavornRicht -ScriptEnvironment $ScriptEnvironment -ErrorAction Stop
    if ($result.Record -and (Test-Path -LiteralPath $result.Record)) {
        $stored = Get-Content -LiteralPath $result.Record -Raw -Encoding UTF8 | ConvertFrom-Json
        $receiptData = @{
            recordPath = [IO.Path]::GetFileName([string]$result.Record)
            reportPath = [IO.Path]::GetFileName([string]$result.Report)
            forwardPassSha256 = [string]$stored.PayloadSha256
            graphGroups = [int]$result.GraphGroups
            graphNodes = [int]$result.GraphNodes
            categoryAnnotations = [int]$result.CategoryAnnotations
            matrixCells = [int]$result.SeptemberMatrixCells
            gavornRichts = [int]$result.GavornRichts
            coalescedSha256 = [string]$result.CoalescedSha256
        }
        $receipt = Write-SNAccordInternal -Category 'ForwardPass' `
            -Message 'Forward Pass snapshot and graph/matrix commitments created.' `
            -Data $receiptData -PriorReference ([string]$stored.PayloadSha256)
        $result | Add-Member -NotePropertyName ShellNotionAccordSequence -NotePropertyValue $receipt.Record.sequence -Force
    }
    return $result
}

function Test-SNForwardPass {
    [CmdletBinding()]
    param()
    Invoke-SNForwardPass -VerifyOnly
}

function Start-ShellNotion {
    [CmdletBinding()]
    param([switch]$ListWindows)
    [pscustomobject]@{
        Name = 'ShellNotion'
        Version = '1.0.0'
        Ready = (Get-SNLight).Ready
        Categories = @(Get-SNCategory)
        Examples = @(
            'Test-SNShadow { Get-Process }',
            'Invoke-SNEchoscopy -ScriptBlock { Get-Process } -Commit -IncludeOutput',
            'Get-SNWindow -Title Notepad',
            'Get-SNWindow -Title Notepad | Set-SNWindowState -State Restore -Commit',
            'Test-SNAccord -IncludeArchive'
        )
    }
    if ($ListWindows) { Get-SNWindow }
}

Export-ModuleMember -Function @(
    'Get-SNCategory', 'Get-SNPolicy', 'Get-SNCurrent', 'Get-SNLight', 'Get-SNCurrents',
    'Test-SNShadow', 'Invoke-SNEchoscopy', 'Get-SNWindow', 'Set-SNWindowState',
    'Move-SNWindow', 'Invoke-SNForwardPass', 'Test-SNForwardPass',
    'Write-SNNotation', 'Test-SNAccord', 'Start-ShellNotion'
)
