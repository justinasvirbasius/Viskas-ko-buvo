@{
    RootModule = 'Reporitor.psm1'
    ModuleVersion = '1.0.0'
    GUID = 'd42d2a67-d240-40db-bfe6-f010fdb328d2'
    Author = 'Reporitor Accord'
    CompanyName = 'Independent'
    Copyright = 'Copyright (c) 2026. All rights reserved.'
    Description = 'A governed GitHub repository manager and finite convenience bot using the GitHub CLI.'
    PowerShellVersion = '5.1'
    FunctionsToExport = @(
        'Get-RPPolicy', 'Test-RPPrerequisite', 'Get-RPRepository',
        'Invoke-RPRead', 'New-RPRepository', 'New-RPIssue',
        'Add-RPIssueComment', 'New-RPPullRequest', 'Invoke-ReporitorBot',
        'Test-RPAccord', 'Start-Reporitor'
    )
    CmdletsToExport = @()
    VariablesToExport = @()
    AliasesToExport = @()
    PrivateData = @{ PSData = @{ Tags = @('GitHub', 'Repository', 'Bot', 'Governance', 'PowerShell') } }
}
