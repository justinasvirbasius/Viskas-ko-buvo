#requires -Version 5.1
[CmdletBinding()]
param([string]$Repository, [string]$LocalPath)

$ErrorActionPreference = 'Stop'
$manifest = Join-Path $PSScriptRoot 'Reporitor.psd1'
Import-Module $manifest -Force

$required = @(
    'Get-RPPolicy', 'Test-RPPrerequisite', 'Get-RPRepository', 'Invoke-RPRead',
    'New-RPRepository', 'New-RPIssue', 'Add-RPIssueComment', 'New-RPPullRequest',
    'Invoke-ReporitorBot', 'Test-RPAccord', 'Start-Reporitor'
)
$missing = @($required | Where-Object { -not (Get-Command $_ -ErrorAction SilentlyContinue) })
$policy = Get-RPPolicy
$prerequisite = Test-RPPrerequisite
$result = [ordered]@{
    Passed = ($missing.Count -eq 0 -and $null -ne $policy -and $policy.schema -eq 'reporitor-policy/v1')
    ReadyForGitHub = $prerequisite.Ready
    MissingCommands = $missing
    PolicySchema = $policy.schema
    Prerequisite = $prerequisite
    Repository = $null
    Accord = $null
}

if ($prerequisite.Ready -and (-not [string]::IsNullOrWhiteSpace($Repository) -or -not [string]::IsNullOrWhiteSpace($LocalPath))) {
    $repositoryInfo = Get-RPRepository -Repository $Repository -LocalPath $LocalPath
    $result.Repository = $repositoryInfo
    $result.Accord = Test-RPAccord -Repository $repositoryInfo.Repository
    $result.Passed = $result.Passed -and $result.Accord.Valid
}

[pscustomobject]$result
