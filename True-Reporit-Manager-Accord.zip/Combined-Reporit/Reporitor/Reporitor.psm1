#requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$script:Root = $PSScriptRoot
$script:PolicyPath = Join-Path $PSScriptRoot 'Reporitor.policy.json'
$script:Utf8NoBom = New-Object Text.UTF8Encoding($false)

function Get-RPPolicy {
    [CmdletBinding()]
    param()
    if (-not (Test-Path -LiteralPath $script:PolicyPath)) { throw "Reporitor policy missing: $script:PolicyPath" }
    Get-Content -LiteralPath $script:PolicyPath -Raw -Encoding UTF8 | ConvertFrom-Json
}

function Get-RPHash {
    param([Parameter(Mandatory)][byte[]]$Bytes)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return -join ($sha.ComputeHash($Bytes) | ForEach-Object { $_.ToString('x2') }) }
    finally { $sha.Dispose() }
}

function Invoke-RPGh {
    param([Parameter(Mandatory)][string[]]$Arguments)
    if (-not (Get-Command gh -ErrorAction SilentlyContinue)) { throw 'GitHub CLI (gh) was not found on PATH.' }
    $output = @(& gh @Arguments 2>&1 | ForEach-Object { [string]$_ })
    $code = $LASTEXITCODE
    [pscustomobject]@{ ExitCode = [int]$code; Output = @($output); Text = (@($output) -join "`n") }
}

function Assert-RPRepositoryName {
    param([Parameter(Mandatory)][string]$Repository)
    if ($Repository -notmatch '^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$') {
        throw "Repository must use owner/name form: $Repository"
    }
}

function Resolve-RPRepository {
    param([string]$Repository, [string]$LocalPath)
    if (-not [string]::IsNullOrWhiteSpace($Repository)) {
        Assert-RPRepositoryName -Repository $Repository
        return $Repository
    }
    $path = if ([string]::IsNullOrWhiteSpace($LocalPath)) { (Get-Location).Path } else { $LocalPath }
    if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw 'Git executable was not found on PATH.' }
    $remote = @(& git -C $path remote get-url origin 2>&1)
    if ($LASTEXITCODE -ne 0 -or $remote.Count -eq 0) { throw 'Could not resolve GitHub repository from origin; pass -Repository owner/name.' }
    $value = ([string]$remote[-1]).Trim()
    $match = [regex]::Match($value, '(?i)(?:github\.com[:/])(?<owner>[^/ :]+?)/(?<name>[^/ ]+?)(?:\.git)?$')
    if (-not $match.Success) { throw 'The origin remote is not a recognizable GitHub repository; pass -Repository owner/name.' }
    $resolved = '{0}/{1}' -f $match.Groups['owner'].Value, $match.Groups['name'].Value
    Assert-RPRepositoryName -Repository $resolved
    return $resolved
}

function Get-RPAccordRoot {
    param([Parameter(Mandatory)][string]$Repository)
    $base = if (-not [string]::IsNullOrWhiteSpace($env:REPORITOR_ACCORD_ROOT)) {
        $env:REPORITOR_ACCORD_ROOT
    } else { Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'Reporitor' }
    $digest = Get-RPHash -Bytes $script:Utf8NoBom.GetBytes($Repository.ToLowerInvariant())
    Join-Path $base $digest.Substring(0, 24)
}

function Test-RPPrerequisite {
    [CmdletBinding()]
    param()
    $gh = Get-Command gh -ErrorAction SilentlyContinue
    if ($null -eq $gh) {
        return [pscustomobject]@{ Ready = $false; GitHubCli = $false; Authenticated = $false; Login = $null; Guidance = 'Install GitHub CLI and run gh auth login.' }
    }
    $policy = Get-RPPolicy
    $auth = Invoke-RPGh -Arguments @('auth', 'status', '--hostname', [string]$policy.github.hostname)
    if ($auth.ExitCode -ne 0) {
        return [pscustomobject]@{ Ready = $false; GitHubCli = $true; Authenticated = $false; Login = $null; Guidance = 'Run gh auth login for the configured hostname.' }
    }
    $user = Invoke-RPGh -Arguments @('api', 'user', '--jq', '.login')
    [pscustomobject]@{
        Ready = ($user.ExitCode -eq 0)
        GitHubCli = $true
        Authenticated = $true
        Login = if ($user.ExitCode -eq 0) { $user.Text.Trim() } else { $null }
        Guidance = if ($user.ExitCode -eq 0) { 'GitHub CLI is authenticated.' } else { 'Authentication exists but the current user could not be resolved.' }
    }
}

function Read-RPLedger {
    param([Parameter(Mandatory)][string]$LedgerPath)
    if (-not (Test-Path -LiteralPath $LedgerPath)) { return @() }
    $items = New-Object Collections.Generic.List[object]
    $prior = ''
    $sequence = 1L
    foreach ($line in [IO.File]::ReadLines($LedgerPath, $script:Utf8NoBom)) {
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        $envelope = $line | ConvertFrom-Json
        $canonical = [string]$envelope.PayloadJson
        $payload = $canonical | ConvertFrom-Json
        $actual = Get-RPHash -Bytes $script:Utf8NoBom.GetBytes($canonical)
        if ($actual -cne [string]$envelope.PayloadSha256) { throw "Reporitor accord sequence $sequence has an invalid digest." }
        if ([string]$payload.PreviousRecordSha256 -cne $prior) { throw "Reporitor accord sequence $sequence has a broken prior link." }
        if ([long]$payload.Sequence -ne $sequence) { throw "Reporitor accord sequence $sequence is missing or reordered." }
        $items.Add([pscustomobject]@{ Payload = $payload; Hash = $actual })
        $prior = $actual
        $sequence++
    }
    @($items)
}

function Write-RPAccord {
    param(
        [Parameter(Mandatory)][string]$Repository,
        [Parameter(Mandatory)][string]$Operation,
        [Parameter(Mandatory)][hashtable]$Evidence
    )
    Assert-RPRepositoryName -Repository $Repository
    $root = Get-RPAccordRoot -Repository $Repository
    [void](New-Item -ItemType Directory -Path $root -Force)
    $ledger = Join-Path $root 'reporitor-accord.jsonl'
    $mutexDigest = Get-RPHash -Bytes $script:Utf8NoBom.GetBytes($ledger.ToLowerInvariant())
    $mutex = New-Object Threading.Mutex($false, ('Local\Reporitor-' + $mutexDigest.Substring(0, 24)))
    $locked = $false
    try {
        $locked = $mutex.WaitOne([TimeSpan]::FromSeconds(20))
        if (-not $locked) { throw 'Reporitor accord is busy; lock timeout.' }
        $records = @(Read-RPLedger -LedgerPath $ledger)
        $prior = if ($records.Count -gt 0) { [string]$records[-1].Hash } else { '' }
        $payload = [ordered]@{
            Schema = 'reporitor-accord/v1'
            Sequence = [long]$records.Count + 1
            TimestampUtc = [DateTimeOffset]::UtcNow.ToString('o')
            Actor = [Environment]::UserName
            Repository = $Repository
            Operation = $Operation
            Evidence = $Evidence
            PreviousRecordSha256 = $prior
        }
        $canonical = $payload | ConvertTo-Json -Depth 20 -Compress
        $hash = Get-RPHash -Bytes $script:Utf8NoBom.GetBytes($canonical)
        $line = [ordered]@{ PayloadJson = $canonical; PayloadSha256 = $hash } | ConvertTo-Json -Depth 20 -Compress
        $bytes = $script:Utf8NoBom.GetBytes($line + [Environment]::NewLine)
        $stream = New-Object IO.FileStream($ledger, [IO.FileMode]::Append, [IO.FileAccess]::Write, [IO.FileShare]::Read)
        try { $stream.Write($bytes, 0, $bytes.Length); $stream.Flush($true) }
        finally { $stream.Dispose() }
        [pscustomobject]@{ Sequence = $payload.Sequence; Hash = $hash; Ledger = $ledger }
    } finally {
        if ($locked) { $mutex.ReleaseMutex() }
        $mutex.Dispose()
    }
}

function Test-RPAccord {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Repository)
    Assert-RPRepositoryName -Repository $Repository
    $root = Get-RPAccordRoot -Repository $Repository
    $ledger = Join-Path $root 'reporitor-accord.jsonl'
    try {
        $records = @(Read-RPLedger -LedgerPath $ledger)
        [pscustomobject]@{
            Valid = $true; Repository = $Repository; AccordRoot = $root; Records = $records.Count
            LastHash = if ($records.Count -gt 0) { $records[-1].Hash } else { $null }
            Guidance = if ($records.Count -eq 0) { 'No Reporitor records yet.' } else { 'Digest, sequence, and prior links are valid.' }
        }
    } catch {
        [pscustomobject]@{ Valid = $false; Repository = $Repository; AccordRoot = $root; Records = $null; LastHash = $null; Guidance = $_.Exception.Message }
    }
}

function Get-RPRepository {
    [CmdletBinding()]
    param([string]$Repository, [string]$LocalPath)
    $resolved = Resolve-RPRepository -Repository $Repository -LocalPath $LocalPath
    $result = Invoke-RPGh -Arguments @('repo', 'view', $resolved, '--json', 'nameWithOwner,description,visibility,isPrivate,isArchived,defaultBranchRef,url,viewerPermission')
    if ($result.ExitCode -ne 0) { throw "GitHub repository view failed: $($result.Text)" }
    $value = $result.Text | ConvertFrom-Json
    [pscustomobject]@{
        Repository = $value.nameWithOwner
        Description = $value.description
        Visibility = $value.visibility
        IsPrivate = $value.isPrivate
        IsArchived = $value.isArchived
        DefaultBranch = if ($null -ne $value.defaultBranchRef) { $value.defaultBranchRef.name } else { $null }
        Url = $value.url
        ViewerPermission = $value.viewerPermission
    }
}

function Invoke-RPRead {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][ValidateSet('Repository','Issues','PullRequests','Runs','Releases')][string]$Operation,
        [string]$Repository,
        [string]$LocalPath,
        [ValidateRange(1,200)][int]$Limit = 30,
        [switch]$RecordReceipt
    )
    $resolved = Resolve-RPRepository -Repository $Repository -LocalPath $LocalPath
    $arguments = switch ($Operation) {
        'Repository' { @('repo','view',$resolved,'--json','nameWithOwner,description,visibility,isArchived,defaultBranchRef,url,viewerPermission') }
        'Issues' { @('issue','list','--repo',$resolved,'--state','all','--limit',"$Limit",'--json','number,title,state,author,labels,updatedAt,url') }
        'PullRequests' { @('pr','list','--repo',$resolved,'--state','all','--limit',"$Limit",'--json','number,title,state,author,baseRefName,headRefName,isDraft,updatedAt,url') }
        'Runs' { @('run','list','--repo',$resolved,'--limit',"$Limit",'--json','databaseId,name,event,status,conclusion,workflowName,createdAt,updatedAt,url') }
        'Releases' { @('release','list','--repo',$resolved,'--limit',"$Limit",'--json','tagName,name,isDraft,isPrerelease,publishedAt,url') }
    }
    $result = Invoke-RPGh -Arguments $arguments
    if ($result.ExitCode -ne 0) { throw "GitHub read $Operation failed: $($result.Text)" }
    $receipt = $null
    if ($RecordReceipt) {
        $receipt = Write-RPAccord -Repository $resolved -Operation "Read/$Operation" `
            -Evidence @{ lineCount = $result.Output.Count; responseSha256 = Get-RPHash -Bytes $script:Utf8NoBom.GetBytes($result.Text) }
    }
    [pscustomobject]@{ Repository = $resolved; Operation = $Operation; Data = ($result.Text | ConvertFrom-Json); Receipt = $receipt }
}

function Invoke-RPWriteInternal {
    param(
        [Parameter(Mandatory)][string]$Repository,
        [Parameter(Mandatory)][string]$Operation,
        [Parameter(Mandatory)][string[]]$Arguments,
        [Parameter(Mandatory)][hashtable]$Intent
    )
    $intentReceipt = Write-RPAccord -Repository $Repository -Operation "Intent/$Operation" -Evidence $Intent
    $result = Invoke-RPGh -Arguments $Arguments
    if ($result.ExitCode -ne 0) {
        $failure = Write-RPAccord -Repository $Repository -Operation "Failure/$Operation" `
            -Evidence @{ intentSequence = $intentReceipt.Sequence; exitCode = $result.ExitCode; outputSha256 = Get-RPHash -Bytes $script:Utf8NoBom.GetBytes($result.Text) }
        throw "GitHub $Operation failed (accord sequence $($failure.Sequence)): $($result.Text)"
    }
    $outcome = Write-RPAccord -Repository $Repository -Operation "Outcome/$Operation" `
        -Evidence @{ intentSequence = $intentReceipt.Sequence; outputSha256 = Get-RPHash -Bytes $script:Utf8NoBom.GetBytes($result.Text) }
    [pscustomobject]@{ Repository = $Repository; Operation = $Operation; Output = $result.Output; Intent = $intentReceipt; Outcome = $outcome }
}

function New-RPRepository {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory)][string]$Name,
        [ValidateSet('private','public','internal')][string]$Visibility = 'private',
        [string]$Description = '',
        [switch]$Commit
    )
    $policy = Get-RPPolicy
    if (-not [bool]$policy.github.allowRepositoryCreate) { throw 'Repository creation is disabled by policy.' }
    if ($Visibility -eq 'public' -and -not [bool]$policy.github.allowPublicRepositoryCreate) { throw 'Public repository creation is disabled by policy.' }
    if ($Name -notmatch '^(?:[A-Za-z0-9_.-]+/)?[A-Za-z0-9_.-]+$') { throw 'Name must be repository or owner/repository form.' }
    if (-not $Commit) { return [pscustomobject]@{ Created = $false; Name = $Name; Visibility = $Visibility; Guidance = 'Add -Commit to create the GitHub repository.' } }
    if ($PSCmdlet.ShouldProcess($Name, "create $Visibility GitHub repository")) {
        $login = (Test-RPPrerequisite).Login
        if ([string]::IsNullOrWhiteSpace($login)) { throw 'Authenticated GitHub login could not be resolved.' }
        $target = if ($Name.Contains('/')) { $Name } else { "$login/$Name" }
        $args = @('repo','create',$Name,"--$Visibility")
        if (-not [string]::IsNullOrWhiteSpace($Description)) { $args += @('--description',$Description) }
        Invoke-RPWriteInternal -Repository $target -Operation 'CreateRepository' -Arguments $args `
            -Intent @{ visibility = $Visibility; descriptionSha256 = Get-RPHash -Bytes $script:Utf8NoBom.GetBytes($Description) }
    }
}

function New-RPIssue {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param([string]$Repository, [string]$LocalPath, [Parameter(Mandatory)][string]$Title, [string]$Body = '', [string[]]$Label = @(), [switch]$Commit)
    $policy = Get-RPPolicy
    if (-not [bool]$policy.github.allowIssueCreate) { throw 'Issue creation is disabled by policy.' }
    $resolved = Resolve-RPRepository -Repository $Repository -LocalPath $LocalPath
    if (-not $Commit) { return [pscustomobject]@{ Created = $false; Repository = $resolved; Title = $Title; Guidance = 'Add -Commit to create the issue.' } }
    if ($PSCmdlet.ShouldProcess($resolved, "create issue: $Title")) {
        $args = @('issue','create','--repo',$resolved,'--title',$Title,'--body',$Body)
        foreach ($item in $Label) { $args += @('--label',$item) }
        Invoke-RPWriteInternal -Repository $resolved -Operation 'CreateIssue' -Arguments $args `
            -Intent @{ title = $Title; bodySha256 = Get-RPHash -Bytes $script:Utf8NoBom.GetBytes($Body); labels = $Label }
    }
}

function Add-RPIssueComment {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param([string]$Repository, [string]$LocalPath, [Parameter(Mandatory)][ValidateRange(1,2147483647)][int]$Number, [Parameter(Mandatory)][string]$Body, [switch]$Commit)
    $policy = Get-RPPolicy
    if (-not [bool]$policy.github.allowIssueComment) { throw 'Issue comments are disabled by policy.' }
    $resolved = Resolve-RPRepository -Repository $Repository -LocalPath $LocalPath
    if (-not $Commit) { return [pscustomobject]@{ Created = $false; Repository = $resolved; Number = $Number; Guidance = 'Add -Commit to publish the comment.' } }
    if ($PSCmdlet.ShouldProcess("$resolved#$Number", 'publish GitHub issue or pull-request comment')) {
        Invoke-RPWriteInternal -Repository $resolved -Operation 'IssueComment' `
            -Arguments @('issue','comment',"$Number",'--repo',$resolved,'--body',$Body) `
            -Intent @{ number = $Number; bodySha256 = Get-RPHash -Bytes $script:Utf8NoBom.GetBytes($Body) }
    }
}

function New-RPPullRequest {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [string]$Repository, [string]$LocalPath,
        [Parameter(Mandatory)][string]$Title, [string]$Body = '',
        [Parameter(Mandatory)][string]$Base, [Parameter(Mandatory)][string]$Head,
        [switch]$Draft, [switch]$Commit
    )
    $policy = Get-RPPolicy
    if (-not [bool]$policy.github.allowPullRequestCreate) { throw 'Pull-request creation is disabled by policy.' }
    $resolved = Resolve-RPRepository -Repository $Repository -LocalPath $LocalPath
    if (-not $Commit) { return [pscustomobject]@{ Created = $false; Repository = $resolved; Title = $Title; Base = $Base; Head = $Head; Guidance = 'Add -Commit to create the pull request.' } }
    if ($PSCmdlet.ShouldProcess($resolved, "create pull request $Head -> $Base")) {
        $args = @('pr','create','--repo',$resolved,'--title',$Title,'--body',$Body,'--base',$Base,'--head',$Head)
        if ($Draft) { $args += '--draft' }
        Invoke-RPWriteInternal -Repository $resolved -Operation 'CreatePullRequest' -Arguments $args `
            -Intent @{ title = $Title; bodySha256 = Get-RPHash -Bytes $script:Utf8NoBom.GetBytes($Body); base = $Base; head = $Head; draft = [bool]$Draft }
    }
}

function Invoke-ReporitorBot {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [string]$Repository, [string]$LocalPath,
        [ValidateRange(1,100)][int]$Rounds = 1,
        [ValidateRange(0,86400)][int]$IntervalSeconds = 60,
        [switch]$Commit
    )
    $policy = Get-RPPolicy
    if ($Rounds -gt [int]$policy.bot.maximumRounds) { throw 'Rounds exceeds policy maximum.' }
    if ($IntervalSeconds -gt [int]$policy.bot.maximumIntervalSeconds) { throw 'IntervalSeconds exceeds policy maximum.' }
    $resolved = Resolve-RPRepository -Repository $Repository -LocalPath $LocalPath
    if (-not $Commit) { return [pscustomobject]@{ Executed = $false; Repository = $resolved; Rounds = $Rounds; Guidance = 'Add -Commit to run the finite reporting bot and write local reports.' } }
    if (-not $PSCmdlet.ShouldProcess($resolved, "run Reporitor for $Rounds finite rounds")) { return }
    $accordRoot = Get-RPAccordRoot -Repository $resolved
    $reportRoot = Join-Path $accordRoot 'reports'
    [void](New-Item -ItemType Directory -Path $reportRoot -Force)
    $runId = [Guid]::NewGuid().ToString('N')
    $intent = Write-RPAccord -Repository $resolved -Operation 'BotIntent' -Evidence @{ runId = $runId; rounds = $Rounds; intervalSeconds = $IntervalSeconds }
    $reports = New-Object Collections.Generic.List[object]
    try {
        for ($round = 1; $round -le $Rounds; $round++) {
            $repositoryData = (Invoke-RPRead -Repository $resolved -Operation Repository).Data
            $issues = (Invoke-RPRead -Repository $resolved -Operation Issues -Limit ([int]$policy.bot.defaultIssueLimit)).Data
            $pulls = (Invoke-RPRead -Repository $resolved -Operation PullRequests -Limit ([int]$policy.bot.defaultPullRequestLimit)).Data
            $runs = (Invoke-RPRead -Repository $resolved -Operation Runs -Limit ([int]$policy.bot.defaultRunLimit)).Data
            $report = [ordered]@{
                Schema = 'reporitor-report/v1'; RunId = $runId; Round = $round
                CapturedUtc = [DateTimeOffset]::UtcNow.ToString('o'); Repository = $resolved
                RepositoryData = $repositoryData; Issues = @($issues); PullRequests = @($pulls); WorkflowRuns = @($runs)
            }
            $stamp = [DateTimeOffset]::UtcNow.ToString('yyyyMMddTHHmmssfffZ')
            $path = Join-Path $reportRoot ("$stamp-$runId-$round.json")
            [IO.File]::WriteAllText($path, ($report | ConvertTo-Json -Depth 20), $script:Utf8NoBom)
            $reportHash = Get-RPHash -Bytes ([IO.File]::ReadAllBytes($path))
            $receipt = Write-RPAccord -Repository $resolved -Operation 'BotRound' `
                -Evidence @{ runId = $runId; round = $round; reportFile = [IO.Path]::GetFileName($path); reportSha256 = $reportHash; issues = @($issues).Count; pullRequests = @($pulls).Count; workflowRuns = @($runs).Count; intentSequence = $intent.Sequence }
            $reports.Add([pscustomobject]@{ Round = $round; Path = $path; Sha256 = $reportHash; ReceiptSequence = $receipt.Sequence })
            if ($round -lt $Rounds -and $IntervalSeconds -gt 0) { Start-Sleep -Seconds $IntervalSeconds }
        }
    } catch {
        $failure = Write-RPAccord -Repository $resolved -Operation 'BotFailure' -Evidence @{
            runId = $runId; roundsCompleted = $reports.Count; intentSequence = $intent.Sequence
            errorSha256 = Get-RPHash -Bytes $script:Utf8NoBom.GetBytes($_.Exception.Message)
        }
        throw "Reporitor bot failed after $($reports.Count) completed rounds (accord sequence $($failure.Sequence)): $($_.Exception.Message)"
    }
    $outcome = Write-RPAccord -Repository $resolved -Operation 'BotOutcome' -Evidence @{ runId = $runId; roundsCompleted = $reports.Count; intentSequence = $intent.Sequence }
    [pscustomobject]@{ Executed = $true; Repository = $resolved; RunId = $runId; Reports = @($reports); Intent = $intent; Outcome = $outcome }
}

function Start-Reporitor {
    [CmdletBinding()]
    param([string]$Repository, [string]$LocalPath)
    $prerequisite = Test-RPPrerequisite
    if (-not $prerequisite.Ready) { return [pscustomobject]@{ Name = 'Reporitor'; Version = '1.0.0'; Ready = $false; Prerequisite = $prerequisite } }
    $resolved = Resolve-RPRepository -Repository $Repository -LocalPath $LocalPath
    [pscustomobject]@{
        Name = 'Reporitor'; Version = '1.0.0'; Ready = $true; Prerequisite = $prerequisite
        Repository = Get-RPRepository -Repository $resolved
        Accord = Test-RPAccord -Repository $resolved
        Examples = @(
            "Invoke-RPRead -Repository $resolved -Operation Issues",
            "Invoke-ReporitorBot -Repository $resolved -Rounds 1 -Commit",
            "New-RPIssue -Repository $resolved -Title 'Tracked work' -Commit"
        )
    }
}

Export-ModuleMember -Function @(
    'Get-RPPolicy', 'Test-RPPrerequisite', 'Get-RPRepository', 'Invoke-RPRead',
    'New-RPRepository', 'New-RPIssue', 'Add-RPIssueComment', 'New-RPPullRequest',
    'Invoke-ReporitorBot', 'Test-RPAccord', 'Start-Reporitor'
)
