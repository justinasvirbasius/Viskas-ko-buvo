#requires -Version 5.1
[CmdletBinding()]
param([string]$Repository, [string]$LocalPath)

$manifest = Join-Path $PSScriptRoot 'Reporitor.psd1'
Import-Module $manifest -Force -ErrorAction Stop
Start-Reporitor -Repository $Repository -LocalPath $LocalPath
