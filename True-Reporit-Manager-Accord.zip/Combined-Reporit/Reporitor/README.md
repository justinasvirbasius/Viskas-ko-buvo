# Reporitor GitHub Agent

Reporitor is a PowerShell repository manager and finite convenience bot built on the GitHub CLI (`gh`). It layers GitHub operations above the separate local `Gits` module. Reporitor has its own policy and SHA-256-linked accord ledger.

## Requirements

- Windows PowerShell 5.1 or PowerShell 7+
- GitHub CLI installed and available as `gh`
- An authenticated CLI session created with `gh auth login`
- Git when resolving a repository from a local `origin` remote

Reporitor does not read, print, or store the GitHub authentication token.

## Start and inspect

```powershell
Import-Module .\Reporitor.psd1 -Force
Test-RPPrerequisite
Start-Reporitor -Repository owner/repository
Get-RPRepository -Repository owner/repository
```

You can omit `-Repository` when the current directory or `-LocalPath` has a recognizable GitHub `origin` remote.

## Read GitHub state

```powershell
Invoke-RPRead -Repository owner/repository -Operation Issues
Invoke-RPRead -Repository owner/repository -Operation PullRequests -Limit 20
Invoke-RPRead -Repository owner/repository -Operation Runs
Invoke-RPRead -Repository owner/repository -Operation Releases -RecordReceipt
```

`-RecordReceipt` writes a response digest and line count. It does not put the response body in the accord.

## Governed GitHub writes

Each write previews until `-Commit` is supplied. PowerShell `-WhatIf` and `-Confirm` are also supported.

```powershell
New-RPRepository -Name useful-project -Visibility private
New-RPRepository -Name useful-project -Visibility private -Description 'Managed repository' -Commit

New-RPIssue -Repository owner/repository -Title 'Review required' -Body 'Check the latest report.' -Commit
Add-RPIssueComment -Repository owner/repository -Number 12 -Body 'Review complete.' -Commit
New-RPPullRequest -Repository owner/repository -Title 'Update notes' -Base main -Head docs/update -Draft -Commit
```

Remote writes record an intent before invoking `gh`, followed by an outcome or failure record. Public repository creation is disabled by default. Merge, delete, archive, repository setting changes, workflow dispatch, release publishing, and force operations are outside this version.

## Run the convenience bot

```powershell
Invoke-ReporitorBot -Repository owner/repository -Rounds 1
Invoke-ReporitorBot -Repository owner/repository -Rounds 3 -IntervalSeconds 300 -Commit
```

The bot runs for a finite number of rounds. Each round reads repository metadata, issues, pull requests, and workflow runs, writes one local JSON report, hashes it, and links the hash into the accord. Reports and the ledger are stored outside the Git working tree under `%LOCALAPPDATA%\Reporitor` by default. Set `REPORITOR_ACCORD_ROOT` to choose a different location.

## Verify the accord

```powershell
Test-RPAccord -Repository owner/repository
```

The verifier checks every stored payload digest, sequence number, and prior-record link. The accord detects accidental or uncoordinated changes; it is not a digital signature and cannot prevent an administrator from replacing both the module and ledger.
