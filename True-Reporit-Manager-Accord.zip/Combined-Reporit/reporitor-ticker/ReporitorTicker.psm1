Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$script:ModuleRoot = $PSScriptRoot
$script:DefaultConfigPath = Join-Path $PSScriptRoot 'ReporitorTicker.config.json'

function Get-RTUtcNow {
    [DateTime]::UtcNow.ToString('o')
}

function Get-RTDefaultRoot {
    if ($env:REPORITOR_TICKER_ROOT) { return $env:REPORITOR_TICKER_ROOT }
    $base = if ($env:LOCALAPPDATA) { $env:LOCALAPPDATA } else { [Environment]::GetFolderPath('LocalApplicationData') }
    if (-not $base) { $base = [IO.Path]::GetTempPath() }
    Join-Path $base 'ReporitorTicker'
}

function Resolve-RTRoot {
    param([string]$Root)
    if ($Root) { return [IO.Path]::GetFullPath($Root) }
    [IO.Path]::GetFullPath((Get-RTDefaultRoot))
}

function Get-RTPaths {
    param([string]$Root)
    $resolved = Resolve-RTRoot $Root
    [pscustomobject]@{
        Root = $resolved
        Config = Join-Path $resolved 'config.json'
        Tickets = Join-Path $resolved 'tickets.json'
        Status = Join-Path $resolved 'status.json'
        StopRequest = Join-Path $resolved 'stop.request.json'
        TickLog = Join-Path $resolved 'ticks.ndjson'
        Lock = Join-Path $resolved 'state.lock'
        RunnerLock = Join-Path $resolved 'ticker.lock'
    }
}

function ConvertTo-RTHash {
    param([Parameter(Mandatory)][string]$Text)
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [Text.Encoding]::UTF8.GetBytes($Text)
        ([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-', '').ToLowerInvariant()
    }
    finally { $sha.Dispose() }
}

function Write-RTJsonAtomic {
    param([Parameter(Mandatory)][string]$Path, [Parameter(Mandatory)]$Value)
    $directory = Split-Path -Parent $Path
    if (-not (Test-Path -LiteralPath $directory)) { New-Item -ItemType Directory -Path $directory -Force | Out-Null }
    $temporary = "$Path.$([Guid]::NewGuid().ToString('N')).tmp"
    try {
        ConvertTo-Json -InputObject $Value -Depth 12 | Set-Content -LiteralPath $temporary -Encoding UTF8
        Move-Item -LiteralPath $temporary -Destination $Path -Force
    }
    finally {
        if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force }
    }
}

function Read-RTJson {
    param([Parameter(Mandatory)][string]$Path, $Default)
    if (-not (Test-Path -LiteralPath $Path)) { return $Default }
    $raw = Get-Content -LiteralPath $Path -Raw
    if (-not $raw.Trim()) { return $Default }
    $raw | ConvertFrom-Json
}

function Invoke-RTLocked {
    param([Parameter(Mandatory)][string]$Root, [Parameter(Mandatory)][scriptblock]$Action)
    $paths = Get-RTPaths $Root
    if (-not (Test-Path -LiteralPath $paths.Root)) { New-Item -ItemType Directory -Path $paths.Root -Force | Out-Null }
    $stream = $null
    try {
        $stream = [IO.File]::Open($paths.Lock, [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
        & $Action $paths
    }
    finally {
        if ($stream) { $stream.Dispose() }
    }
}

function Initialize-RTWorkspace {
    [CmdletBinding()]
    param([string]$Root, [string]$Repository)
    $paths = Get-RTPaths $Root
    if (-not (Test-Path -LiteralPath $paths.Root)) { New-Item -ItemType Directory -Path $paths.Root -Force | Out-Null }
    if (-not (Test-Path -LiteralPath $paths.Config)) {
        $config = Read-RTJson $script:DefaultConfigPath $null
        if ($Repository) { $config.repository.name = $Repository }
        Write-RTJsonAtomic $paths.Config $config
    }
    elseif ($Repository) {
        $config = Read-RTJson $paths.Config $null
        $config.repository.name = $Repository
        Write-RTJsonAtomic $paths.Config $config
    }
    if (-not (Test-Path -LiteralPath $paths.Tickets)) { Write-RTJsonAtomic $paths.Tickets @() }
    if (-not (Test-Path -LiteralPath $paths.Status)) {
        Write-RTJsonAtomic $paths.Status ([ordered]@{ state = 'Initialized'; tick = 0; updatedAt = Get-RTUtcNow; reason = 'Workspace ready' })
    }
    [pscustomobject]@{ Root = $paths.Root; ConfigPath = $paths.Config; TicketsPath = $paths.Tickets; StatusPath = $paths.Status }
}

function Get-RTConfig {
    [CmdletBinding()]
    param([string]$Root)
    $paths = Get-RTPaths $Root
    if (-not (Test-Path -LiteralPath $paths.Config)) { Initialize-RTWorkspace -Root $paths.Root | Out-Null }
    Read-RTJson $paths.Config $null
}

function Set-RTConfig {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [string]$Root,
        [string]$Repository,
        [string]$LocalPath,
        [ValidateRange(1,86400)][int]$IntervalSeconds,
        [ValidateRange(1,2147483647)][int]$MaxTicks,
        [ValidateSet('Immediate','AfterTick','Drain')][string]$DefaultTerminationMode,
        [Nullable[bool]]$GitHubEnabled,
        [Nullable[bool]]$AllowGitHubWrites
    )
    $paths = Get-RTPaths $Root
    Initialize-RTWorkspace -Root $paths.Root | Out-Null
    $config = Get-RTConfig -Root $paths.Root
    if ($Repository) { $config.repository.name = $Repository }
    if ($LocalPath) { $config.repository.localPath = $LocalPath }
    if ($PSBoundParameters.ContainsKey('IntervalSeconds')) { $config.ticker.intervalSeconds = $IntervalSeconds }
    if ($PSBoundParameters.ContainsKey('MaxTicks')) { $config.ticker.maxTicks = $MaxTicks }
    if ($DefaultTerminationMode) { $config.ticker.defaultTerminationMode = $DefaultTerminationMode }
    if ($PSBoundParameters.ContainsKey('GitHubEnabled')) { $config.connectors.github.enabled = [bool]$GitHubEnabled }
    if ($PSBoundParameters.ContainsKey('AllowGitHubWrites')) { $config.connectors.github.allowWrites = [bool]$AllowGitHubWrites }
    if ($PSCmdlet.ShouldProcess($paths.Config, 'Update ticker configuration')) { Write-RTJsonAtomic $paths.Config $config }
    $config
}

function Invoke-RTNative {
    param([Parameter(Mandatory)][string]$Command, [string[]]$Arguments = @())
    $output = @(& $Command @Arguments 2>&1)
    [pscustomobject]@{ ExitCode = $LASTEXITCODE; Output = ($output -join [Environment]::NewLine).Trim() }
}

function Test-RTConnector {
    [CmdletBinding()]
    param([string]$Root, [string]$Repository)
    $config = Get-RTConfig -Root $Root
    if ($Repository) { $config.repository.name = $Repository }
    $localPath = [string]$config.repository.localPath
    $results = @()

    if ([bool]$config.connectors.git.enabled) {
        $git = Get-Command git -ErrorAction SilentlyContinue
        $ok = [bool]$git
        $detail = if ($git) { (Invoke-RTNative -Command git -Arguments @('--version')).Output } else { 'git was not found in PATH' }
        if ($git -and (Test-Path -LiteralPath $localPath)) {
            $probe = Invoke-RTNative -Command git -Arguments @('-C', $localPath, 'rev-parse', '--is-inside-work-tree')
            $detail = if ($probe.ExitCode -eq 0) { "connected; $detail" } else { "available; path is not a Git worktree" }
        }
        $results += [pscustomobject]@{ Name = 'git'; Enabled = $true; Healthy = $ok; Detail = $detail }
    }

    if ([bool]$config.connectors.github.enabled) {
        $gh = Get-Command gh -ErrorAction SilentlyContinue
        $healthy = $false
        $detail = 'gh was not found in PATH'
        if ($gh) {
            $auth = Invoke-RTNative -Command gh -Arguments @('auth', 'status')
            $healthy = $auth.ExitCode -eq 0
            $detail = if ($healthy) { 'GitHub CLI authenticated' } else { 'GitHub CLI installed but not authenticated' }
            if ($healthy -and $config.repository.name) {
                $view = Invoke-RTNative -Command gh -Arguments @('repo', 'view', [string]$config.repository.name, '--json', 'nameWithOwner', '--jq', '.nameWithOwner')
                $healthy = $view.ExitCode -eq 0
                $detail = if ($healthy) { "connected to $($view.Output)" } else { 'authenticated, but configured repository is unavailable' }
            }
        }
        $results += [pscustomobject]@{ Name = 'github'; Enabled = $true; Healthy = $healthy; Detail = $detail; WritesAllowed = [bool]$config.connectors.github.allowWrites }
    }

    if ([bool]$config.connectors.reporitor.enabled) {
        $modulePath = [string]$config.connectors.reporitor.modulePath
        if (-not [IO.Path]::IsPathRooted($modulePath)) { $modulePath = Join-Path $script:ModuleRoot $modulePath }
        $present = Test-Path -LiteralPath $modulePath
        $results += [pscustomobject]@{ Name = 'reporitor'; Enabled = $true; Healthy = $present; Detail = if ($present) { "module available: $modulePath" } else { "optional module not found: $modulePath" } }
    }
    $results
}

function Invoke-RTConnectorTick {
    [CmdletBinding()]
    param([string]$Root, [string]$Repository)
    $items = @(Test-RTConnector -Root $Root -Repository $Repository)
    [pscustomobject]@{
        Timestamp = Get-RTUtcNow
        Healthy = (@($items | Where-Object { $_.Enabled -and -not $_.Healthy }).Count -eq 0)
        Connectors = $items
    }
}

function Get-RTTicketsInternal {
    param([Parameter(Mandatory)]$Paths)
    @((Read-RTJson $Paths.Tickets @()))
}

function New-RTTicket {
    [CmdletBinding()]
    param(
        [string]$Root,
        [Parameter(Mandatory)][ValidateNotNullOrEmpty()][string]$Title,
        [ValidateSet('Standard','Connector','Subvariance')][string]$Kind = 'Standard',
        [ValidateSet('Low','Normal','High','Critical')][string]$Priority = 'Normal',
        [string]$Connector = '',
        [string]$ParentId = '',
        [double]$VarianceLimit = [double]::NaN,
        [hashtable]$Metadata
    )
    Initialize-RTWorkspace -Root $Root | Out-Null
    Invoke-RTLocked -Root $Root -Action {
        param($paths)
        $config = Read-RTJson $paths.Config $null
        if ([double]::IsNaN($VarianceLimit)) { $limit = [double]$config.subvariance.defaultLimit } else { $limit = $VarianceLimit }
        if ($limit -lt 0) { throw 'VarianceLimit cannot be negative.' }
        $tickets = @(Get-RTTicketsInternal $paths)
        if ($ParentId -and -not ($tickets | Where-Object { $_.id -eq $ParentId })) { throw "Parent ticket '$ParentId' was not found." }
        $now = Get-RTUtcNow
        $ticket = [ordered]@{
            id = 'RT-' + [DateTime]::UtcNow.ToString('yyyyMMddHHmmssfff') + '-' + (Get-Random -Minimum 100 -Maximum 999)
            title = $Title
            kind = $Kind
            priority = $Priority
            state = 'Open'
            connector = $Connector
            parentId = $ParentId
            varianceLimit = $limit
            observedVariance = 0.0
            varianceState = 'WithinLimit'
            createdAt = $now
            updatedAt = $now
            metadata = if ($Metadata) { $Metadata } else { @{} }
        }
        $tickets += [pscustomobject]$ticket
        Write-RTJsonAtomic $paths.Tickets $tickets
        [pscustomobject]$ticket
    }
}

function New-RTSubvarianceTicket {
    [CmdletBinding()]
    param(
        [string]$Root,
        [Parameter(Mandatory)][string]$Title,
        [Parameter(Mandatory)][string]$ParentId,
        [ValidateRange(0,1.7976931348623157E+308)][double]$VarianceLimit = 0.15,
        [ValidateSet('Low','Normal','High','Critical')][string]$Priority = 'Normal'
    )
    New-RTTicket -Root $Root -Title $Title -Kind Subvariance -Priority $Priority -ParentId $ParentId -VarianceLimit $VarianceLimit
}

function Get-RTTicket {
    [CmdletBinding()]
    param([string]$Root, [string]$Id, [ValidateSet('Open','Ready','Running','Blocked','Done','Cancelled')][string]$State)
    $paths = Get-RTPaths $Root
    Initialize-RTWorkspace -Root $paths.Root | Out-Null
    $tickets = @(Get-RTTicketsInternal $paths)
    if ($Id) { $tickets = @($tickets | Where-Object { $_.id -eq $Id }) }
    if ($State) { $tickets = @($tickets | Where-Object { $_.state -eq $State }) }
    $tickets
}

function Set-RTTicketState {
    [CmdletBinding(SupportsShouldProcess)]
    param([string]$Root, [Parameter(Mandatory)][string]$Id, [Parameter(Mandatory)][ValidateSet('Open','Ready','Running','Blocked','Done','Cancelled')][string]$State)
    Invoke-RTLocked -Root $Root -Action {
        param($paths)
        $tickets = @(Get-RTTicketsInternal $paths)
        $ticket = $tickets | Where-Object { $_.id -eq $Id } | Select-Object -First 1
        if (-not $ticket) { throw "Ticket '$Id' was not found." }
        if ($PSCmdlet.ShouldProcess($Id, "Set ticket state to $State")) {
            $ticket.state = $State
            $ticket.updatedAt = Get-RTUtcNow
            Write-RTJsonAtomic $paths.Tickets $tickets
        }
        $ticket
    }
}

function Set-RTTicketVariance {
    [CmdletBinding(SupportsShouldProcess)]
    param([string]$Root, [Parameter(Mandatory)][string]$Id, [Parameter(Mandatory)][double]$ObservedVariance)
    Invoke-RTLocked -Root $Root -Action {
        param($paths)
        $config = Read-RTJson $paths.Config $null
        $tickets = @(Get-RTTicketsInternal $paths)
        $ticket = $tickets | Where-Object { $_.id -eq $Id } | Select-Object -First 1
        if (-not $ticket) { throw "Ticket '$Id' was not found." }
        $absolute = [Math]::Abs($ObservedVariance)
        $breached = $absolute -gt [double]$ticket.varianceLimit
        if ($PSCmdlet.ShouldProcess($Id, "Record observed variance $absolute")) {
            $ticket.observedVariance = $absolute
            $ticket.varianceState = if ($breached) { 'Breached' } else { 'WithinLimit' }
            if ($breached -and [string]$config.subvariance.breachAction -eq 'Block' -and $ticket.state -notin @('Done','Cancelled')) { $ticket.state = 'Blocked' }
            $ticket.updatedAt = Get-RTUtcNow
            Write-RTJsonAtomic $paths.Tickets $tickets
        }
        $ticket
    }
}

function Get-RTStopRequest {
    param([Parameter(Mandatory)]$Paths)
    Read-RTJson $Paths.StopRequest $null
}

function Stop-ReporitorTicker {
    [CmdletBinding(SupportsShouldProcess)]
    param([string]$Root, [ValidateSet('Immediate','AfterTick','Drain')][string]$Mode = 'AfterTick', [string]$Reason = 'Operator request')
    $paths = Get-RTPaths $Root
    Initialize-RTWorkspace -Root $paths.Root | Out-Null
    $request = [ordered]@{ mode = $Mode; reason = $Reason; requestedAt = Get-RTUtcNow }
    if ($PSCmdlet.ShouldProcess($paths.StopRequest, "Request $Mode termination")) { Write-RTJsonAtomic $paths.StopRequest $request }
    [pscustomobject]$request
}

function Test-RTDrainComplete {
    param([Parameter(Mandatory)]$Paths)
    $tickets = @(Get-RTTicketsInternal $Paths)
    @($tickets | Where-Object { $_.state -in @('Ready','Running') }).Count -eq 0
}

function Wait-RTInterval {
    param([Parameter(Mandatory)][int]$Seconds, [Parameter(Mandatory)]$Paths)
    $deadline = [DateTime]::UtcNow.AddSeconds($Seconds)
    while ([DateTime]::UtcNow -lt $deadline) {
        $stop = Get-RTStopRequest $Paths
        if ($stop -and $stop.mode -eq 'Immediate') { return $false }
        $remaining = ($deadline - [DateTime]::UtcNow).TotalMilliseconds
        if ($remaining -le 0) { break }
        Start-Sleep -Milliseconds ([Math]::Min(250, [Math]::Ceiling($remaining)))
    }
    $true
}

function Invoke-RTTick {
    [CmdletBinding()]
    param([string]$Root, [string]$Repository, [int]$TickNumber = 1)
    $paths = Get-RTPaths $Root
    Initialize-RTWorkspace -Root $paths.Root -Repository $Repository | Out-Null
    $connector = Invoke-RTConnectorTick -Root $paths.Root -Repository $Repository
    $tickets = @(Get-RTTicketsInternal $paths)
    $counts = [ordered]@{}
    foreach ($state in @('Open','Ready','Running','Blocked','Done','Cancelled')) { $counts[$state] = @($tickets | Where-Object { $_.state -eq $state }).Count }
    $breaches = @($tickets | Where-Object { $_.varianceState -eq 'Breached' }).Count
    $payload = [ordered]@{
        schemaVersion = 1
        tick = $TickNumber
        timestamp = Get-RTUtcNow
        repository = if ($Repository) { $Repository } else { [string](Get-RTConfig -Root $paths.Root).repository.name }
        connectorHealthy = [bool]$connector.Healthy
        connectors = @($connector.Connectors)
        ticketCounts = $counts
        subvarianceBreaches = $breaches
    }
    $canonical = $payload | ConvertTo-Json -Depth 12 -Compress
    $payload['sha256'] = ConvertTo-RTHash $canonical
    Add-Content -LiteralPath $paths.TickLog -Value ($payload | ConvertTo-Json -Depth 12 -Compress) -Encoding UTF8
    Write-RTJsonAtomic $paths.Status ([ordered]@{ state = 'Running'; tick = $TickNumber; updatedAt = $payload.timestamp; connectorHealthy = $payload.connectorHealthy; ticketCounts = $counts; subvarianceBreaches = $breaches })
    [pscustomobject]$payload
}

function Start-ReporitorTicker {
    [CmdletBinding()]
    param(
        [string]$Root,
        [string]$Repository,
        [ValidateRange(1,86400)][int]$IntervalSeconds,
        [ValidateRange(1,2147483647)][int]$MaxTicks,
        [switch]$Continuous
    )
    $paths = Get-RTPaths $Root
    Initialize-RTWorkspace -Root $paths.Root -Repository $Repository | Out-Null
    $config = Get-RTConfig -Root $paths.Root
    if (-not $PSBoundParameters.ContainsKey('IntervalSeconds')) { $IntervalSeconds = [int]$config.ticker.intervalSeconds }
    if ($Continuous) { $MaxTicks = [int]::MaxValue }
    elseif (-not $PSBoundParameters.ContainsKey('MaxTicks')) { $MaxTicks = [int]$config.ticker.maxTicks }
    if (Test-Path -LiteralPath $paths.StopRequest) { Remove-Item -LiteralPath $paths.StopRequest -Force }

    $reason = 'Maximum tick count reached'
    $completed = 0
    $runnerStream = $null
    try {
        $runnerStream = [IO.File]::Open($paths.RunnerLock, [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
    }
    catch {
        throw "Another Reporitor ticker is already running for '$($paths.Root)'."
    }
    try {
        for ($tick = 1; $tick -le $MaxTicks; $tick++) {
            $stop = Get-RTStopRequest $paths
            if ($stop -and $stop.mode -eq 'Immediate') { $reason = [string]$stop.reason; break }
            if ($stop -and $stop.mode -eq 'Drain' -and (Test-RTDrainComplete $paths)) { $reason = [string]$stop.reason; break }

            $result = Invoke-RTTick -Root $paths.Root -Repository $Repository -TickNumber $tick
            $completed = $tick
            Write-Output $result

            $stop = Get-RTStopRequest $paths
            if ($stop -and $stop.mode -eq 'AfterTick') { $reason = [string]$stop.reason; break }
            if ($stop -and $stop.mode -eq 'Drain' -and (Test-RTDrainComplete $paths)) { $reason = [string]$stop.reason; break }
            if ($tick -lt $MaxTicks) {
                if (-not (Wait-RTInterval -Seconds $IntervalSeconds -Paths $paths)) {
                    $stop = Get-RTStopRequest $paths
                    $reason = if ($stop) { [string]$stop.reason } else { 'Immediate termination requested' }
                    break
                }
            }
        }
    }
    catch [Management.Automation.PipelineStoppedException] { $reason = 'Pipeline stopped by operator' }
    catch { $reason = "Fault: $($_.Exception.Message)"; throw }
    finally {
        try {
            Write-RTJsonAtomic $paths.Status ([ordered]@{ state = 'Terminated'; tick = $completed; updatedAt = Get-RTUtcNow; reason = $reason })
            if (Test-Path -LiteralPath $paths.StopRequest) { Remove-Item -LiteralPath $paths.StopRequest -Force }
        }
        finally {
            if ($runnerStream) { $runnerStream.Dispose() }
        }
    }
}

function Get-RTStatus {
    [CmdletBinding()]
    param([string]$Root)
    $paths = Get-RTPaths $Root
    Initialize-RTWorkspace -Root $paths.Root | Out-Null
    Read-RTJson $paths.Status $null
}

function Test-RTState {
    [CmdletBinding()]
    param([string]$Root)
    $paths = Get-RTPaths $Root
    $errors = @()
    try { $null = Get-RTConfig -Root $paths.Root } catch { $errors += "Config: $($_.Exception.Message)" }
    try {
        foreach ($ticket in @(Get-RTTicket -Root $paths.Root)) {
            if (-not $ticket.id -or -not $ticket.title) { $errors += 'A ticket is missing id or title.' }
            if ([double]$ticket.observedVariance -lt 0) { $errors += "Ticket $($ticket.id) has negative observed variance." }
        }
    } catch { $errors += "Tickets: $($_.Exception.Message)" }
    [pscustomobject]@{ Valid = ($errors.Count -eq 0); Errors = $errors; Root = $paths.Root }
}

Export-ModuleMember -Function @(
    'Initialize-RTWorkspace', 'Get-RTConfig', 'Set-RTConfig',
    'Test-RTConnector', 'Invoke-RTConnectorTick',
    'New-RTTicket', 'New-RTSubvarianceTicket', 'Get-RTTicket',
    'Set-RTTicketState', 'Set-RTTicketVariance',
    'Invoke-RTTick', 'Start-ReporitorTicker',
    'Stop-ReporitorTicker', 'Get-RTStatus', 'Test-RTState'
)
