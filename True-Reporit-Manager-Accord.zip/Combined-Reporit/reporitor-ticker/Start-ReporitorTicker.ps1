[CmdletBinding()]
param(
    [string]$Root,
    [string]$Repository,
    [ValidateRange(1, 86400)][int]$IntervalSeconds,
    [ValidateRange(1, 2147483647)][int]$MaxTicks,
    [switch]$Continuous
)

$modulePath = Join-Path $PSScriptRoot 'ReporitorTicker.psd1'
Import-Module $modulePath -Force -ErrorAction Stop

$initialization = @{}
if ($Root) { $initialization.Root = $Root }
if ($Repository) { $initialization.Repository = $Repository }

$arguments = @{} + $initialization
if ($PSBoundParameters.ContainsKey('IntervalSeconds')) { $arguments.IntervalSeconds = $IntervalSeconds }
if ($PSBoundParameters.ContainsKey('MaxTicks')) { $arguments.MaxTicks = $MaxTicks }
if ($Continuous) { $arguments.Continuous = $true }

Initialize-RTWorkspace @initialization | Out-Null
Start-ReporitorTicker @arguments
