@{
    RootModule = 'ReporitorTicker.psm1'
    ModuleVersion = '1.0.0'
    GUID = 'ff5b786f-ae74-439e-a9c3-765095f280be'
    Author = 'Reporitor Ticker Accord'
    CompanyName = 'Independent'
    Copyright = 'Copyright (c) 2026. All rights reserved.'
    Description = 'Finite PowerShell ticket ticker, repository connector sidecar, subvariance governor, and controlled termination layer.'
    PowerShellVersion = '5.1'
    FunctionsToExport = @(
        'Initialize-RTWorkspace', 'Get-RTConfig', 'Set-RTConfig',
        'Test-RTConnector', 'Invoke-RTConnectorTick',
        'New-RTTicket', 'New-RTSubvarianceTicket', 'Get-RTTicket',
        'Set-RTTicketState', 'Set-RTTicketVariance',
        'Invoke-RTTick', 'Start-ReporitorTicker',
        'Stop-ReporitorTicker', 'Get-RTStatus', 'Test-RTState'
    )
    CmdletsToExport = @()
    VariablesToExport = @()
    AliasesToExport = @()
    PrivateData = @{
        PSData = @{
            Tags = @('PowerShell', 'GitHub', 'Git', 'Repository', 'Ticker', 'Tickets', 'Governance')
        }
    }
}
