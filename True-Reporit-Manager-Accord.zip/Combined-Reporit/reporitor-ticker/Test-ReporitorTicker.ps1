$ErrorActionPreference = 'Stop'
$module = Join-Path $PSScriptRoot 'ReporitorTicker.psd1'
$testRoot = Join-Path ([IO.Path]::GetTempPath()) ('ReporitorTicker-Test-' + [Guid]::NewGuid().ToString('N'))

try {
    Import-Module $module -Force
    Initialize-RTWorkspace -Root $testRoot | Out-Null
    $parent = New-RTTicket -Root $testRoot -Title 'Connector baseline' -Kind Connector -Connector git
    $child = New-RTSubvarianceTicket -Root $testRoot -Title 'Bounded drift' -ParentId $parent.id -VarianceLimit 0.10
    $child = Set-RTTicketVariance -Root $testRoot -Id $child.id -ObservedVariance 0.20 -Confirm:$false
    if ($child.state -ne 'Blocked' -or $child.varianceState -ne 'Breached') { throw 'Subvariance breach did not block the ticket.' }
    $tick = Invoke-RTTick -Root $testRoot -TickNumber 1
    if (-not $tick.sha256 -or $tick.tick -ne 1) { throw 'Tick receipt was not generated.' }
    Stop-ReporitorTicker -Root $testRoot -Mode Immediate -Reason 'Test stop' -Confirm:$false | Out-Null
    if (-not (Test-Path (Join-Path $testRoot 'stop.request.json'))) { throw 'Stop request was not written.' }
    $validation = Test-RTState -Root $testRoot
    if (-not $validation.Valid) { throw ($validation.Errors -join '; ') }
    [pscustomobject]@{ Passed = $true; Root = $testRoot; ParentTicket = $parent.id; SubvarianceTicket = $child.id; TickHash = $tick.sha256 }
}
finally {
    if (Test-Path -LiteralPath $testRoot) { Remove-Item -LiteralPath $testRoot -Recurse -Force }
}
