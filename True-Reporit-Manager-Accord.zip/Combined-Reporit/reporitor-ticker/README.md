# Reporitor Ticker — standard PowerShell variant

This is the connector-side ticker for the Reporitor repository manager. It is a finite, inspectable PowerShell controller with configuration, repository connector health, local tickets, child/subvariance tickets, tick receipts, and explicit termination control.

It works on Windows PowerShell 5.1 and PowerShell 7+. `git`, `gh`, and the adjacent Reporitor module are detected individually; missing optional connectors are reported instead of crashing workspace initialization. No GitHub write is performed by this ticker.

## Blue-line structure

1. **Configuration line** — `config.json` selects interval, maximum ticks, repository, connectors, and variance policy.
2. **Connector line** — each side tick checks Git, GitHub CLI authentication/repository access, and the optional Reporitor module.
3. **Ticket line** — standard, connector, and subvariance tickets live in one atomic JSON state file.
4. **Variance line** — absolute observed variance is compared with the ticket limit; the standard policy blocks a breached ticket.
5. **Receipt line** — every tick appends a compact NDJSON receipt with a SHA-256 digest.
6. **Termination line** — stop control is checked before work and after every tick.

Runtime state is stored outside the source directory under `%LOCALAPPDATA%\ReporitorTicker`. Set `REPORITOR_TICKER_ROOT` or pass `-Root` to choose another location.

## Quick start

```powershell
Import-Module .\ReporitorTicker.psd1 -Force

Initialize-RTWorkspace -Repository owner/repository
Set-RTConfig -Repository owner/repository -IntervalSeconds 5 -MaxTicks 12
Test-RTConnector

$ticket = New-RTTicket -Title 'Inspect repository connector' -Kind Connector -Connector github
Set-RTTicketState -Id $ticket.id -State Ready

Start-ReporitorTicker -Repository owner/repository
Get-RTStatus
```

The simple entry script performs the same setup:

```powershell
.\Start-ReporitorTicker.ps1 -Repository owner/repository -IntervalSeconds 5 -MaxTicks 12
```

Use `-Continuous` only when a long-running controller is intended.

## Tickets and subvariance

```powershell
$parent = New-RTTicket -Title 'Repository rollout' -Kind Standard -Priority High
$child = New-RTSubvarianceTicket `
    -Title 'Watch connector timing drift' `
    -ParentId $parent.id `
    -VarianceLimit 0.10

Set-RTTicketVariance -Id $child.id -ObservedVariance 0.04
Set-RTTicketVariance -Id $child.id -ObservedVariance 0.18
Get-RTTicket -Id $child.id
```

With the supplied policy, the second update marks the child as `Breached` and changes an unfinished ticket to `Blocked`. The ticker reports the number of breaches; it does not invent corrective work.

## Termination modes

Termination control sits above the tick loop and is checked at both cycle boundaries.

| Mode | Behaviour |
| --- | --- |
| `Immediate` | Stop before the next tick begins. |
| `AfterTick` | Finish one current/final tick, then stop. |
| `Drain` | Stop once no ticket remains in `Ready` or `Running`. |

From another PowerShell window using the same root:

```powershell
Stop-ReporitorTicker -Mode AfterTick -Reason 'Maintenance boundary'
```

The stop request is a small JSON control file. The controller removes it after termination and writes the final reason into `status.json`.

## Connector safety

- Git and GitHub checks are read-only.
- `allowWrites` defaults to `false` and is recorded only as policy state; this module contains no GitHub mutation command.
- Authentication tokens are neither read nor logged.
- The Reporitor module is optional and detected by relative path `..\Reporitor\Reporitor.psd1` when both packages are placed side by side.
- Runtime JSON writes use a temporary file and atomic replacement.
- A process lock prevents concurrent ticket-state writers.

## Verify

```powershell
.\Test-ReporitorTicker.ps1
Test-RTState
```

The included test creates a parent ticket, a breached subvariance child, a tick receipt, and an immediate stop request in a temporary workspace.
