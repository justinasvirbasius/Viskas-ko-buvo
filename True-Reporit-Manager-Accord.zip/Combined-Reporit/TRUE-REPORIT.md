# True Reporit manager accord

This package joins the prior Python Server Script Manager, the PowerShell ticker, and the earlier ShellNotion/Gits/Reporitor envelope. `Start-TrueReporit.ps1` coordinates a local ticker tick with an optional finite GitHub repository report, and writes a linked local receipt for each completed round.

## Privilege degree

| Operation | Default | Explicit enabling |
| --- | --- | --- |
| Local ticker and receipt writes | Yes, in `manager-state` | `-StateRoot` selects another directory |
| GitHub repository reads and local bot reports | No | `-EnableRemoteReads`, authenticated `gh` |
| GitHub writes (issues, PRs, repository creation) | No | Use the separate Reporitor commands with their own `-Commit` gates; the combined manager never calls them |
| Destructive disk cleanup | No | Separate Python manager policy gates and `--apply` |

## Commands

Run from the package directory in PowerShell 7 or Windows PowerShell 5.1:

```powershell
.\Start-TrueReporit.ps1 -Action Forecast -Repository owner/name
.\Start-TrueReporit.ps1 -Action Run -Repository owner/name -Rounds 3 -IntervalSeconds 5
.\Start-TrueReporit.ps1 -Action Run -Repository owner/name -Rounds 2 -EnableRemoteReads
.\Start-TrueReporit.ps1 -Action Stop
.\Start-TrueReporit.ps1 -Action Status
.\Start-TrueReporit.ps1 -Action Verify
```

Use the same `-StateRoot` on Run, Stop, Status and Verify when overriding the default. Stop is observed between ticks and during interval waits; it cannot interrupt an active network request. The manager lock prevents two runs against the same state directory. A start clears an old stop request. Run `Verify` before continuing a previous ledger. The receipt hashes detect accidental changes, but do not authenticate an attacker who can rewrite the whole ledger. The remote bot has its own report ledger and policy.

For the Python scheduler and disk routines, use `server-script-manager/README.md` and `integration/ssm.reporitor.example.toml`. For explicit GitHub operations and policy read `Reporitor/README.md`; ticker configuration is described in `reporitor-ticker/README.md`. These components have distinct state and policy settings.
