# Server Script Manager (SSM)

SSM is a small, dependency-free Python control plane for routine server and disk checks. It provides guarded built-in routines, an interval runner, a configuration and resource forecast, and an optional isolated native connector for C, C++, or Rust code.

## Design and operating modes

- **Python is the manager.** It loads TOML policy, schedules routines, serializes work, validates allowed roots, and emits JSON results.
- **Observe** is read-only. **Propose** (default) permits reports and previews. **Apply** is an explicit policy mode for approved actions.
- Cleanup is preview-only by default. To actually remove eligible files, both `manager.mode = "apply"` and `policy.allow_destructive = true` must be configured, and the operator must also pass `--apply` to the one cleanup invocation. Cleanup only considers regular, old files beneath `cleanup_roots`, themselves constrained to `allowed_roots`. Symlinks are skipped.
- No command strings are evaluated by a shell, no elevated permissions are requested, and routines do not restart services or modify disks/partitions.
- Each routine run in the manager is serialized. The forecast highlights shared write resources, invalid scheduled routines, low disk headroom, and unavailable native libraries. Treat warnings as an operations review queue.
- Native code is loaded in a separate Python worker with a timeout, bounded JSON output, and ABI version check. This contains hangs and ordinary crashes; it does not make untrusted native code safe. Only load libraries you built or trust. For stronger isolation, run the worker as a low-privilege OS account inside a container/service sandbox.

## Quick start

Requires Python 3.11+. No third-party Python packages are required.

```sh
python -m venv .venv
# Linux/macOS:
. .venv/bin/activate
# Windows PowerShell:
# .\.venv\Scripts\Activate.ps1
python -m pip install -e .
cp ssm.example.toml ssm.toml  # PowerShell: Copy-Item ssm.example.toml ssm.toml
mkdir -p data/cache           # PowerShell: New-Item -ItemType Directory -Force data/cache
ssm --config ssm.toml routines
ssm --config ssm.toml forecast
ssm --config ssm.toml run disk_report
ssm --config ssm.toml run cleanup # preview only
ssm --config ssm.toml serve       # Ctrl+C stops the manager
```

Without installing, run commands from this directory with `PYTHONPATH=src python -m server_script_manager.cli --config ssm.toml forecast` (PowerShell: `$env:PYTHONPATH='src'; python -m server_script_manager.cli --config ssm.toml forecast`).

To enable cleanup, edit `ssm.toml`, verify the cleanup roots carefully, set `manager.mode = "apply"` and `policy.allow_destructive = true`, then run the explicit command `ssm --config ssm.toml run cleanup --apply`. First run it without `--apply` to review the candidate list. It never cleans outside the configured roots. Back up important data and run under an account with only the required permissions.

## Built-in routines

| Routine | Effect |
|---|---|
| `disk_report` | Reports total, used, and free bytes for allowed roots and marks configured free-space threshold breaches. |
| `inventory` | Counts files, directories, and bytes, with symlink traversal disabled and a file-count cap. |
| `log_age_report` | Lists old `.log`, `.out`, and `.err` files; does not alter them. |
| `cleanup` | Shows eligible old files by default; the two policy gates plus `--apply` are required to unlink them. |
| `native` | Runs the configured native connector in the isolated worker when enabled. |

`serve` starts all configured interval jobs immediately, then repeats them at their configured interval. Jobs execute serially in one manager process. Resource declarations (`reads`, `writes`) let `forecast` identify overlapping ownership; they are planning labels, not OS locks. Use one SSM instance per managed root unless you add an external lock/lease service.

## Combination forecast

`ssm forecast` computes a simple operational forecast before jobs run:

1. validates routine names in the schedule;
2. flags jobs whose declared read/write resources overlap;
3. checks allowed-root existence and free space against `min_free_bytes`;
4. checks the native library path, enabled state, platform and architecture metadata.

It does not claim to predict arbitrary resource use by opaque third-party code. Adjust resource labels and thresholds to match the deployed routines. The `decision` field is `clear` or `review-required`.

## Native runtime connector (ABI v1)

The native library exports these C ABI functions:

```c
int ssm_abi_version(void);
int ssm_run(const char *routine_utf8, const char *input_json_utf8,
            char *output_utf8, size_t output_capacity);
```

`ssm_run` writes a UTF-8 JSON object into the caller-owned buffer and returns the number of bytes written (0 to capacity); a negative result means failure. It must not write beyond capacity, retain pointers after return, or print protocol data to stdout. The worker validates the JSON and caps output at 65,536 bytes. Compile with the platform's ordinary shared-library toolchain. Example files are in `connectors/c`, `connectors/cpp`, and `connectors/rust`.

Build commands for Linux, macOS and Windows are in `connectors/BUILDING.md`. Point `[native].library` at the built library and keep it under `[native].directory`; set `enabled = true`. The manager rejects libraries outside that directory and kills a hung worker after `timeout_seconds`. ABI checks occur at call time. Windows DLLs use the C calling convention (`cdecl`).

## Configuration reference

- `[manager]`: `mode`, `poll_seconds`.
- `[policy]`: `allowed_roots`, `cleanup_roots`, `cleanup_older_than_days`, `max_files`, `max_output_bytes` (minimum 1,024 bytes), `min_free_bytes`, `allow_destructive`.
- `[native]`: `enabled`, `directory`, optional `library`, `routine`, `timeout_seconds`.
- `[[jobs]]`: unique `name`, supported `routine`, `every_seconds >= 1`, and optional resource arrays `reads` / `writes`.

Relative paths resolve from the TOML file location. Paths are expanded and resolved at startup. Keep configuration writable only by trusted administrators; it controls which locations cleanup can modify.

## Development and verification

Run tests with `python -m unittest discover -s tests -v`. The tests cover config confinement, dry-run and apply gates, inventory, resource forecasts, and routine dispatch. Native examples are source only and must be compiled for the target operating system and architecture.
