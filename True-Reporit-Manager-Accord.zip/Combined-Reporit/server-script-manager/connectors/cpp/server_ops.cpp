#include <cstddef>
#include <cstdio>
#include <cstring>

#if defined(_WIN32)
#define SSM_EXPORT __declspec(dllexport)
#else
#define SSM_EXPORT __attribute__((visibility("default")))
#endif

extern "C" SSM_EXPORT int ssm_abi_version(void) { return 1; }

extern "C" SSM_EXPORT int ssm_run(const char *routine, const char *input_json,
                                  char *output, std::size_t capacity) {
    if (!routine || !input_json || !output || capacity == 0) return -1;
    if (std::strcmp(routine, "health_probe") != 0) return -2;
    const int n = std::snprintf(output, capacity,
                                "{\"ok\":true,\"connector\":\"cpp\",\"received\":true}");
    if (n < 0 || static_cast<std::size_t>(n) >= capacity) return -3;
    return n;
}
