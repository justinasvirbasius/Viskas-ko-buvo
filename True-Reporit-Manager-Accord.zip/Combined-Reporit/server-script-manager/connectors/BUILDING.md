# Building the example connector libraries

Build the language example you want with a compiler for the target operating system and architecture. Put the resulting shared library beneath the `native.directory` path in `ssm.toml`; use its exact filename as `native.library`. The manager checks that the library remains in that directory.

## Linux

```sh
cc -shared -fPIC connectors/c/server_ops.c -o connectors/libserver_ops.so
c++ -shared -fPIC connectors/cpp/server_ops.cpp -o connectors/libserver_ops_cpp.so
(cd connectors/rust && cargo build --release)
# Rust output: connectors/rust/target/release/libssm_native_example.so
```

## macOS

```sh
cc -dynamiclib connectors/c/server_ops.c -o connectors/libserver_ops.dylib
c++ -dynamiclib connectors/cpp/server_ops.cpp -o connectors/libserver_ops_cpp.dylib
(cd connectors/rust && cargo build --release)
# Rust output: connectors/rust/target/release/libssm_native_example.dylib
```

## Windows (Visual Studio Developer PowerShell)

```powershell
cl /LD /O2 connectors\c\server_ops.c /link /OUT:connectors\server_ops.dll
cl /LD /O2 /EHsc connectors\cpp\server_ops.cpp /link /OUT:connectors\server_ops_cpp.dll
cd connectors\rust; cargo build --release; cd ..\..
# Rust output: connectors\rust\target\release\ssm_native_example.dll
```

Example configuration for the C build on Windows:

```toml
[native]
enabled = true
directory = "./connectors"
library = "./connectors/server_ops.dll"
routine = "health_probe"
timeout_seconds = 10
```

The source is portable sample code. Build and test the resulting binary on the same OS and CPU architecture as the Python runtime that will load it. `cargo` is only needed for the Rust example; the Python manager itself has no third-party dependencies.

