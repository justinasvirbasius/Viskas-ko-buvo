#include <stddef.h>
#include <stdio.h>
#include <string.h>

#if defined(_WIN32)
#define SSM_EXPORT __declspec(dllexport)
#else
#define SSM_EXPORT __attribute__((visibility("default")))
#endif

/* ABI v1: return JSON byte length, or a negative error code. */
SSM_EXPORT int ssm_abi_version(void) { return 1; }

SSM_EXPORT int ssm_run(const char *routine, const char *input_json,
                       char *output, size_t capacity) {
    if (!routine || !input_json || !output || capacity == 0) return -1;
    if (strcmp(routine, "health_probe") != 0) return -2;
    int n = snprintf(output, capacity, "{\"ok\":true,\"connector\":\"c\",\"received\":true}");
    if (n < 0 || (size_t)n >= capacity) return -3;
    return n;
}
