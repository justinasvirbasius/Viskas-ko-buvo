use std::ffi::CStr;
use std::os::raw::{c_char, c_int};
use std::ptr;

#[no_mangle]
pub extern "C" fn ssm_abi_version() -> c_int { 1 }

#[no_mangle]
pub unsafe extern "C" fn ssm_run(
    routine: *const c_char,
    _input_json: *const c_char,
    output: *mut c_char,
    capacity: usize,
) -> c_int {
    if routine.is_null() || _input_json.is_null() || output.is_null() || capacity == 0 { return -1; }
    let name = match CStr::from_ptr(routine).to_str() { Ok(v) => v, Err(_) => return -2 };
    if name != "health_probe" { return -3; }
    let result = b"{\"ok\":true,\"connector\":\"rust\",\"received\":true}";
    if result.len() > capacity { return -4; }
    ptr::copy_nonoverlapping(result.as_ptr(), output.cast::<u8>(), result.len());
    result.len() as c_int
}
