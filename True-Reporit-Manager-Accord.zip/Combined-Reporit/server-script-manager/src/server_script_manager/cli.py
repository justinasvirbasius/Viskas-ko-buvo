from __future__ import annotations

import argparse
import json
import sys

from .config import load_config
from .manager import ScriptManager


def main() -> int:
    parser = argparse.ArgumentParser(prog="ssm", description="Guarded server script manager")
    parser.add_argument("--config", default="ssm.toml", help="path to TOML configuration")
    subs = parser.add_subparsers(dest="command", required=True)
    subs.add_parser("routines", help="list supported routines")
    subs.add_parser("forecast", help="preview disk, native connector, and job combinations")
    run = subs.add_parser("run", help="run one routine")
    run.add_argument("routine")
    run.add_argument("--apply", action="store_true", help="apply a destructive routine action (policy must also allow it)")
    subs.add_parser("serve", help="run configured interval jobs until interrupted")
    args = parser.parse_args()
    try:
        manager = ScriptManager(load_config(args.config))
        if args.command == "routines":
            result = manager.list_routines()
        elif args.command == "forecast":
            result = manager.forecast()
        elif args.command == "run":
            result = manager.run(args.routine, apply=args.apply)
        else:
            manager.serve()
            return 0
        print(json.dumps(result, indent=2))
        return 0
    except KeyboardInterrupt:
        return 130
    except Exception as e:
        print(f"ssm: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

