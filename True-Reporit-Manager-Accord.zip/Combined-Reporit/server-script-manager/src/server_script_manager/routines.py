from __future__ import annotations

import os
import shutil
import time
from pathlib import Path
from typing import Any

from .config import Config


def _within(path: Path, roots: tuple[Path, ...]) -> bool:
    resolved = path.resolve()
    return any(resolved == root or resolved.is_relative_to(root) for root in roots)


def disk_report(config: Config, apply: bool = False) -> dict[str, Any]:
    rows = []
    for root in config.allowed_roots:
        if not root.exists():
            rows.append({"path": str(root), "exists": False})
            continue
        usage = shutil.disk_usage(root)
        rows.append({"path": str(root), "exists": True, "total_bytes": usage.total,
                     "used_bytes": usage.used, "free_bytes": usage.free,
                     "below_min_free": usage.free < config.min_free_bytes})
    return {"routine": "disk_report", "mode": config.mode, "roots": rows}


def inventory(config: Config, apply: bool = False) -> dict[str, Any]:
    files, dirs, bytes_seen, capped = 0, 0, 0, False
    roots_report = []
    for root in config.allowed_roots:
        count = 0
        if not root.exists():
            roots_report.append({"path": str(root), "exists": False, "files": 0})
            continue
        for current, dirnames, filenames in os.walk(root, followlinks=False):
            current_path = Path(current)
            dirnames[:] = [d for d in dirnames if not (current_path / d).is_symlink()]
            dirs += len(dirnames)
            for filename in filenames:
                p = current_path / filename
                if p.is_symlink():
                    continue
                try:
                    stat = p.stat(follow_symlinks=False)
                except OSError:
                    continue
                if not p.is_file():
                    continue
                files += 1
                count += 1
                bytes_seen += stat.st_size
                if files >= config.max_files:
                    capped = True
                    break
            if capped:
                break
        roots_report.append({"path": str(root), "exists": True, "files": count})
        if capped:
            break
    return {"routine": "inventory", "roots": roots_report, "files": files,
            "directories": dirs, "bytes": bytes_seen, "capped": capped}


def log_age_report(config: Config, apply: bool = False) -> dict[str, Any]:
    cutoff = time.time() - config.cleanup_older_than_days * 86400
    old_logs, count, scanned = [], 0, 0
    for root in config.allowed_roots:
        if not root.exists():
            continue
        for current, dirnames, filenames in os.walk(root, followlinks=False):
            here = Path(current)
            dirnames[:] = [d for d in dirnames if not (here / d).is_symlink()]
            for name in filenames:
                p = here / name
                if p.is_symlink() or p.suffix.lower() not in {".log", ".out", ".err"}:
                    continue
                scanned += 1
                try:
                    stat = p.stat(follow_symlinks=False)
                except OSError:
                    continue
                if stat.st_mtime < cutoff:
                    old_logs.append({"path": str(p), "size_bytes": stat.st_size,
                                     "age_days": round((time.time() - stat.st_mtime) / 86400, 1)})
                if scanned >= config.max_files:
                    break
            if scanned >= config.max_files:
                break
    return {"routine": "log_age_report", "older_than_days": config.cleanup_older_than_days,
            "scanned": scanned, "old_logs": old_logs, "capped": scanned >= config.max_files}


def cleanup(config: Config, apply: bool = False) -> dict[str, Any]:
    cutoff = time.time() - config.cleanup_older_than_days * 86400
    candidates: list[Path] = []
    scanned = 0
    removed: list[str] = []
    for root in config.cleanup_roots:
        if not root.exists():
            continue
        for current, dirnames, filenames in os.walk(root, followlinks=False):
            here = Path(current)
            dirnames[:] = [d for d in dirnames if not (here / d).is_symlink()]
            for name in filenames:
                p = here / name
                scanned += 1
                try:
                    st = p.lstat()
                except OSError:
                    continue
                # Only old, regular, non-symlink files inside explicitly configured cleanup roots.
                if p.is_symlink() or not p.is_file() or st.st_mtime >= cutoff or not _within(p, config.cleanup_roots):
                    continue
                candidates.append(p)
                if scanned >= config.max_files:
                    break
            if scanned >= config.max_files:
                break
    if apply:
        if config.mode != "apply" or not config.allow_destructive:
            raise PermissionError("cleanup apply requires manager.mode='apply' and policy.allow_destructive=true")
        for p in candidates:
            try:
                # Re-check the object immediately before unlink; symlinks are never followed.
                st = p.lstat()
                if not p.is_symlink() and p.is_file() and st.st_mtime < cutoff and _within(p, config.cleanup_roots):
                    p.unlink()
                    removed.append(str(p))
            except FileNotFoundError:
                continue
    return {"routine": "cleanup", "mode": "apply" if apply else "preview",
            "candidate_count": len(candidates), "candidate_bytes": sum(p.stat().st_size for p in candidates if p.exists()),
            "removed": removed, "candidates": [str(p) for p in candidates], "scanned": scanned,
            "capped": scanned >= config.max_files}


BUILTINS = {
    "disk_report": disk_report,
    "inventory": inventory,
    "log_age_report": log_age_report,
    "cleanup": cleanup,
}

