from __future__ import annotations

import json
import os
import platform
import subprocess
import sys
from pathlib import Path
from typing import Any

from .config import Config


def native_forecast(config: Config) -> dict[str, Any]:
    result: dict[str, Any] = {"enabled": config.native_enabled, "abi_version": 1,
                              "platform": platform.system(), "architecture": platform.machine()}
    if not config.native_enabled:
        result["status"] = "disabled"
        return result
    if not config.native_library or not config.native_library.exists():
        result.update(status="unavailable", reason="configured native library does not exist")
        return result
    lib = config.native_library.resolve()
    allowed = config.native_dir.resolve() if config.native_dir else None
    if allowed is None or not (lib == allowed or lib.is_relative_to(allowed)):
        result.update(status="blocked", reason="library is outside native.directory")
        return result
    result.update(status="ready", library=str(lib), routine=config.native_routine)
    return result


def run_native(config: Config, payload: dict[str, Any]) -> dict[str, Any]:
    forecast = native_forecast(config)
    if forecast["status"] != "ready":
        raise RuntimeError(f"native connector not ready: {forecast.get('reason', forecast['status'])}")
    assert config.native_library is not None
    proc = subprocess.run(
        [sys.executable, "-m", "server_script_manager.native_worker",
         str(config.native_library.resolve()), config.native_routine],
        input=json.dumps(payload), text=True, capture_output=True,
        timeout=config.native_timeout_seconds, check=False,
        env={**os.environ, "PYTHONPATH": os.pathsep.join(sys.path)},
    )
    if proc.returncode != 0:
        try:
            detail = json.loads(proc.stdout).get("error", proc.stderr.strip())
        except json.JSONDecodeError:
            detail = proc.stderr.strip() or f"worker exited {proc.returncode}"
        raise RuntimeError(f"native worker failed: {detail}")
    response = json.loads(proc.stdout)
    if not response.get("ok"):
        raise RuntimeError(response.get("error", "native worker failed"))
    return response["result"]

