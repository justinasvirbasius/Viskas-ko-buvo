"""Isolated worker for the versioned native connector ABI."""
from __future__ import annotations

import ctypes
import json
import sys
from pathlib import Path

ABI_VERSION = 1
MAX_OUTPUT = 65536


def invoke(library: Path, routine: str, payload: dict) -> dict:
    # Cdecl ABI: int ssm_abi_version(void); int ssm_run(const char *routine,
    # const char *input_json, char *output, size_t capacity).
    lib = ctypes.CDLL(str(library))
    version = lib.ssm_abi_version
    version.argtypes = []
    version.restype = ctypes.c_int
    if version() != ABI_VERSION:
        raise RuntimeError(f"native ABI mismatch; expected {ABI_VERSION}")
    run = lib.ssm_run
    run.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.POINTER(ctypes.c_char), ctypes.c_size_t]
    run.restype = ctypes.c_int
    source = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    output = ctypes.create_string_buffer(MAX_OUTPUT + 1)
    written = run(routine.encode("utf-8"), source, output, MAX_OUTPUT)
    if written < 0:
        raise RuntimeError(f"native routine returned error code {written}")
    if written > MAX_OUTPUT:
        raise RuntimeError("native routine exceeded output limit")
    try:
        parsed = json.loads(output.raw[:written].decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise RuntimeError("native routine returned invalid UTF-8 JSON") from e
    if not isinstance(parsed, dict):
        raise RuntimeError("native routine result must be a JSON object")
    return parsed


def main() -> int:
    try:
        library = Path(sys.argv[1]).resolve()
        routine = sys.argv[2]
        payload = json.load(sys.stdin)
        print(json.dumps({"ok": True, "result": invoke(library, routine, payload)}))
        return 0
    except Exception as e:
        print(json.dumps({"ok": False, "error": str(e)}))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

