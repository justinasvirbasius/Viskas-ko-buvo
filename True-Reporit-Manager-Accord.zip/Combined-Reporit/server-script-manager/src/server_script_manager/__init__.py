"""Guarded server script management toolkit."""

__version__ = "0.1.0"

