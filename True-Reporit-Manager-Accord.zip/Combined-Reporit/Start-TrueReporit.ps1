[CmdletBinding()]
param(
    [ValidateSet('Forecast','Run','Stop','Status','Verify')][string]$Action = 'Forecast',
    [string]$Repository,
    [string]$StateRoot = (Join-Path $PSScriptRoot 'manager-state'),
    [ValidateRange(1,100)][int]$Rounds = 1,
    [ValidateRange(0,86400)][int]$IntervalSeconds = 0,
    [switch]$EnableRemoteReads
)
$ErrorActionPreference = 'Stop'
$state = [IO.Path]::GetFullPath($StateRoot)
$stop = Join-Path $state 'stop.request'
$log = Join-Path $state 'manager.ndjson'
$lock = Join-Path $state 'manager.lock'
$ticker = Join-Path $PSScriptRoot 'reporitor-ticker/ReporitorTicker.psd1'
$reporitor = Join-Path $PSScriptRoot 'Reporitor/Reporitor.psd1'

if ($Action -eq 'Forecast') {
    [pscustomobject]@{
        tickerModule = (Test-Path -LiteralPath $ticker)
        repositoryModule = (Test-Path -LiteralPath $reporitor)
        repository = $Repository
        rounds = $Rounds
        stateRoot = $state
        privilege = if ($EnableRemoteReads) { 'remote-read and local-write' } else { 'local-write only' }
        remoteWrites = $false
    }
    return
}
if (-not (Test-Path -LiteralPath $state)) { [void](New-Item -ItemType Directory -Path $state -Force) }
if ($Action -eq 'Stop') { [IO.File]::WriteAllText($stop, 'operator request'); return [pscustomobject]@{ stopRequested = $true; stateRoot = $state } }
if ($Action -eq 'Status') {
    $entries = if (Test-Path -LiteralPath $log) { @(Get-Content -LiteralPath $log) } else { @() }
    return [pscustomobject]@{ stopRequested = (Test-Path -LiteralPath $stop); roundsRecorded = $entries.Count; latest = if ($entries.Count) { $entries[-1] | ConvertFrom-Json } else { $null } }
}
if ($Action -eq 'Verify') {
    $count = 0
    $previous = 'GENESIS'
    if (Test-Path -LiteralPath $log) {
        foreach ($line in (Get-Content -LiteralPath $log)) {
            $entry = $line | ConvertFrom-Json
            if ($entry.previous -ne $previous -or $entry.sequence -ne ($count + 1)) { throw "Accord link mismatch at round $($count + 1)" }
            $payload = "{0}|{1}|{2}|{3}|{4}" -f $entry.sequence,$entry.timestamp,$entry.repository,$entry.tickerSha256,$entry.previous
            $hash = [BitConverter]::ToString(([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($payload)))).Replace('-','').ToLowerInvariant()
            if ($entry.sha256 -ne $hash) { throw "Accord digest mismatch at round $($count + 1)" }
            $previous = $hash
            $count++
        }
    }
    return [pscustomobject]@{ valid = $true; rounds = $count; head = $previous }
}
if (-not $Repository -or $Repository -notmatch '^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$') { throw 'Run requires -Repository owner/name.' }
if (-not (Test-Path -LiteralPath $ticker) -or -not (Test-Path -LiteralPath $reporitor)) { throw 'A bundled module is missing.' }
$stream = $null
try {
    $stream = [IO.File]::Open($lock, [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
    if (Test-Path -LiteralPath $stop) { Remove-Item -LiteralPath $stop -Force }
    Import-Module $ticker -Force
    Import-Module $reporitor -Force
    $tickerRoot = Join-Path $state 'ticker'
    Initialize-RTWorkspace -Root $tickerRoot -Repository $Repository | Out-Null
    $prior = & $PSCommandPath -Action Verify -StateRoot $state
    for ($round = 1; $round -le $Rounds; $round++) {
        if (Test-Path -LiteralPath $stop) { break }
        $tick = Invoke-RTTick -Root $tickerRoot -Repository $Repository -TickNumber ($prior.rounds + $round)
        $remote = $null
        if ($EnableRemoteReads) { $remote = Invoke-ReporitorBot -Repository $Repository -Rounds 1 -IntervalSeconds 0 -Commit }
        $stamp = [DateTimeOffset]::UtcNow.ToString('o')
        $sequence = $prior.rounds + $round
        $payload = "{0}|{1}|{2}|{3}|{4}" -f $sequence,$stamp,$Repository,$tick.sha256,$prior.head
        $sha = [BitConverter]::ToString(([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($payload)))).Replace('-','').ToLowerInvariant()
        $entry = [ordered]@{ sequence = $sequence; timestamp = $stamp; repository = $Repository; tickerSha256 = $tick.sha256; previous = $prior.head; sha256 = $sha; remoteRead = [bool]$EnableRemoteReads; remoteReportCount = if ($remote) { @($remote.Reports).Count } else { 0 } }
        Add-Content -LiteralPath $log -Value ($entry | ConvertTo-Json -Compress -Depth 5) -Encoding UTF8
        [pscustomobject]$entry
        $prior = [pscustomobject]@{ rounds = $sequence; head = $sha }
        if ($round -lt $Rounds -and $IntervalSeconds -gt 0) {
            for ($i=0; $i -lt $IntervalSeconds; $i++) { if (Test-Path -LiteralPath $stop) { break }; Start-Sleep -Seconds 1 }
        }
    }
} finally { if ($stream) { $stream.Dispose() } }
