@echo off
python "%~dp0WorkScriptature\hash_ula.py" menu
exit /b %errorlevel%
