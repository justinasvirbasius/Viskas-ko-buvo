# True Reporit Scriptature Menu

`Scriptature-Menu.ps1` is the top-level operator menu for the combined accord.
It does not replace the individual scripts; it makes them reachable from one
foreground control surface.

## Start

PowerShell:

```powershell
.\Scriptature-Menu.ps1 -Repository owner/repository
```

Windows Command Prompt:

```cmd
Start-Scriptature.cmd -Repository owner/repository
```

The repository argument is optional. The menu will ask for `owner/name` only
when a repository-scoped operation needs it.

## Sections

1. True Reporit manager — forecast, finite runs, status, stop, ledger verify.
2. Reporitor ticker — workspace, connector, ticks, finite ticker, tickets,
   status, state verification, and Immediate/AfterTick/Drain termination.
3. Reporitor — GitHub prerequisite and read/report functions. The menu does not
   expose GitHub write operations.
4. Gits — local repository reads, accord verification, initialization, and
   explicitly confirmed local mutations.
5. ShellNotion — ShellNotion overview/test, Forward Pass, and the full
   Record-Through core/verifier/roller/UI group.
6. Python manager — routines, forecast, named routine execution, ticker bridge,
   foreground service mode, and tests.
7. Native connectors — source listing and optional C/C++/Rust builds.
8. Tests and integrity — grouped verification and source hashing.
9. Scripture index — enumerates the source/config/documentation files in the
   package so the operator can see the full script surface.

## Governance rules

- The menu is foreground-only and finite unless the operator deliberately starts
  the Python `serve` loop.
- GitHub remote write actions are not exposed.
- Local Git mutations require an explicit menu choice, a confirmation, and the
  Gits module `-Commit` gate.
- Ticker termination remains explicit: `Immediate`, `AfterTick`, or `Drain`.
- State and audit files remain in the existing manager/ticker/Forward Pass/
  Record-Through locations.

## ZA

Menu section **10** provides ZA completeness analysis and SHA-256 verification. It keeps completeness analysis separate from byte-identity verification and includes an independent Python verifier for systems where PowerShell is unavailable.
