@echo off
python "%~dp0WorkScriptature\kuvu_rot.py" menu
exit /b %errorlevel%
