@echo off
python "%~dp0WorkScriptature\python_git_connector.py" menu
exit /b %errorlevel%
