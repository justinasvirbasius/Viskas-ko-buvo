@echo off
call "%~dp0WorkScriptature\Start-Triggers34-Manager.cmd" %*
exit /b %errorlevel%
