#requires -Version 5.1
[CmdletBinding()]
param(
    [string]$Root = (Split-Path -Parent $PSScriptRoot),
    [ValidateSet('Analyze','Refresh','Verify','Report')][string]$Action = 'Report'
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSScriptRoot 'ZA.psd1') -Force
switch($Action){
    'Analyze' { Invoke-ZAAnalysis -Root $Root -VerifyChecksums }
    'Refresh' { New-ZAChecksumManifest -Root $Root }
    'Verify'  { Test-ZAChecksumManifest -Root $Root }
    'Report'  { New-ZAReport -Root $Root }
}
