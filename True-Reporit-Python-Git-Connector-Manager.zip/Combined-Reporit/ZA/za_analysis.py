#!/usr/bin/env python3
"""Independent ZA completeness + SHA-256 checker.

Works on Windows, Linux, and macOS without PowerShell. It deliberately excludes
its generated report and manifest from the checksum set so verification is stable.
"""
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path

EXT={'.ps1','.psm1','.psd1','.py','.c','.cpp','.h','.hpp','.rs','.toml','.json','.md','.cmd'}
EXCLUDE_DIR={'.work-scriptature','__pycache__','build','target','manager-state','ticker-state','record-through-state','forward-pass-state'}
EXCLUDE_NAME={'ZA-SHA256.txt','ZA-REPORT.json','ZA-REPORT.md'}
EXPECTED=[
'WorkScriptature/python_git_connector.py','WorkScriptature/PythonGit.policy.json','Start-Python-Git-Manager.cmd',
'WorkScriptature/kuvu_rot.py','WorkScriptature/KuvuRot.example.json','Start-Kuvu-Rot-Manager.cmd',
'WorkScriptature/hash_ula.py','WorkScriptature/HashULA.policy.json','Start-ULA-Bot-Manager.cmd',
'WorkScriptature/work_scriptature.py','WorkScriptature/Triggers34.json','WorkScriptature/Triggers34-Manager.ps1','WorkScriptature/Work-Scriptature.ps1','Start-34-Triggers-Manager.cmd',
'Scriptature-Menu.ps1','Start-Scriptature.cmd','Start-TrueReporit.ps1','TRUE-REPORIT.md','COMBINED-REPORIT.md',
'integration/ssm.reporitor.example.toml','reporitor-ticker/ReporitorTicker.psd1','reporitor-ticker/ReporitorTicker.psm1',
'reporitor-ticker/Start-ReporitorTicker.ps1','reporitor-ticker/Test-ReporitorTicker.ps1','Reporitor/Reporitor.psd1',
'Reporitor/Reporitor.psm1','Reporitor/Start-Reporitor.ps1','Reporitor/Test-Reporitor.ps1','Gits/Gits.psd1','Gits/Gits.psm1',
'Gits/Test-Gits.ps1','ShellNotion/ShellNotion.psd1','ShellNotion/ShellNotion.psm1','ShellNotion/Start-ShellNotion.ps1',
'ShellNotion/Test-ShellNotion.ps1','ShellNotion/ForwardPass/PowerShell-Forward-Pass.ps1',
'ShellNotion/RecordThrough/PowerShell-Record-Through.ps1','ShellNotion/RecordThrough/PowerShell-Record-Through-Verify.ps1',
'server-script-manager/pyproject.toml','server-script-manager/src/server_script_manager/cli.py',
'server-script-manager/src/server_script_manager/config.py','server-script-manager/src/server_script_manager/manager.py',
'server-script-manager/src/server_script_manager/routines.py','server-script-manager/src/server_script_manager/ticker.py',
'server-script-manager/tests/test_manager.py','server-script-manager/connectors/c/server_ops.c',
'server-script-manager/connectors/cpp/server_ops.cpp','server-script-manager/connectors/rust/Cargo.toml',
'server-script-manager/connectors/rust/src/lib.rs','scriptature/SCRIPTURE-CATALOG.txt','scriptature/SCRIPTURE-SHA256.txt',
'ZA/ZA.psd1','ZA/ZA.psm1','ZA/Invoke-ZAAnalysis.ps1','ZA/Test-ZA.ps1','ZA/za_analysis.py','ZA/README.md']

def files(root:Path):
    out=[]
    for p in root.rglob('*'):
        if not p.is_file() or p.suffix.lower() not in EXT or p.name in EXCLUDE_NAME: continue
        rel=p.relative_to(root)
        if any(part in EXCLUDE_DIR for part in rel.parts): continue
        out.append(p)
    return sorted(out)

def sha(p:Path):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def write_manifest(root:Path,path:Path):
    fs=files(root); path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(''.join(f'{sha(p)}  {p.relative_to(root).as_posix()}\n' for p in fs),encoding='utf-8')
    return len(fs)

def verify(root:Path,path:Path):
    if not path.exists(): return {'passed':False,'checked':0,'missing':0,'changed':0,'unlisted':0,'problems':[f'missing manifest: {path}']}
    exp={}
    for line in path.read_text(encoding='utf-8-sig').splitlines():
        if not line.strip() or line.lstrip().startswith('#'): continue
        try: h,r=line.split('  ',1)
        except ValueError: continue
        if len(h)==64: exp[r.replace('\\','/')]=h.lower()
    problems=[]; missing=changed=0
    for rel,h in sorted(exp.items()):
        p=root/rel
        if not p.is_file(): missing+=1; problems.append(f'missing: {rel}')
        elif sha(p)!=h: changed+=1; problems.append(f'changed: {rel}')
    cur={p.relative_to(root).as_posix() for p in files(root)}
    unlisted=sorted(cur-set(exp)); problems += [f'unlisted: {r}' for r in unlisted]
    return {'passed':not(missing or changed or unlisted),'checked':len(exp),'missing':missing,'changed':changed,'unlisted':len(unlisted),'problems':problems}

def analyze(root:Path,do_verify=True):
    fs=files(root); missing=[r for r in EXPECTED if not (root/r).is_file()]; empty=[p.relative_to(root).as_posix() for p in fs if p.stat().st_size==0]
    json_issues=[]
    for p in root.rglob('*.json'):
        if p.name in EXCLUDE_NAME or any(part in EXCLUDE_DIR for part in p.relative_to(root).parts): continue
        try: json.loads(p.read_text(encoding='utf-8-sig'))
        except Exception as e: json_issues.append(f'{p.relative_to(root).as_posix()}: {e}')
    menu=(root/'Scriptature-Menu.ps1').read_text(encoding='utf-8-sig') if (root/'Scriptature-Menu.ps1').exists() else ''
    refs=['Start-TrueReporit.ps1','ReporitorTicker.psd1','Reporitor.psd1','Gits.psd1','ShellNotion.psd1','PowerShell-Forward-Pass.ps1','PowerShell-Record-Through.ps1','ZA.psd1']
    ref_issues=[f'menu reference absent: {x}' for x in refs if x not in menu]
    counts={k:0 for k in ('PowerShell','Python','Native','Config','Docs','Launchers')}
    for p in fs:
        e=p.suffix.lower()
        if e in {'.ps1','.psm1','.psd1'}: counts['PowerShell']+=1
        elif e=='.py': counts['Python']+=1
        elif e in {'.c','.cpp','.h','.hpp','.rs'}: counts['Native']+=1
        elif e in {'.json','.toml'}: counts['Config']+=1
        elif e=='.md': counts['Docs']+=1
        elif e=='.cmd': counts['Launchers']+=1
    chk=verify(root,root/'ZA/ZA-SHA256.txt') if do_verify else None
    issue=len(missing)+len(empty)+len(json_issues)+len(ref_issues)+(0 if not chk or chk['passed'] else chk['missing']+chk['changed']+chk['unlisted'])
    return {'schema':'za-analysis/v1','passed':issue==0,'completeness':{'expected_count':len(EXPECTED),'expected_present':len(EXPECTED)-len(missing),'missing_count':len(missing),'missing':missing,'scripture_count':len(fs),'empty_file_count':len(empty),'empty_files':empty,'groups':counts},'structure':{'json_issue_count':len(json_issues),'json_issues':json_issues,'menu_reference_issue_count':len(ref_issues),'menu_reference_issues':ref_issues},'checksum':chk}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]); ap.add_argument('--refresh',action='store_true'); ap.add_argument('--json',action='store_true'); a=ap.parse_args(); root=a.root.resolve(); mf=root/'ZA/ZA-SHA256.txt'
    if a.refresh: write_manifest(root,mf)
    result=analyze(root,True)
    if a.json: print(json.dumps(result,indent=2))
    else:
        c=result['completeness']; ch=result['checksum']; print(f"ZA {'PASS' if result['passed'] else 'FAIL'} | expected {c['expected_present']}/{c['expected_count']} | scripture {c['scripture_count']} | checksum {ch['checked'] if ch else 0} checked")
        for x in c['missing']+(ch['problems'] if ch else []): print(' -',x)
    raise SystemExit(0 if result['passed'] else 1)
if __name__=='__main__': main()
