#requires -Version 5.1
[CmdletBinding()]
param([string]$Root=(Split-Path -Parent $PSScriptRoot))
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSScriptRoot 'ZA.psd1') -Force
$analysis=Invoke-ZAAnalysis -Root $Root
if($analysis.completeness.missing_count -ne 0){ throw "ZA missing paths: $($analysis.completeness.missing_count)" }
if($analysis.completeness.empty_file_count -ne 0){ throw "ZA empty files: $($analysis.completeness.empty_file_count)" }
if($analysis.structure.json_issue_count -ne 0){ throw "ZA JSON issues: $($analysis.structure.json_issue_count)" }
if($analysis.structure.menu_reference_issue_count -ne 0){ throw "ZA menu linkage issues: $($analysis.structure.menu_reference_issue_count)" }
$manifest=New-ZAChecksumManifest -Root $Root
$verify=Test-ZAChecksumManifest -Root $Root
if(-not $verify.Passed){ throw ('ZA checksum verification failed: '+($verify.Problems -join '; ')) }
[pscustomobject]@{ Passed=$true; Scripture=$analysis.completeness.scripture_count; Expected=$analysis.completeness.expected_count; Hashes=$manifest.Count }
