Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-ZARelativePath {
    param([Parameter(Mandatory=$true)][string]$Root,[Parameter(Mandatory=$true)][string]$Path)
    $r=[IO.Path]::GetFullPath($Root).TrimEnd('\\','/')
    $p=[IO.Path]::GetFullPath($Path)
    if (-not $p.StartsWith($r,[StringComparison]::OrdinalIgnoreCase)) { throw "Path is outside ZA root: $Path" }
    return ($p.Substring($r.Length).TrimStart('\\','/') -replace '\\','/')
}

function Get-ZAScriptureFiles {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Root)
    $extensions=@('.ps1','.psm1','.psd1','.py','.c','.cpp','.h','.hpp','.rs','.toml','.json','.md','.cmd')
    Get-ChildItem -LiteralPath $Root -Recurse -File | Where-Object {
        $extensions -contains $_.Extension.ToLowerInvariant() -and
        $_.FullName -notmatch '[\\/]__pycache__[\\/]' -and
        $_.FullName -notmatch '[\\/]\.work-scriptature[\\/]' -and
        $_.FullName -notmatch '[\\/]build[\\/]' -and
        $_.FullName -notmatch '[\\/]target[\\/]' -and
        $_.FullName -notmatch '[\\/]manager-state[\\/]' -and
        $_.FullName -notmatch '[\\/]ticker-state[\\/]' -and
        $_.FullName -notmatch '[\\/]record-through-state[\\/]' -and
        $_.FullName -notmatch '[\\/]forward-pass-state[\\/]' -and
        $_.Name -notin @('ZA-SHA256.txt','ZA-REPORT.json','ZA-REPORT.md')
    } | Sort-Object FullName
}

function Get-ZAExpectedPaths {
    @(
        'Scriptature-Menu.ps1',
        'Start-Scriptature.cmd',
        'Start-TrueReporit.ps1',
        'TRUE-REPORIT.md',
        'COMBINED-REPORIT.md',
        'integration/ssm.reporitor.example.toml',
        'reporitor-ticker/ReporitorTicker.psd1',
        'reporitor-ticker/ReporitorTicker.psm1',
        'reporitor-ticker/Start-ReporitorTicker.ps1',
        'reporitor-ticker/Test-ReporitorTicker.ps1',
        'Reporitor/Reporitor.psd1',
        'Reporitor/Reporitor.psm1',
        'Reporitor/Start-Reporitor.ps1',
        'Reporitor/Test-Reporitor.ps1',
        'Gits/Gits.psd1',
        'Gits/Gits.psm1',
        'Gits/Test-Gits.ps1',
        'ShellNotion/ShellNotion.psd1',
        'ShellNotion/ShellNotion.psm1',
        'ShellNotion/Start-ShellNotion.ps1',
        'ShellNotion/Test-ShellNotion.ps1',
        'ShellNotion/ForwardPass/PowerShell-Forward-Pass.ps1',
        'ShellNotion/RecordThrough/PowerShell-Record-Through.ps1',
        'ShellNotion/RecordThrough/PowerShell-Record-Through-Verify.ps1',
        'server-script-manager/pyproject.toml',
        'server-script-manager/src/server_script_manager/cli.py',
        'server-script-manager/src/server_script_manager/config.py',
        'server-script-manager/src/server_script_manager/manager.py',
        'server-script-manager/src/server_script_manager/routines.py',
        'server-script-manager/src/server_script_manager/ticker.py',
        'server-script-manager/tests/test_manager.py',
        'server-script-manager/connectors/c/server_ops.c',
        'server-script-manager/connectors/cpp/server_ops.cpp',
        'server-script-manager/connectors/rust/Cargo.toml',
        'server-script-manager/connectors/rust/src/lib.rs',
        'scriptature/SCRIPTURE-CATALOG.txt',
        'scriptature/SCRIPTURE-SHA256.txt',
        'WorkScriptature/Triggers24.json',
        'WorkScriptature/Triggers34.json',
        'WorkScriptature/Triggers34-Manager.ps1',
        'Start-34-Triggers-Manager.cmd',
        'WorkScriptature/hash_ula.py',
        'WorkScriptature/HashULA.policy.json',
        'Start-ULA-Bot-Manager.cmd',
        'WorkScriptature/kuvu_rot.py',
        'WorkScriptature/KuvuRot.example.json',
        'Start-Kuvu-Rot-Manager.cmd',
        'WorkScriptature/python_git_connector.py',
        'WorkScriptature/PythonGit.policy.json',
        'Start-Python-Git-Manager.cmd',
        'WorkScriptature/Work-Scriptature.ps1',
        'WorkScriptature/Triggers24-Manager.ps1',
        'WorkScriptature/Start-Triggers24-Manager.cmd',
        'Start-24-Triggers-Manager.cmd',
        'ZA/ZA.psd1',
        'ZA/ZA.psm1',
        'ZA/Invoke-ZAAnalysis.ps1',
        'ZA/Test-ZA.ps1',
        'ZA/za_analysis.py',
        'ZA/README.md'
    )
}

function New-ZAChecksumManifest {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Root,
        [string]$Path=(Join-Path $Root 'ZA/ZA-SHA256.txt')
    )
    $lines = foreach($file in Get-ZAScriptureFiles -Root $Root) {
        $relative=Get-ZARelativePath -Root $Root -Path $file.FullName
        $hash=(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        "$hash  $relative"
    }
    $dir=Split-Path -Parent $Path
    if($dir){ [void](New-Item -ItemType Directory -Path $dir -Force) }
    Set-Content -LiteralPath $Path -Value $lines -Encoding UTF8
    [pscustomobject]@{ Path=[IO.Path]::GetFullPath($Path); Count=@($lines).Count; Algorithm='SHA256' }
}

function Test-ZAChecksumManifest {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Root,
        [string]$Path=(Join-Path $Root 'ZA/ZA-SHA256.txt')
    )
    if(-not (Test-Path -LiteralPath $Path)){ return [pscustomobject]@{ Passed=$false; Checked=0; Missing=0; Changed=0; Unlisted=0; Problems=@("Missing manifest: $Path") } }
    $expected=@{}
    foreach($line in Get-Content -LiteralPath $Path){
        if([string]::IsNullOrWhiteSpace($line) -or $line.TrimStart().StartsWith('#')){continue}
        if($line -notmatch '^([0-9a-fA-F]{64})\s{2}(.+)$'){continue}
        $expected[$Matches[2].Replace('\\','/')]=$Matches[1].ToLowerInvariant()
    }
    $problems=New-Object Collections.Generic.List[string]
    $changed=0; $missing=0
    foreach($relative in ($expected.Keys | Sort-Object)){
        $full=Join-Path $Root ($relative -replace '/', [IO.Path]::DirectorySeparatorChar)
        if(-not (Test-Path -LiteralPath $full -PathType Leaf)){ $missing++; $problems.Add("missing: $relative"); continue }
        $actual=(Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash.ToLowerInvariant()
        if($actual -ne $expected[$relative]){ $changed++; $problems.Add("changed: $relative") }
    }
    $current=@(Get-ZAScriptureFiles -Root $Root | ForEach-Object { Get-ZARelativePath -Root $Root -Path $_.FullName })
    $unlisted=0
    foreach($relative in $current){ if(-not $expected.ContainsKey($relative)){ $unlisted++; $problems.Add("unlisted: $relative") } }
    [pscustomobject]@{ Passed=($missing -eq 0 -and $changed -eq 0 -and $unlisted -eq 0); Checked=$expected.Count; Missing=$missing; Changed=$changed; Unlisted=$unlisted; Problems=@($problems) }
}

function Test-ZAJsonFiles {
    param([string]$Root)
    $issues=New-Object Collections.Generic.List[string]
    foreach($file in Get-ChildItem -LiteralPath $Root -Recurse -File -Filter '*.json'){
        if($file.Name -in @('ZA-REPORT.json') -or $file.FullName -match '[\\/](build|target|__pycache__|\.work-scriptature)[\\/]'){continue}
        try { Get-Content -LiteralPath $file.FullName -Raw | ConvertFrom-Json | Out-Null }
        catch { $issues.Add((Get-ZARelativePath -Root $Root -Path $file.FullName)+': '+$_.Exception.Message) }
    }
    return @($issues)
}

function Test-ZAPowerShellReferences {
    param([string]$Root)
    $issues=New-Object Collections.Generic.List[string]
    $menu=Join-Path $Root 'Scriptature-Menu.ps1'
    if(-not (Test-Path -LiteralPath $menu)){ return @('Scriptature-Menu.ps1 missing') }
    $text=Get-Content -LiteralPath $menu -Raw
    $required=@('Start-TrueReporit.ps1','ReporitorTicker.psd1','Reporitor.psd1','Gits.psd1','ShellNotion.psd1','PowerShell-Forward-Pass.ps1','PowerShell-Record-Through.ps1','ZA.psd1','Triggers24-Manager.ps1','Work-Scriptature.ps1','Triggers24.json')
    foreach($name in $required){ if($text -notmatch [regex]::Escape($name)){ $issues.Add("menu reference absent: $name") } }
    return @($issues)
}

function Invoke-ZAAnalysis {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Root,
        [switch]$VerifyChecksums
    )
    $rootFull=[IO.Path]::GetFullPath($Root)
    $files=@(Get-ZAScriptureFiles -Root $rootFull)
    $relative=@($files | ForEach-Object { Get-ZARelativePath -Root $rootFull -Path $_.FullName })
    $expected=@(Get-ZAExpectedPaths)
    $missing=@($expected | Where-Object { -not (Test-Path -LiteralPath (Join-Path $rootFull ($_ -replace '/', [IO.Path]::DirectorySeparatorChar)) -PathType Leaf })
    $empty=@($files | Where-Object Length -eq 0 | ForEach-Object { Get-ZARelativePath -Root $rootFull -Path $_.FullName })
    $jsonIssues=@(Test-ZAJsonFiles -Root $rootFull)
    $referenceIssues=@(Test-ZAPowerShellReferences -Root $rootFull)
    $duplicateNames=@($files | Group-Object Name | Where-Object Count -gt 1 | ForEach-Object { [pscustomobject]@{ Name=$_.Name; Count=$_.Count; Paths=@($_.Group | ForEach-Object { Get-ZARelativePath -Root $rootFull -Path $_.FullName }) } })
    $groups=[ordered]@{
        PowerShell=@($files | Where-Object Extension -in @('.ps1','.psm1','.psd1')).Count
        Python=@($files | Where-Object Extension -eq '.py').Count
        Native=@($files | Where-Object Extension -in @('.c','.cpp','.h','.hpp','.rs')).Count
        Config=@($files | Where-Object Extension -in @('.json','.toml')).Count
        Docs=@($files | Where-Object Extension -eq '.md').Count
        Launchers=@($files | Where-Object Extension -eq '.cmd').Count
    }
    $checksum=$null
    if($VerifyChecksums){ $checksum=Test-ZAChecksumManifest -Root $rootFull }
    $issueCount=$missing.Count+$empty.Count+$jsonIssues.Count+$referenceIssues.Count
    if($checksum -and -not $checksum.Passed){ $issueCount += $checksum.Missing+$checksum.Changed+$checksum.Unlisted }
    [pscustomobject]@{
        schema='za-analysis/v1'
        generated_utc=[DateTime]::UtcNow.ToString('o')
        root=$rootFull
        passed=($issueCount -eq 0)
        completeness=[pscustomobject]@{
            expected_count=$expected.Count
            expected_present=$expected.Count-$missing.Count
            missing_count=$missing.Count
            missing=@($missing)
            scripture_count=$files.Count
            empty_file_count=$empty.Count
            empty_files=@($empty)
            groups=[pscustomobject]$groups
        }
        structure=[pscustomobject]@{
            json_issue_count=$jsonIssues.Count
            json_issues=@($jsonIssues)
            menu_reference_issue_count=$referenceIssues.Count
            menu_reference_issues=@($referenceIssues)
            duplicate_basename_groups=$duplicateNames.Count
            duplicate_basenames=@($duplicateNames)
        }
        checksum=$checksum
        notes=@(
            'ZA checks declared component completeness and static structure.',
            'Checksum verification proves byte identity only for files listed in ZA-SHA256.txt.',
            'Duplicate basenames are informational because modules may legitimately contain README.md or Test-* names.',
            'Runtime/network behavior remains a separate concern from static completeness.'
        )
    }
}

function New-ZAReport {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Root,
        [switch]$RefreshChecksums
    )
    if($RefreshChecksums){ New-ZAChecksumManifest -Root $Root | Out-Null }
    $analysis=Invoke-ZAAnalysis -Root $Root -VerifyChecksums
    $jsonPath=Join-Path $Root 'ZA/ZA-REPORT.json'
    $mdPath=Join-Path $Root 'ZA/ZA-REPORT.md'
    $analysis | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $jsonPath -Encoding UTF8
    $c=$analysis.completeness; $s=$analysis.structure
    $status=if($analysis.passed){'PASS'}else{'FAIL'}
    $lines=New-Object Collections.Generic.List[string]
    $lines.Add('# ZA Analysis and Completeness Report')
    $lines.Add('')
    $lines.Add("**Status:** $status")
    $lines.Add("")
    $lines.Add("Generated UTC: $($analysis.generated_utc)")
    $lines.Add('')
    $lines.Add('## Completeness')
    $lines.Add('')
    $lines.Add("- Expected core paths: $($c.expected_present) / $($c.expected_count)")
    $lines.Add("- Scripture files inventoried: $($c.scripture_count)")
    $lines.Add("- Empty files: $($c.empty_file_count)")
    $lines.Add("- Missing expected paths: $($c.missing_count)")
    foreach($m in $c.missing){ $lines.Add("  - `$m`") }
    $lines.Add('')
    $lines.Add('## Static structure')
    $lines.Add('')
    $lines.Add("- JSON parse issues: $($s.json_issue_count)")
    $lines.Add("- Menu linkage issues: $($s.menu_reference_issue_count)")
    $lines.Add("- Duplicate basename groups (informational): $($s.duplicate_basename_groups)")
    $lines.Add('')
    $lines.Add('## SHA-256')
    $lines.Add('')
    if($analysis.checksum){
        $lines.Add("- Manifest passed: $($analysis.checksum.Passed)")
        $lines.Add("- Checked: $($analysis.checksum.Checked)")
        $lines.Add("- Missing: $($analysis.checksum.Missing)")
        $lines.Add("- Changed: $($analysis.checksum.Changed)")
        $lines.Add("- Unlisted: $($analysis.checksum.Unlisted)")
        foreach($p in $analysis.checksum.Problems){ $lines.Add("  - `$p`") }
    }
    $lines.Add('')
    $lines.Add('## Scope')
    $lines.Add('')
    foreach($n in $analysis.notes){ $lines.Add("- $n") }
    Set-Content -LiteralPath $mdPath -Value $lines -Encoding UTF8
    [pscustomobject]@{ Passed=$analysis.passed; Json=$jsonPath; Markdown=$mdPath; Checksum=(Join-Path $Root 'ZA/ZA-SHA256.txt'); Analysis=$analysis }
}

Export-ModuleMember -Function Get-ZAScriptureFiles,New-ZAChecksumManifest,Test-ZAChecksumManifest,Invoke-ZAAnalysis,New-ZAReport
