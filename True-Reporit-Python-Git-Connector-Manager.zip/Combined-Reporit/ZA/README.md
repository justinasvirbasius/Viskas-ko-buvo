# ZA + Checksum Accord

ZA is the Scriptature completeness and integrity layer. The acronym is retained as the project term rather than expanded into a new meaning.

It provides two independent assurances:

1. **ZA analysis/completeness** — verifies the declared core files are present, inventories the scriptature, finds zero-byte files, parses JSON configuration, and checks that the top-level menu links the major accords.
2. **SHA-256 checksum verification** — records every governed source/config/documentation file in `ZA-SHA256.txt` and later detects missing, changed, or newly-unlisted scripture.

Generated outputs (`ZA-SHA256.txt`, `ZA-REPORT.json`, and `ZA-REPORT.md`) are deliberately excluded from the checksum input set so the manifest is reproducible and does not hash itself.

## PowerShell

```powershell
.\ZA\Invoke-ZAAnalysis.ps1 -Action Refresh
.\ZA\Invoke-ZAAnalysis.ps1 -Action Verify
.\ZA\Invoke-ZAAnalysis.ps1 -Action Report
.\ZA\Test-ZA.ps1
```

`Refresh` should be used only after an intentional source change. `Verify` should be used for ordinary integrity checks. `Report` writes JSON and Markdown reports without silently accepting changed source bytes.

## Cross-platform independent check

```sh
python ZA/za_analysis.py --refresh
python ZA/za_analysis.py
python ZA/za_analysis.py --json
```

The Python checker is intentionally separate from the PowerShell implementation so the package can be verified even on machines without PowerShell.

## Completeness scope

ZA checks packaging/static completeness. It does not claim that remote GitHub connectivity, credentials, OS services, compiler toolchains, or every runtime path are available. Those are covered by the existing module self-tests and runtime checks.
