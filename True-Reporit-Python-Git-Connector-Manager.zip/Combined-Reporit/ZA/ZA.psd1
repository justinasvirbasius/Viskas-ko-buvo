@{
    RootModule = 'ZA.psm1'
    ModuleVersion = '1.0.0'
    GUID = 'd56cb311-5234-4f52-9887-fad64ad57fa4'
    Author = 'True Reporit Accord'
    CompanyName = 'Independent'
    Copyright = '(c) 2026'
    Description = 'ZA analysis, completeness inventory, and SHA-256 verification for the True Reporit Scriptature accord.'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-ZAScriptureFiles','New-ZAChecksumManifest','Test-ZAChecksumManifest','Invoke-ZAAnalysis','New-ZAReport')
    CmdletsToExport = @()
    VariablesToExport = @()
    AliasesToExport = @()
}
