# Script Kuvu Rot — Python bot command scripture

**Script kuvu rot** is the name for a bounded route of script operations. The
route starts at one named node, performs a permitted operation, and follows its
`pass` or `fail` movement to another node or an ending. The *movement set* is
the set of those explicit links. The *enigma guide* is a numeric comparison
whose observed value chooses the next link. This terminology names the local
workflow; it does not imply that scripts or their hashes can change themselves.

The route extends the earlier Hash ULA helper and bot manager. Old
`hash-ula-script/1` files still work. Each queued route contains a validated,
resolved copy of its instructions; the bot reads the target files when it runs.
It stores a receipt with the visited nodes, decisions, hashes, numerical
measurements and ending.

## Start and command scripture

From the extracted `Combined-Reporit` folder:

```console
python WorkScriptature/kuvu_rot.py menu
```

On Windows, `Start-Kuvu-Rot-Manager.cmd` opens that menu. The Hash ULA menu also
has **Script Kuvu Rot command scripture**. Python 3.10+ is required; NumPy
accelerates numerical counting when installed, and the same result is available
with the Python backend.

| Command | Purpose |
| --- | --- |
| `guide ROUTE.json` | Show the named nodes and possible movements without running them. |
| `check ROUTE.json` | Validate topology, locators and instruction fields. |
| `run ROUTE.json` | Execute the route once and write a report. |
| `enqueue ROUTE.json` | Queue a pinned route for the existing bot. |
| `tick --ticks N` | Run at most N queued jobs, in the foreground. |
| `numeric ULA` | Hash a locator and measure its bytes. |
| `status`, `stop`, `resume` | Inspect or control the existing bot. |

For example:

```console
python WorkScriptature/kuvu_rot.py guide WorkScriptature/KuvuRot.example.json
python WorkScriptature/kuvu_rot.py check WorkScriptature/KuvuRot.example.json
python WorkScriptature/kuvu_rot.py run WorkScriptature/KuvuRot.example.json
python WorkScriptature/kuvu_rot.py enqueue WorkScriptature/KuvuRot.example.json
python WorkScriptature/kuvu_rot.py tick --ticks 1
```

`run` and `tick` return exit code 2 when a route or queued job fails. The
existing `hash_ula.py` `script-check`, `script-run`, and `enqueue` commands also
accept this route schema. Its queue status, retry, cancel and recovery commands
continue to work on route jobs.

## Route format

`WorkScriptature/KuvuRot.example.json` is runnable. A minimal version:

```json
{
  "schema": "script-kuvu-rot/1",
  "name": "A measured movement",
  "start": "measure",
  "max_movements": 4,
  "nodes": [
    {
      "id": "measure", "op": "rescript",
      "locator": "README.md",
      "move": {"pass": "guide", "fail": "HALT"}
    },
    {
      "id": "guide", "op": "guide", "source": "measure",
      "metric": "unique_bytes", "compare": "ge", "threshold": 1,
      "move": {"pass": "END", "fail": "HALT"}
    }
  ]
}
```

The script must contain `schema`, `name`, `start`, `max_movements`, and `nodes`.
Each node has a unique identifier and both `pass` and `fail` targets. Targets
must name another node, `END` (successful ending), or `HALT` (failed ending).
Loops are allowed only within `max_movements`, which cannot exceed the
configured script-step limit (64 by default). Exceeding the limit produces a
failed report. `guide` does not execute arbitrary conditions or Python code.

| Node operation | Inputs | Behavior |
| --- | --- | --- |
| `hash` | `locator`; optional `expected_sha256` | Stream SHA-256 and its ten-fold chain. |
| `verify` | `locator`; required `expected_sha256` | Follow `pass` only when H1 matches. |
| `rescript` | `locator`; optional `expected_sha256` | Hash and calculate numerical byte measurements in one read. |
| `guide` | prior `rescript` node, metric, comparison, integer threshold | Follow `pass` or `fail` from that measurement. |

`expected_sha256` is a 64-digit hexadecimal digest of the **file**, H1. The
script checks the hash at execution time. A mismatch emits the existing ZA-05
embargo trigger even if the route subsequently follows a `fail` link. A `guide`
comparison returning false is an ordinary branch; it does not raise an embargo.
A guide may refer only to a rescript node that has actually run on the current
route. References to future or skipped measurements produce a failed report.

Permitted guide metrics are `unique_bytes`, `byte_sum`,
`entropy_milli_bits`, and `num_end12`. Comparisons are `ge`, `le`, and `eq`.
Thresholds are integers between 0 and 10^12. The example checks whether the
file contains at least one distinct byte value.

## Hash rescript in NumPython

A rescript is a numerical record made from file bytes alongside the same
`sha256-tenfold/raw/v1` chain used by Hash ULA. Its default backend selects
NumPy when available. `numeric_backend` states what actually ran. To request
one backend explicitly:

```console
python WorkScriptature/kuvu_rot.py numeric README.md --backend numpy
python WorkScriptature/kuvu_rot.py numeric README.md --backend python
```

Both count byte values 0–255, then compute:

- `bytes`: bytes read; `unique_bytes`: nonempty histogram buckets.
- `byte_sum`: sum of every byte value.
- `entropy_milli_bits`: Shannon entropy in bits per byte, multiplied by
  1,000 and rounded to an integer. Empty files have zero entropy.
- `histogram_sha256`: SHA-256 of 256 unsigned 64-bit big-endian bucket counts.
- `num_end12`: integer H10 modulo 1,000,000,000,000, with a 12-digit display.

These are descriptive measures of bytes, not quality scores or a security
upgrade. Files are streamed in 1 MiB chunks. The size limit, path confinement,
and observed-change checks from Hash ULA apply. The cache never substitutes a
previous digest for a fresh read.

## Hash ULA locator numeric ending

Every completed or failed route records its movement trace and a *route ending*.
The ending includes `kind`, number of movements, SHA-256 and `decimal12`.
For reproducibility, its SHA-256 is calculated over a domain marker
`kuvu-end/v1`, the pinned script SHA-256, each visited node's hash or
histogram digest, each branch condition and destination, and the ending kind.
`decimal12` is that digest as an integer modulo 1,000,000,000,000, displayed
with leading zeros. It is an identifier for comparing route outcomes, not an
ordering of script quality or a proof that two scripts behave alike.

The route ending uses observed hashes, so a changed target can change it.
Cache hit/miss status and timestamps are excluded, so rerunning identical
inputs and movements gives the same ending. Reports retain the fuller evidence
for inspection. A stop produces an `INTERRUPTED` report; the bot requires an
explicit retry. File contents remain outside bot state.

## Safety and recovery

The route accepts only the four declared operations. It cannot execute shell
commands, arbitrary Python, network writes, mutation of source scripts,
deployment or an embargo lift. It inherits ULA's relative-path and alias
checks. Validation pins alias destinations in the queued script, but does not
freeze file contents; use `verify` when a particular content version matters.

Bot stop is cooperative between chunks and nodes. Existing `retry`, `cancel`
and `recover` rules are documented in `HASH-ULA.md`. Reports are kept under
`.work-scriptature/ula-reports`. This is local, unsigned evidence; a report
becomes decree evidence only after review and copying it to an ordinary
repository evidence file, followed by the original accord's approval stages.

Validate locally:

```console
python -m unittest discover -s WorkScriptature/tests -v
python WorkScriptature/work_scriptature.py self-test
```

The new route tests cover branch decisions, cycles, guide scope, NumPy/Python
parity, numerical endings, immutable queue snapshots, stop/retry and embargo
on expected-hash mismatch. The Python engine and menu were exercised here.
The Windows launcher was source-reviewed; no Windows runtime was available.
