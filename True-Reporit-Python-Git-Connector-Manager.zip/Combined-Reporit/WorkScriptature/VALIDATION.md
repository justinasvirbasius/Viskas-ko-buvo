# Delivery validation — 2026-09-27

- 24 Work Scriptature behavioral tests: passed on Python 3.12 / Linux.
- 8 existing server-script-manager regression tests: passed with `PYTHONPATH=src`.
- CLI self-test, error exit code and interactive menu exit: passed.
- Full proposal → contract → evidence → validation → decree → lift flow: passed.
- Unresolved causes, undecreed releases, stale/expired requests, source drift,
  manifest replacement after verification and evidence drift: denied as expected.
- Legacy embargo migration, mandatory trigger protection, lock contention,
  traversal/URI/symlink checks, quarantine hold and checksum checks: passed.
- Final source manifest and ZA completeness: checked during packaging.
- No live repository operations, external writes, or persistent embargo state
  changes were performed. Test mutations ran in temporary copies.
- PowerShell is unavailable in this environment. Windows launchers and the
  PowerShell wrapper were reviewed as source, not executed. The Python console
  is the verified entrypoint.

Reproduce Work Scriptature tests from the extracted package root:

```console
python -m unittest discover -s WorkScriptature/tests -v
python WorkScriptature/work_scriptature.py self-test
python ZA/za_analysis.py
```

## Hash ULA extension

- 18 additional tests passed for cache, hashing, scriptor and bot worker behavior.
- Combined Work Scriptature suite: 42 tests passed.
- New CLI and integrated menu launch/exit tests passed.
- Ten folds use SHA-256 over raw digest bytes after the initial file hash.
- New source/config files are included in the regenerated integrity manifest.

## Script Kuvu Rot extension

- 11 new route tests passed; Work Scriptature total: 53 tests.
- NumPy and Python byte histograms agreed on numeric measurements.
- Bounded movement branches, cycle limit, checksum-triggered embargo,
  queue pinning, stop/retry and numeric endings were exercised.
- Eight existing server-script-manager regressions passed in the prior
  package and its code is unchanged.
- Windows launcher remains source-reviewed rather than executed here.

## Python Git connector extension

- 14 connector tests passed using temporary local Git repositories.
- Covered read views, redacted remotes, command scriptures, bot controls,
  initialization, mutation preview/apply, embargo checks, hook/filter gating,
  root confinement and corrupted state.
- No network or remote Git operations were executed.

## Current complete validation

- Work Scriptature suite: **67 tests passed**.
- Existing server-script-manager regression suite: **8 tests passed**.
- Combined Python checks: **75 tests passed**.
- Python source compilation passed for all Work Scriptature modules.
