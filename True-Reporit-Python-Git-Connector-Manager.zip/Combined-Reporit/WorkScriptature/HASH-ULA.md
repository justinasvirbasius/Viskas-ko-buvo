# Cache ULA, Hash Ten Folds, Hash ULA Scriptor and Bot Manager

This module extends the 34-trigger accord. It implements a cached local locator,
a streaming file hasher, ten chained SHA-256 rounds, a declarative script runner,
and a persistent queue with a finite foreground bot worker. Python 3.10+;
standard library only. The existing 34-trigger list is retained.

## Start

From the extracted `Combined-Reporit` folder:

```console
python WorkScriptature/hash_ula.py menu
```

Windows convenience entrypoint: `Start-ULA-Bot-Manager.cmd` (requires `python`
on PATH). The existing 34-trigger menu now includes **ula tools**. PowerShell:

```powershell
.\WorkScriptature\Work-Scriptature.ps1 -Action UlaTools
```

The menu provides status, alias registration, cached location, hashing,
verification, script validation/run, queueing, finite ticks, stop/resume,
cancel/retry, recovery and cache clearing.

## Cache ULA locator

ULA continues to mean a governed file locator. Register an alias, then resolve
or hash it:

```console
python WorkScriptature/hash_ula.py alias core WorkScriptature/work_scriptature.py
python WorkScriptature/hash_ula.py locate ula:core
python WorkScriptature/hash_ula.py hash ula:core
```

Direct relative paths and `file:relative/path` work too. Remote URLs are not
fetched. Parent traversal, absolute paths, symbolic links and runtime-state
files are rejected. Aliases bind direct file paths; aliases cannot refer to
other aliases.

The cache stores locator metadata, **not reusable content digests**. Every lookup
rechecks confinement and existence. Every hash reads the current file bytes.
The cache compares file identity, size, modification/change times and expiry.
Defaults: 128 cached entries, 128 aliases, 300-second TTL, least-recently-used
cache eviction. Rebinding any alias clears cached locators. A cache hit does
not certify unchanged file contents.

```console
python WorkScriptature/hash_ula.py cache-clear
```

## Hasher and ten folds

For file bytes `B`, the algorithm identifier is `sha256-tenfold/raw/v1`:

- `H1 = SHA256(B)` — the ordinary file SHA-256.
- `Hi = SHA256(raw 32-byte H(i-1))`, for `i = 2..10`.
- `sha256` is H1; `folds` contains all ten lowercase hexadecimal results;
  `fold10` is H10.

The file is streamed once in 1 MiB chunks. Rounds 2–10 hash the previous binary
digest, not hexadecimal text. Empty files are supported. The default file-size
limit is 1 GiB. File identity and metadata are compared before and after reading;
an observed change rejects the result. This is a best-effort stable read, not a
filesystem snapshot or protection against a hostile local administrator.

Ten rounds provide a defined reproducible derivation. They are not ten
independent checks, encryption, a password KDF, or a claim of tenfold security.
The interpretation of “hash ten folds” is explicit so it can be revised later.

```console
python WorkScriptature/hash_ula.py hash README.md
python WorkScriptature/hash_ula.py verify README.md EXPECTED_64_HEX_SHA256
```

`verify` compares the expected ordinary file digest (H1). A mismatch emits a
report, exits with code 2 and signals existing trigger **ZA-05**, raising embargo
and invalidating any prepared lift through the existing accord engine. Merely
hashing a file without an expected digest records what was read; it cannot
establish that the content is the intended version.

## Hash ULA scriptor

Scripts are JSON data. Only `hash` and `verify` operations are accepted. There is
no shell command, Python execution, network request, deletion or deployment op.

```json
{
  "schema": "hash-ula-script/1",
  "name": "Source inspection",
  "steps": [
    {"op": "hash", "locator": "README.md"},
    {"op": "hash", "locator": "WorkScriptature/Triggers34.json"}
  ]
}
```

For verification use `{"op":"verify","locator":"path/to/file",
"expected_sha256":"your actual 64-hex digest"}`. Replace that explanatory
placeholder with a real digest before validation.

A runnable example is included:

```console
python WorkScriptature/hash_ula.py script-check WorkScriptature/HashULA.example.json
python WorkScriptature/hash_ula.py script-run WorkScriptature/HashULA.example.json
```

Scripts are limited to 1 MiB and, by default, 64 steps. Unknown fields and
operations are rejected. Validation checks the referenced paths and populates
the locator cache. Execution stops at the first mismatch or read error and
records the completed results plus the error. Reports include the script's
SHA-256 and its resolved steps. Direct script execution is synchronous; Ctrl+C
stops it. The bot stop flag controls queued worker jobs.

## Bot manager

Queue an immutable copy of the validated script, then run a bounded number of
jobs. Alias destinations are resolved at enqueue time. Editing the source JSON
or rebinding aliases later does not silently change an already queued job.
Target file bytes are read at execution time; use `verify` expectations when a
particular version is required.

```console
python WorkScriptature/hash_ula.py enqueue WorkScriptature/HashULA.example.json
python WorkScriptature/hash_ula.py status
python WorkScriptature/hash_ula.py run --ticks 10 --interval 0
```

One tick claims one queued job. The worker exits when it reaches the tick
limit, has no pending work, or receives a stop. Maximum: 1,000 ticks per run and
60 seconds between jobs. It runs in the foreground; it does not install a
service or scheduled task. One worker lock prevents simultaneous queue workers.

While the worker runs, use another terminal:

```console
python WorkScriptature/hash_ula.py stop
```

Stop is cooperative: it is checked between file chunks, between script steps
and during the wait between jobs. A blocked operating-system read must return
before the worker can observe the flag. An interrupted job remains
`interrupted`; pending jobs remain queued. The stop flag persists across runs.
After the worker exits:

```console
python WorkScriptature/hash_ula.py resume
python WorkScriptature/hash_ula.py retry JOB_ID
python WorkScriptature/hash_ula.py run --ticks 10
```

Use `cancel JOB_ID` for a pending job. Retry accepts failed, interrupted or
cancelled jobs and keeps their original script snapshot. To change that script,
enqueue a new one. Job states are `pending`, `running`, `completed`, `failed`,
`interrupted`, and `cancelled`. Attempts are counted. The queue is limited to
256 records; older terminal records may be removed to make room, but pending,
running and interrupted jobs are never evicted automatically.

After an unexpected process crash, verify that no bot worker remains. Remove
only its stale `.work-scriptature/ula-worker.lock`, then run `recover` to mark
stranded `running` jobs interrupted. If an accord state lock also remains,
follow the core manager's lock recovery instructions. Recovery never retries
jobs automatically. Local lock files are not distributed leases.

## Embargo and reports

Hashing and verification are inspection operations, so a valid active embargo
does not stop them. Invalid accord state fails closed. The bot cannot clear an
embargo, decree a proposal, run arbitrary programs, or delete source files.
Checksum mismatches create blocking causes; repair and use the existing verified
lift workflow to clear them. Retrying a failed job does not resolve its cause.

State: `.work-scriptature/ula-bot.json`.
Reports: `.work-scriptature/ula-reports/<unique-id>.json`.

State replacement is atomic and uses the same short-lived state lock as the
accord. Reports are local records, not signed attestations. The state retains
up to 256 report references; report files themselves are retained for manual
archiving. A report and its queue-state update are separate writes, so a crash
can leave a report without a finalized job. Use status/recovery rather than
assuming an interrupted job completed.

To use a report as proposal evidence, inspect it and copy it to an ordinary
repository evidence path first. The core accord deliberately rejects runtime
state as decree evidence. Recording a report does not automatically decree or
release technology.

## Configuration and validation

`HashULA.policy.json` sets cache bounds, TTL, file-size limit, script steps,
queue size and maximum ticks. All limits are validated; intentional source or
policy edits require reviewing and refreshing the existing source manifest
before a later embargo lift.

```console
python -m unittest discover -s WorkScriptature/tests -v
python WorkScriptature/work_scriptature.py self-test
```

42 Work Scriptature tests passed, including 18 new Hash ULA tests. Covered:
known SHA-256 and all ten rounds, empty files, cache expiry/eviction, file drift,
path rejection, expected-digest mismatch, embargo inspection, script validation,
immutable queued scripts, finite ticks, stop/resume, retry, cancellation,
worker exclusion and recovery. Windows launchers were not executed because
PowerShell is unavailable in the validation environment.

## Script Kuvu Rot route extension

The bot now accepts the bounded `script-kuvu-rot/1` movement script.
Run `python WorkScriptature/kuvu_rot.py menu` or open its entry from the Hash
ULA menu. See `KUVU-ROT.md` for numeric rescripts, branches, command scripture,
and the reproducible numerical ending.
