#!/usr/bin/env python3
"""Script Kuvu Rot: bounded, declarative ULA routes with numeric rescripts."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import sys
from hash_ula import HashULA, Stopped, ten_folds
from work_scriptature import Denied, need

SCHEMA = 'script-kuvu-rot/1'
IDENT = re.compile(r'[A-Za-z][A-Za-z0-9_.-]{0,63}\Z')
DIGEST = re.compile(r'[0-9a-fA-F]{64}\Z')
METRICS = {'unique_bytes', 'entropy_milli_bits', 'byte_sum', 'num_end12'}
ENDINGS = {'END', 'HALT'}


def byte_counts(data: bytes, backend='auto'):
    """Histogram with a NumPy path and an exactly equivalent Python fallback."""
    if backend not in {'auto', 'numpy', 'python'}:
        raise Denied('Numeric backend must be auto, numpy or python.')
    if backend != 'python':
        try:
            import numpy as np
        except ImportError:
            if backend == 'numpy':
                raise Denied('NumPy is required for the selected numeric backend.')
        else:
            return np.bincount(np.frombuffer(data, dtype=np.uint8), minlength=256).tolist(), 'numpy'
    counts = [0] * 256
    for value in data:
        counts[value] += 1
    return counts, 'python'


def numerical_end(counts, fold10):
    need(len(counts) == 256 and all(type(n) is int and n >= 0 for n in counts), 'Invalid byte histogram.')
    size = sum(counts)
    entropy = -sum((n / size) * math.log2(n / size) for n in counts if n) if size else 0.0
    histogram_digest = hashlib.sha256(b''.join(n.to_bytes(8, 'big') for n in counts)).hexdigest()
    number = int(fold10, 16) % 10**12
    return {'bytes': size, 'unique_bytes': sum(n != 0 for n in counts),
            'byte_sum': sum(i * n for i, n in enumerate(counts)),
            'entropy_milli_bits': round(entropy * 1000),
            'histogram_sha256': histogram_digest,
            'num_end12': number, 'num_end12_display': f'{number:012d}'}


class KuvuRot:
    def __init__(self, bot: HashULA):
        self.bot = bot

    def compile(self, relative, payload=None, source=None):
        """Pin the script bytes, route topology and resolved file paths at enqueue."""
        if payload is None:
            p = self.bot.accord.path(relative, True)
            need(p.stat().st_size <= 1024*1024, 'Kuvu script exceeds 1 MiB.')
            payload = p.read_bytes()
        if source is None:
            source = json.loads(payload)
        need(isinstance(source, dict) and source.get('schema') == SCHEMA, 'Invalid Kuvu Rot schema.')
        need(set(source) == {'schema', 'name', 'start', 'max_movements', 'nodes'},
             'Kuvu Rot requires schema, name, start, max_movements and nodes only.')
        need(isinstance(source['name'], str) and 1 <= len(source['name']) <= 100, 'Name must be 1..100 characters.')
        maximum = source['max_movements']
        need(type(maximum) is int and 1 <= maximum <= self.bot.policy['max_script_steps'],
             'Movement count must be within the configured script-step limit.')
        rows = source['nodes']
        need(isinstance(rows, list) and 1 <= len(rows) <= maximum, 'Invalid route node count.')
        ids = [row.get('id') if isinstance(row, dict) else None for row in rows]
        need(all(isinstance(x, str) and IDENT.fullmatch(x) and x not in ENDINGS for x in ids),
             'Each node needs a unique ID distinct from END and HALT.')
        need(len(set(ids)) == len(ids) and source['start'] in ids, 'Duplicate IDs or missing start node.')
        by_id = {row['id']: row for row in rows}
        compiled = []
        for row in rows:
            op = row.get('op')
            need(isinstance(op, str) and op in {'hash', 'verify', 'rescript', 'guide'}, 'Unsupported route operation.')
            allowed = {'id', 'op', 'move'} | ({'source', 'metric', 'compare', 'threshold'} if op == 'guide'
                                            else {'locator', 'expected_sha256'})
            need(set(row) <= allowed, 'Unknown route node fields.')
            moves = row.get('move')
            need(isinstance(moves, dict) and set(moves) == {'pass', 'fail'},
                 'Each node needs pass and fail movements.')
            need(all(isinstance(to, str) and to in by_id.keys() | ENDINGS for to in moves.values()),
                 'Movement target is not a node, END or HALT.')
            node = {'id': row['id'], 'op': op, 'move': dict(moves)}
            if op == 'guide':
                need(row.get('source') in by_id and by_id[row['source']].get('op') == 'rescript',
                     'Guide source must name a rescript node.')
                need(row.get('metric') in METRICS and row.get('compare') in {'ge', 'le', 'eq'},
                     'Unsupported numerical guide predicate.')
                threshold = row.get('threshold')
                need(type(threshold) is int and 0 <= threshold <= 10**12,
                     'Numerical guide threshold must be an integer 0..10^12.')
                node.update(source=row['source'], metric=row['metric'], compare=row['compare'], threshold=threshold)
            else:
                locator = row.get('locator')
                need(isinstance(locator, str), 'Locator required.')
                expected = row.get('expected_sha256')
                need(op != 'verify' or expected is not None, 'Verify needs expected_sha256.')
                if expected is not None:
                    need(isinstance(expected, str) and DIGEST.fullmatch(expected) is not None,
                         'Expected SHA256 must be 64 hexadecimal characters.')
                located = self.bot.resolve(locator)
                node.update(locator=located['path'], expected_sha256=expected.lower() if expected else None)
            compiled.append(node)
        return {'schema': SCHEMA, 'name': source['name'], 'source': relative,
                'script_sha256': hashlib.sha256(payload).hexdigest(),
                'start': source['start'], 'max_movements': maximum, 'nodes': compiled}

    def numeric_hash(self, locator, expected=None, backend='auto', cancelled=lambda:False):
        if expected is not None:
            need(isinstance(expected, str) and DIGEST.fullmatch(expected) is not None,
                 'Expected SHA256 must contain 64 hex digits.')
            expected = expected.lower()
        loc = self.bot.resolve(locator)
        p = self.bot.accord.path(loc['path'], True)
        h = hashlib.sha256(); histogram = [0] * 256; total = 0; chosen = None
        with p.open('rb') as f:
            before = os.fstat(f.fileno())
            need(before.st_size <= self.bot.policy['max_file_bytes'], 'File exceeds configured size limit.')
            while True:
                if cancelled():
                    raise Stopped('Stop requested during numeric hashing.')
                chunk = f.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                need(total <= self.bot.policy['max_file_bytes'], 'File grew beyond configured size limit.')
                h.update(chunk)
                counts, chosen = byte_counts(chunk, backend)
                for i, count in enumerate(counts):
                    histogram[i] += count
            after = os.fstat(f.fileno())
        current = self.bot.accord.path(loc['path'], True).stat()
        signature = lambda st: (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns)
        need(signature(before) == signature(after) == signature(current) and total == after.st_size,
             'File changed during numerical hash; result discarded.')
        if chosen is None:  # empty files still record the selected implementation
            _, chosen = byte_counts(b'', backend)
        folds = ten_folds(h.digest())
        numeric = numerical_end(histogram, folds[-1])
        return {**loc, 'op': 'rescript', 'passed': expected is None or folds[0] == expected,
                'sha256': folds[0], 'fold10': folds[-1], 'expected_sha256': expected,
                'algorithm': 'sha256-tenfold/raw/v1', 'numeric_backend': chosen,
                'numeric': numeric, 'bytes_read': total}

    def execute(self, spec, cancelled=lambda:False, backend='auto'):
        """Run a finite route and write a report with every movement and ending."""
        need(spec.get('schema') == SCHEMA, 'Compiled Kuvu Rot required.')
        nodes = {node['id']: node for node in spec['nodes']}
        position = spec['start']; results = []; movement = []; numeric_by_node = {}
        end = 'HALT'; error = None
        try:
            for index in range(spec['max_movements']):
                if cancelled():
                    raise Stopped('Stop requested before route movement.')
                node = nodes[position]; op = node['op']; condition = True
                if op == 'guide':
                    source = numeric_by_node.get(node['source'])
                    need(source is not None, 'Guide source has not run on this route.')
                    observed = source[node['metric']]
                    condition = {'ge': observed >= node['threshold'],
                                 'le': observed <= node['threshold'],
                                 'eq': observed == node['threshold']}[node['compare']]
                    result = {'op': op, 'node': position, 'source': node['source'],
                              'metric': node['metric'], 'observed': observed,
                              'threshold': node['threshold'], 'condition': condition,
                              'passed': True}
                elif op == 'rescript':
                    result = self.numeric_hash(node['locator'], node['expected_sha256'], backend, cancelled)
                    result['node'] = position
                    numeric_by_node[position] = result['numeric']
                    condition = result['passed']
                else:
                    result = self.bot.hash(node['locator'], node['expected_sha256'], cancelled)
                    result['node'] = position; result['op'] = op
                    condition = result['passed']
                destination = node['move']['pass' if condition else 'fail']
                movement.append({'index': index, 'from': position, 'condition': condition,
                                 'to': destination})
                results.append(result)
                position = destination
                if position in ENDINGS:
                    end = position
                    break
            else:
                error = 'Movement limit reached before END or HALT.'
        except Stopped:
            self.bot.report(results, spec, 'interrupted by stop request',
                            {'route': {'movements': movement, 'end': 'INTERRUPTED'}})
            raise
        except (OSError, ValueError, KeyError, TypeError) as exc:
            error = str(exc)
        if end == 'HALT' and error is None:
            error = 'Route reached HALT.'
        # Stable numeric ending: only pinned script SHA and observed movement facts.
        facts = [{'node': r['node'], 'op': r['op'], 'sha256': r.get('sha256'),
                  'histogram_sha256': r.get('numeric', {}).get('histogram_sha256'),
                  'condition': r.get('condition', r['passed']),
                  'to': move['to']}
                 for r, move in zip(results, movement)]
        canonical = json.dumps({'script_sha256': spec['script_sha256'],
                                'facts': facts, 'end': end}, sort_keys=True, separators=(',', ':')).encode()
        digest = hashlib.sha256(b'kuvu-end/v1\x00' + canonical).hexdigest()
        ending = {'kind': end, 'movements': len(movement), 'sha256': digest,
                  'decimal12': f'{int(digest, 16) % 10**12:012d}'}
        extra = {'route': {'movements': movement, 'end': end,
                           'numeric_ending': ending, 'numeric_backend_requested': backend}}
        return self.bot.report(results, spec, error, extra)

    def guide(self, spec):
        return {'name': spec['name'], 'start': spec['start'], 'max_movements': spec['max_movements'],
                'routes': [{'id': n['id'], 'op': n['op'], 'pass': n['move']['pass'],
                            'fail': n['move']['fail'],
                            'locator': n.get('locator'), 'source': n.get('source')}
                           for n in spec['nodes']]}


def menu(bot):
    engine = KuvuRot(bot)
    while True:
        print('\nPYTHON BOT COMMAND SCRIPTURE — SCRIPT KUVU ROT')
        print(' 1  Guide a movement set\n 2  Validate route script\n 3  Run route now')
        print(' 4  Queue route with bot\n 5  Run finite queued ticks\n 6  Numeric rescript a locator')
        print(' 7  Bot status\n 8  Stop worker\n 9  Resume worker\n B  Back')
        try:
            choice = input('Select: ').strip().upper()
            if choice in {'B', 'Q'}:
                return
            if choice in {'1', '2', '3', '4'}:
                path = input('Route JSON path: ').strip()
                if choice == '4':
                    result = bot.enqueue(path)
                else:
                    spec = bot.script(path)
                    need(spec['schema'] == SCHEMA, 'Expected a script-kuvu-rot/1 route.')
                    result = engine.guide(spec) if choice == '1' else spec if choice == '2' else bot.execute_script(spec)
            elif choice == '5':
                result = bot.run(int(input('Ticks: ')))
            elif choice == '6':
                result = bot.report([engine.numeric_hash(input('ULA locator: ').strip())])
            elif choice == '7':
                result = bot.status()
            elif choice in {'8', '9'}:
                result = bot.control('stop' if choice == '8' else 'resume')
            else:
                continue
            print(json.dumps(result, indent=2))
        except (EOFError, KeyboardInterrupt):
            print('\nStopped.')
            return
        except (OSError, ValueError, KeyError, TypeError) as exc:
            print('DENIED:', exc)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    sub = parser.add_subparsers(dest='action', required=True)
    for name in ('menu', 'status', 'stop', 'resume'):
        sub.add_parser(name)
    for name in ('guide', 'check', 'run', 'enqueue'):
        sub.add_parser(name).add_argument('script')
    command = sub.add_parser('numeric')
    command.add_argument('locator')
    command.add_argument('--expected-sha256')
    command.add_argument('--backend', choices=('auto', 'numpy', 'python'), default='auto')
    command = sub.add_parser('tick')
    command.add_argument('--ticks', type=int, default=10)
    args = parser.parse_args()
    try:
        bot = HashULA(args.root)
        engine = KuvuRot(bot)
        if args.action == 'menu':
            menu(bot)
            return 0
        if args.action in {'guide', 'check', 'run', 'enqueue'}:
            if args.action == 'enqueue':
                result = bot.enqueue(args.script)
            else:
                spec = bot.script(args.script)
                need(spec['schema'] == SCHEMA, 'Expected a script-kuvu-rot/1 route.')
                result = engine.guide(spec) if args.action == 'guide' else spec if args.action == 'check' else bot.execute_script(spec)
        elif args.action == 'numeric':
            expected = args.expected_sha256
            if expected is not None:
                need(DIGEST.fullmatch(expected) is not None, 'Expected SHA256 must be 64 hex digits.')
                expected = expected.lower()
            result = bot.report([engine.numeric_hash(args.locator, expected, args.backend)])
        elif args.action == 'tick':
            result = bot.run(args.ticks)
        elif args.action == 'status':
            result = bot.status()
        else:
            result = bot.control(args.action)
        print(json.dumps(result, indent=2))
        return 2 if result.get('passed') is False or any(j['state'] != 'completed' for j in result.get('jobs', [])) else 0
    except KeyboardInterrupt:
        return 130
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(json.dumps({'passed': False, 'error': str(exc)}), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
