#!/usr/bin/env python3
"""Cached ULA locators, ten-fold SHA-256, declarative hash scripts and finite bot jobs."""
from __future__ import annotations
import argparse
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import time
import uuid
from work_scriptature import Accord, Denied, need, read

SCHEMA = 'hash-ula-script/1'
TERMINAL = {'completed', 'failed', 'cancelled'}

class Stopped(Exception):
    pass


def ten_folds(first_digest):
    """H1=SHA256(file bytes); Hi=SHA256(raw 32 bytes of H(i-1)), i=2..10."""
    values = [first_digest.hex()]
    for _ in range(9):
        first_digest = hashlib.sha256(first_digest).digest()
        values.append(first_digest.hex())
    return values


class HashULA:
    def __init__(self, root):
        self.accord = Accord(root)
        self.root = self.accord.root
        self.rt = self.accord.rt
        self.statefile = self.rt / 'ula-bot.json'
        self.worker_lock = self.rt / 'ula-worker.lock'
        self.policy = read(self.root / 'WorkScriptature/HashULA.policy.json')
        need(isinstance(self.policy, dict) and self.policy.get('schema') == 'hash-ula-policy/1', 'Invalid HashULA policy schema.')
        for key, limit in [('cache_entries', 1024), ('cache_ttl_seconds', 86400),
                           ('max_file_bytes', 16*1024**3), ('max_script_steps', 256),
                           ('max_jobs', 1024), ('max_ticks', 1000)]:
            n = self.policy.get(key)
            need(type(n) is int and 1 <= n <= limit, 'Invalid HashULA policy: ' + key)

    def healthy(self):
        s = self.accord.status()
        need(s.get('passed') is True, 'Accord state is invalid; hashing manager fails closed.')
        return s

    def load(self):
        self.accord.path('.work-scriptature/ula-bot.json')
        if not self.statefile.exists():
            return {'schema': 'hash-ula-bot/1', 'aliases': {}, 'cache': {},
                    'jobs': [], 'stop_requested': False, 'reports': []}
        s = read(self.statefile)
        need(isinstance(s, dict) and s.get('schema') == 'hash-ula-bot/1', 'Invalid bot state schema.')
        for key, kind in [('aliases', dict), ('cache', dict), ('jobs', list), ('reports', list)]:
            need(isinstance(s.get(key), kind), 'Invalid bot state: ' + key)
        need(type(s.get('stop_requested')) is bool, 'Invalid bot stop state.')
        need(all(isinstance(j, dict) and j.get('state') in TERMINAL | {'pending', 'running', 'interrupted'} for j in s['jobs']), 'Invalid job state.')
        need(all(isinstance(k, str) and isinstance(v, str) for k,v in s['aliases'].items()), 'Invalid alias state.')
        need(all(isinstance(v, dict) and isinstance(v.get('expires'), (int,float))
                 and isinstance(v.get('used'), (int,float)) for v in s['cache'].values()), 'Invalid cache state.')
        return s

    def atomic(self, p, value):
        self.accord.path(p.relative_to(self.root).as_posix())
        p.parent.mkdir(parents=True, exist_ok=True)
        temp = p.with_name('.' + uuid.uuid4().hex + '.tmp')
        try:
            with temp.open('x', encoding='utf-8') as f:
                json.dump(value, f, indent=2); f.write('\n'); f.flush(); os.fsync(f.fileno())
            os.replace(temp, p)
        finally:
            temp.unlink(missing_ok=True)

    def save(self, s):
        self.atomic(self.statefile, s)

    def resolve(self, locator, use_cache=True):
        need(isinstance(locator, str) and bool(locator), 'ULA locator required.')
        self.healthy()
        with self.accord.lock():
            s = self.load(); target = locator
            if locator.startswith('ula:'):
                name = locator[4:]
                need(name in s['aliases'], 'Unknown ULA alias: ' + name)
                target = s['aliases'][name]
            result = self.accord.address(target)
            need(result.get('valid') and result.get('kind') == 'file', 'Hash locators must resolve to a repository file; remote content is not fetched.')
            rel = Path(result['value']).relative_to(self.root).as_posix()
            need(not rel.startswith('.work-scriptature/'), 'Runtime state cannot be a hashing target.')
            p = self.accord.path(rel, True)
            stat = p.stat()
            signature = [stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns]
            now = time.time(); previous = s['cache'].get(locator)
            hit = bool(use_cache and previous and previous.get('expires', 0) > now
                       and previous.get('path') == rel and previous.get('signature') == signature)
            s['cache'] = {k:v for k,v in s['cache'].items() if v.get('expires',0) > now}
            s['cache'][locator] = {'path': rel, 'signature': signature, 'used': now,
                                   'expires': now + self.policy['cache_ttl_seconds']}
            while len(s['cache']) > self.policy['cache_entries']:
                del s['cache'][min(s['cache'], key=lambda key:s['cache'][key]['used'])]
            self.save(s)
            return {'locator': locator, 'path': rel, 'cache_hit': hit, 'size': stat.st_size}

    def alias(self, name, target):
        need(re.fullmatch(r'[A-Za-z][A-Za-z0-9_.-]{0,63}', name or '') is not None, 'Invalid alias name.')
        need(not target.startswith('ula:'), 'Aliases must bind direct local locators, not other aliases.')
        resolved = self.resolve(target)
        with self.accord.lock():
            s = self.load()
            need(name in s['aliases'] or len(s['aliases']) < self.policy['cache_entries'], 'Alias capacity reached.')
            s['aliases'][name] = resolved['path']; s['cache'] = {}; self.save(s)
        return {'alias': 'ula:' + name, 'path': resolved['path']}

    def hash(self, locator, expected=None, cancelled=lambda:False):
        loc = self.resolve(locator)
        p = self.accord.path(loc['path'], True)
        h = hashlib.sha256(); total = 0
        with p.open('rb') as f:
            before = os.fstat(f.fileno())
            need(before.st_size <= self.policy['max_file_bytes'], 'File exceeds configured hashing size limit.')
            while True:
                if cancelled(): raise Stopped('Stop requested during hashing.')
                chunk = f.read(1024*1024)
                if not chunk: break
                total += len(chunk)
                need(total <= self.policy['max_file_bytes'], 'File grew beyond size limit.')
                h.update(chunk)
            after = os.fstat(f.fileno())
        current = self.accord.path(loc['path'], True).stat()
        sig = lambda st:(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)
        need(sig(before) == sig(after) == sig(current) and total == after.st_size, 'File changed while hashing; no digest accepted.')
        folds = ten_folds(h.digest())
        if expected is not None:
            need(isinstance(expected,str) and re.fullmatch('[0-9a-fA-F]{64}', expected) is not None, 'Expected SHA256 must contain 64 hex digits.')
        return {**loc, 'algorithm': 'sha256-tenfold/raw/v1', 'bytes_read': total,
                'sha256': folds[0], 'folds': folds, 'fold10': folds[-1],
                'expected_sha256': expected, 'passed': expected is None or folds[0] == expected.lower()}

    def script(self, relative):
        p = self.accord.path(relative, True)
        need(p.stat().st_size <= 1024*1024, 'Script limit is 1 MiB.')
        payload = p.read_bytes(); spec = json.loads(payload)
        if isinstance(spec, dict) and spec.get('schema') == 'script-kuvu-rot/1':
            from kuvu_rot import KuvuRot
            return KuvuRot(self).compile(relative, payload, spec)
        need(isinstance(spec,dict) and spec.get('schema') == SCHEMA, 'Invalid hash ULA script schema.')
        need(set(spec) <= {'schema','name','steps'}, 'Unknown script fields.')
        steps = spec.get('steps')
        need(isinstance(steps,list) and 1 <= len(steps) <= self.policy['max_script_steps'], 'Invalid script step count.')
        canonical = []
        for step in steps:
            need(isinstance(step,dict) and set(step) <= {'op','locator','expected_sha256'}, 'Unknown step fields.')
            need(step.get('op') in {'hash','verify'}, 'Only hash and verify operations are permitted.')
            expected = step.get('expected_sha256')
            need(step['op'] != 'verify' or expected is not None, 'Verify requires expected_sha256.')
            if expected is not None:
                need(isinstance(expected,str) and re.fullmatch('[0-9a-fA-F]{64}', expected) is not None, 'Malformed expected_sha256.')
            loc = self.resolve(step.get('locator'))
            canonical.append({'op':step['op'], 'locator':loc['path'], 'expected_sha256':expected})
        return {'schema':SCHEMA,'name':str(spec.get('name','Hash ULA script')),
                'source':relative,'script_sha256':hashlib.sha256(payload).hexdigest(),'steps':canonical}

    def report(self, results, script=None, error=None, extra=None):
        value = {'schema':'hash-ula-report/1','id':uuid.uuid4().hex,'time':time.time(),
                 'passed':error is None and all(r['passed'] for r in results),
                 'script':script,'results':results,'error':error}
        if extra is not None: value.update(extra)
        path = self.rt / 'ula-reports' / (value['id']+'.json')
        with self.accord.lock():
            s = self.load(); self.atomic(path,value)
            s['reports'].append(path.relative_to(self.root).as_posix())
            s['reports'] = s['reports'][-256:]; self.save(s)
        if any(not r['passed'] and r.get('expected_sha256') is not None for r in results):
            self.accord.execute('signal',trigger='ZA-05',reason='Hash ULA expected-checksum mismatch; report '+value['id'])
        return {**value,'report_path':path.relative_to(self.root).as_posix()}

    def execute_script(self, spec, cancelled=lambda:False):
        if spec.get('schema') == 'script-kuvu-rot/1':
            from kuvu_rot import KuvuRot
            return KuvuRot(self).execute(spec, cancelled)
        results=[]
        try:
            for step in spec['steps']:
                if cancelled(): raise Stopped('Stop requested before next script step.')
                results.append(self.hash(step['locator'],step.get('expected_sha256'),cancelled))
                if not results[-1]['passed']: break
            return self.report(results,spec)
        except Stopped:
            self.report(results,spec,'interrupted by stop request')
            raise
        except (OSError,ValueError) as e:
            return self.report(results,spec,str(e))

    def enqueue(self, relative):
        self.healthy(); spec=self.script(relative)
        with self.accord.lock():
            s=self.load()
            while len(s['jobs']) >= self.policy['max_jobs']:
                terminal=next((j for j in s['jobs'] if j['state'] in TERMINAL),None)
                need(terminal is not None,'Queue is full.'); s['jobs'].remove(terminal)
            job={'id':uuid.uuid4().hex,'state':'pending','created':time.time(),'attempts':0,'script':spec,'report':None}
            s['jobs'].append(job); self.save(s); return job

    def control(self, command, ident=None):
        self.healthy()
        with self.accord.lock():
            s=self.load()
            if command=='stop': s['stop_requested']=True
            elif command=='resume':
                need(not self.worker_lock.exists(),'Wait for worker exit before resuming.')
                s['stop_requested']=False
            elif command=='cache-clear': s['cache']={}
            elif command=='recover':
                need(not self.worker_lock.exists(),'Worker lock present: stop the worker or confirm it has exited before removing its stale lock.')
                for j in s['jobs']:
                    if j['state']=='running': j['state']='interrupted'; j['error']='Recovered after worker exit; explicit retry required.'
            elif command in {'cancel','retry'}:
                job=next((j for j in s['jobs'] if j['id']==ident),None); need(job is not None,'Unknown job ID.')
                if command=='cancel':
                    need(job['state']=='pending','Only pending jobs can be cancelled; stop interrupts the running job.')
                    job['state']='cancelled'
                else:
                    need(job['state'] in {'failed','interrupted','cancelled'},'Only failed/interrupted/cancelled jobs can be retried.')
                    job['state']='pending'; job['report']=None; job.pop('error',None)
            else: raise Denied('Unknown control command.')
            self.save(s); return {'action':command,'stop_requested':s['stop_requested'],'job_id':ident}

    @contextmanager
    def worker(self):
        # Same state lock as stop/resume prevents a lost stop during worker startup.
        with self.accord.lock():
            self.accord.path('.work-scriptature/ula-worker.lock')
            try: fd=os.open(self.worker_lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
            except FileExistsError as e: raise Denied('A bot worker is already active (or its lock needs crash recovery).') from e
            with os.fdopen(fd,'w') as f: f.write(str(os.getpid()))
        try: yield
        finally: self.worker_lock.unlink(missing_ok=True)

    def stopped(self):
        return self.load()['stop_requested']

    def run(self,ticks=10,interval=0):
        need(type(ticks) is int and 1<=ticks<=self.policy['max_ticks'],'Invalid finite tick count.')
        need(isinstance(interval,(int,float)) and 0<=interval<=60,'Interval must be 0..60 seconds.')
        self.healthy(); summary=[]
        with self.worker():
            for _ in range(ticks):
                self.healthy()
                with self.accord.lock():
                    s=self.load()
                    if s['stop_requested']: break
                    job=next((j for j in s['jobs'] if j['state']=='pending'),None)
                    if job is None: break
                    job['state']='running'; job['attempts']+=1; self.save(s)
                    ident=job['id']; spec=job['script']
                try:
                    result=self.execute_script(spec,self.stopped)
                    state='completed' if result['passed'] else 'failed'; report=result['report_path']; error=result.get('error')
                except (Stopped,KeyboardInterrupt): state='interrupted'; report=None; error='Worker stopped; explicit retry required.'
                except (OSError,ValueError,KeyError,TypeError) as e: state='failed'; report=None; error=str(e)
                with self.accord.lock():
                    s=self.load(); job=next(j for j in s['jobs'] if j['id']==ident)
                    job.update(state=state,report=report,error=error,finished=time.time()); self.save(s)
                summary.append({'id':ident,'state':state,'report':report,'error':error})
                if state=='interrupted': break
                until=time.monotonic()+interval
                while time.monotonic()<until and not self.stopped(): time.sleep(min(.1,max(0,until-time.monotonic())))
        return {'ticks_completed':len(summary),'jobs':summary,'stop_requested':self.stopped()}

    def status(self):
        s=self.load()
        return {'embargo':self.healthy()['embargo'],'worker_lock_present':self.worker_lock.exists(),
                'stop_requested':s['stop_requested'],'aliases':s['aliases'],'cache_entries':len(s['cache']),
                'jobs':[{k:v for k,v in j.items() if k!='script'} for j in s['jobs']], 'recent_reports':s['reports'][-10:]}


def menu(bot):
    labels=['Status','Register ULA alias','Resolve cached locator','Hash ten folds','Verify expected SHA256',
            'Validate ULA script','Run ULA script now','Enqueue bot script','Run finite bot ticks',
            'Request bot stop','Resume bot','Cancel pending job','Retry job','Recover interrupted jobs','Clear locator cache','Script Kuvu Rot command scripture']
    while True:
        print('\nCACHE ULA / HASH TEN FOLDS / SCRIPTOR / BOT MANAGER')
        for i,label in enumerate(labels,1): print(f'{i:2}  {label}')
        print(' B  Back')
        try:
            x=input('Select: ').strip().upper()
            if x in {'B','Q'}: return
            if x=='1': value=bot.status()
            elif x=='2': value=bot.alias(input('Alias name: '),input('Local file path: '))
            elif x=='3': value=bot.resolve(input('ULA locator: '))
            elif x in {'4','5'}:
                loc=input('ULA locator: '); expected=input('Expected SHA256: ') if x=='5' else None
                value=bot.report([bot.hash(loc,expected)])
            elif x in {'6','7','8'}:
                path=input('Script path: ')
                value=bot.enqueue(path) if x=='8' else bot.script(path)
                if x=='7': value=bot.execute_script(value)
            elif x=='9': value=bot.run(int(input('Ticks (1..1000): ')),float(input('Interval seconds (0..60): ') or '0'))
            elif x in {'10','11','14','15'}: value=bot.control({'10':'stop','11':'resume','14':'recover','15':'cache-clear'}[x])
            elif x in {'12','13'}: value=bot.control('cancel' if x=='12' else 'retry',input('Job ID: '))
            elif x=='16':
                from kuvu_rot import menu as rot_menu
                rot_menu(bot); continue
            else: continue
            print(json.dumps(value,indent=2))
        except (EOFError,KeyboardInterrupt): print('\nStopped.'); return
        except (OSError,ValueError,KeyError,TypeError) as e: print('DENIED:',e)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]); sub=p.add_subparsers(dest='action',required=True)
    for name in ['menu','status','stop','resume','recover','cache-clear']: sub.add_parser(name)
    q=sub.add_parser('alias'); q.add_argument('name'); q.add_argument('target')
    for name in ['locate','hash','verify']:
        q=sub.add_parser(name); q.add_argument('locator')
        if name=='verify': q.add_argument('expected')
    for name in ['script-check','script-run','enqueue']: sub.add_parser(name).add_argument('script')
    for name in ['cancel','retry']: sub.add_parser(name).add_argument('id')
    q=sub.add_parser('run'); q.add_argument('--ticks',type=int,default=10); q.add_argument('--interval',type=float,default=0)
    a=p.parse_args()
    try:
        b=HashULA(a.root)
        if a.action=='menu': menu(b); return 0
        if a.action=='status': result=b.status()
        elif a.action=='alias': result=b.alias(a.name,a.target)
        elif a.action=='locate': result=b.resolve(a.locator)
        elif a.action in {'hash','verify'}: result=b.report([b.hash(a.locator,getattr(a,'expected',None))])
        elif a.action=='script-check': result=b.script(a.script)
        elif a.action=='script-run': result=b.execute_script(b.script(a.script))
        elif a.action=='enqueue': result=b.enqueue(a.script)
        elif a.action=='run': result=b.run(a.ticks,a.interval)
        else: result=b.control(a.action,getattr(a,'id',None))
        print(json.dumps(result,indent=2))
        failed=result.get('passed') is False or any(j['state']!='completed' for j in result.get('jobs',[]) if a.action=='run')
        return 2 if failed else 0
    except KeyboardInterrupt: return 130
    except (OSError,ValueError,KeyError,TypeError) as e:
        print(json.dumps({'passed':False,'error':str(e)}),file=sys.stderr); return 2

if __name__=='__main__': sys.exit(main())
