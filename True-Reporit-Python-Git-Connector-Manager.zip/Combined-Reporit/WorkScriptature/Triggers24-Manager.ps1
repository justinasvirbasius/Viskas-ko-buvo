# Compatibility entrypoint: the existing 24-trigger menu now opens the 34-trigger manager.
[CmdletBinding()]
param([string]$Repository='', [switch]$NoClear)
& (Join-Path $PSScriptRoot 'Triggers34-Manager.ps1') -Repository $Repository -NoClear:$NoClear
