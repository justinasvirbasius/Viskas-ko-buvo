@echo off
setlocal
where pwsh >nul 2>nul
if errorlevel 1 goto windows_powershell
pwsh -NoLogo -NoProfile -File "%~dp0Triggers34-Manager.ps1" %*
exit /b %errorlevel%
:windows_powershell
powershell -NoLogo -NoProfile -File "%~dp0Triggers34-Manager.ps1" %*
exit /b %errorlevel%
