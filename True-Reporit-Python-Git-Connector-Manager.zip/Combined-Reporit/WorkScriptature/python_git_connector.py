#!/usr/bin/env python3
"""Python Git repository manager, finite report bot, and command scripture."""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import time
from urllib.parse import urlsplit, urlunsplit
import uuid

from work_scriptature import Accord, Denied, need, read

SCRIPT_SCHEMA = 'python-git-command/1'
STATE_SCHEMA = 'python-git-manager/1'
REPORT_SCHEMA = 'python-git-report/1'
NAME = re.compile(r'[A-Za-z][A-Za-z0-9_.-]{0,63}\Z')
REF = re.compile(r'[A-Za-z0-9](?:[A-Za-z0-9._/-]{0,126}[A-Za-z0-9])?\Z')
READ_OPS = {'status', 'branches', 'log', 'diff', 'staged-diff', 'files', 'remotes', 'snapshot'}
TERMINAL = {'completed', 'failed', 'cancelled'}


def canonical_hash(value):
    payload = json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()
    return hashlib.sha256(payload).hexdigest()


def redact_url(value):
    """Return transport/host/path without embedded credentials or query fragments."""
    value = value.strip()
    # SCP-like SSH syntax: [user@]host:path. User is discarded.
    if '://' not in value:
        match = re.fullmatch(r'(?:[^@/:]+@)?([^/:\s]+):(.+)', value)
        if match:
            host, path = match.groups()
            return {'scheme': 'ssh', 'host': host.lower(), 'path': path, 'redacted': True}
        # Local remote paths are represented without resolving or exposing an absolute path.
        return {'scheme': 'local', 'host': None, 'path': Path(value).name or '.', 'redacted': True}
    parsed = urlsplit(value)
    try:
        port = parsed.port
    except ValueError:
        port = None
    host = parsed.hostname.lower() if parsed.hostname else None
    display_host = host + ((':' + str(port)) if host and port else '') if host else None
    clean = urlunsplit((parsed.scheme.lower(), display_host or '', parsed.path, '', ''))
    return {'scheme': parsed.scheme.lower(), 'host': host, 'path': parsed.path,
            'display': clean, 'redacted': bool(parsed.username or parsed.password or parsed.query or parsed.fragment)}


class PythonGit:
    def __init__(self, root):
        self.accord = Accord(root)
        self.root = self.accord.root
        self.rt = self.accord.rt / 'python-git'
        self.statefile = self.rt / 'state.json'
        self.worker_lock = self.rt / 'worker.lock'
        self.policy = read(self.root / 'WorkScriptature/PythonGit.policy.json')
        need(isinstance(self.policy, dict) and self.policy.get('schema') == 'python-git-policy/1', 'Invalid Python Git policy schema.')
        expected = {'root_confined': bool, 'command_timeout_seconds': int,
                    'max_output_bytes': int, 'max_log_entries': int,
                    'max_script_steps': int, 'max_jobs': int, 'max_rounds': int}
        for key, kind in expected.items():
            need(type(self.policy.get(key)) is kind, 'Invalid Python Git policy field: ' + key)
        need(self.policy['root_confined'] is True, 'Repository confinement must remain enabled.')
        need(1 <= self.policy['command_timeout_seconds'] <= 300, 'Command timeout must be 1..300 seconds.')
        need(1024 <= self.policy['max_output_bytes'] <= 16 * 1024 * 1024, 'Output limit out of range.')
        for key, maximum in [('max_log_entries', 1000), ('max_script_steps', 256),
                             ('max_jobs', 1024), ('max_rounds', 1000)]:
            need(1 <= self.policy[key] <= maximum, 'Policy limit out of range: ' + key)
        self.git = shutil.which('git')
        need(self.git is not None, 'Git executable was not found on PATH.')
        legacy = read(self.root / 'Gits/Gits.policy.json')
        need(legacy.get('schema') == 'gits-policy/v1', 'Existing Gits policy is invalid.')
        self.legacy = legacy['repository']
        need(self.legacy.get('allowRemoteOperations') is False, 'This connector requires remote operations disabled.')

    def healthy(self):
        status = self.accord.status()
        need(status.get('passed') is True, 'Accord state is invalid; Git connector fails closed.')
        return status

    def local_path(self, value, create=False, allow_missing=False):
        need(isinstance(value, str) and bool(value.strip()), 'Repository path required.')
        value = value.strip()
        need('\\' not in value and ':' not in value and '\0' not in value, 'Use a repository-relative path with forward slashes.')
        rel = PurePosixPath(value)
        need(not rel.is_absolute() and '..' not in rel.parts, 'Repository path escapes the package root.')
        p = self.root
        for part in rel.parts:
            p = p / part
            need(not p.is_symlink(), 'Repository path cannot traverse a symbolic link.')
            need(not (hasattr(p, 'is_junction') and p.is_junction()), 'Repository path cannot traverse a junction.')
        if create:
            p.mkdir(parents=True, exist_ok=True)
        need(p.is_dir() or (allow_missing and not p.exists()), 'Repository path must name a directory.')
        resolved = p.resolve()
        need(resolved.is_relative_to(self.root), 'Repository path escapes package root.')
        return resolved

    def run_git(self, repository, arguments, allow_failure=False):
        need(isinstance(arguments, list) and all(isinstance(x, str) and '\0' not in x for x in arguments), 'Invalid Git argument vector.')
        command = [self.git, '--no-pager', '--literal-pathspecs', '-c', 'color.ui=false',
                   '-c', 'core.quotepath=false', '-c', 'core.fsmonitor=false',
                   '-C', str(repository), *arguments]
        env = os.environ.copy()
        env.update({'GIT_TERMINAL_PROMPT': '0', 'GIT_ASKPASS': '', 'SSH_ASKPASS': '',
                    'GIT_OPTIONAL_LOCKS': '0', 'GIT_CONFIG_NOSYSTEM': '1',
                    'GIT_CONFIG_GLOBAL': os.devnull, 'LC_ALL': 'C.UTF-8'})
        try:
            result = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE, timeout=self.policy['command_timeout_seconds'],
                                    env=env, check=False)
        except subprocess.TimeoutExpired as exc:
            raise Denied('Git command timed out.') from exc
        limit = self.policy['max_output_bytes']
        need(len(result.stdout) <= limit and len(result.stderr) <= limit, 'Git output exceeded the configured limit.')
        output = result.stdout.decode('utf-8', 'replace')
        error = result.stderr.decode('utf-8', 'replace').strip()
        if result.returncode and not allow_failure:
            raise Denied('Git command failed: ' + (error or output.strip() or str(result.returncode)))
        return {'code': result.returncode, 'stdout': output, 'stderr': error}

    def repository(self, value):
        p = self.local_path(value)
        result = self.run_git(p, ['rev-parse', '--show-toplevel'], True)
        need(result['code'] == 0, 'Path is not inside a Git repository.')
        top = Path(result['stdout'].strip()).resolve()
        need(top.is_relative_to(self.root), 'Git top level escapes package root.')
        # Resolve again through the governed relative path to reject link/junction routes.
        rel = top.relative_to(self.root).as_posix() or '.'
        governed = self.local_path(rel)
        git_dir = self.run_git(governed, ['rev-parse', '--absolute-git-dir'])['stdout'].strip()
        need(bool(git_dir), 'Git directory could not be resolved.')
        git_path = Path(git_dir).resolve()
        need(git_path.is_relative_to(self.root), 'Git metadata escapes package root.')
        return governed

    def load(self):
        if not self.statefile.exists():
            return {'schema': STATE_SCHEMA, 'repositories': {}, 'jobs': [],
                    'reports': [], 'stop_requested': False}
        state = read(self.statefile)
        need(isinstance(state, dict) and state.get('schema') == STATE_SCHEMA, 'Invalid Python Git state schema.')
        for key, kind in [('repositories', dict), ('jobs', list), ('reports', list)]:
            need(isinstance(state.get(key), kind), 'Invalid Python Git state: ' + key)
        need(type(state.get('stop_requested')) is bool, 'Invalid Python Git stop flag.')
        need(all(isinstance(j, dict) and j.get('state') in TERMINAL | {'pending', 'running', 'interrupted'} for j in state['jobs']), 'Invalid Python Git job state.')
        return state

    def atomic(self, path, value):
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_name('.' + uuid.uuid4().hex + '.tmp')
        try:
            with temp.open('x', encoding='utf-8') as stream:
                json.dump(value, stream, indent=2, ensure_ascii=False)
                stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
            os.replace(temp, path)
        finally:
            temp.unlink(missing_ok=True)

    def save(self, state):
        self.atomic(self.statefile, state)

    def resolve(self, selector):
        self.healthy()
        state = self.load()
        value = state['repositories'].get(selector, selector)
        repo = self.repository(value)
        return repo, repo.relative_to(self.root).as_posix() or '.'

    def connect(self, name, path):
        need(NAME.fullmatch(name or '') is not None, 'Connection name must be a simple identifier.')
        repo = self.repository(path)
        relative = repo.relative_to(self.root).as_posix() or '.'
        snapshot = self.snapshot(relative)
        with self.accord.lock():
            state = self.load(); state['repositories'][name] = relative; self.save(state)
        return {'name': name, 'repository': relative, 'snapshot': snapshot}

    def head(self, repo):
        head = self.run_git(repo, ['rev-parse', '--verify', 'HEAD'], True)
        branch = self.run_git(repo, ['symbolic-ref', '--quiet', '--short', 'HEAD'], True)
        return {'commit': head['stdout'].strip() if head['code'] == 0 else None,
                'branch': branch['stdout'].strip() if branch['code'] == 0 else None,
                'detached': head['code'] == 0 and branch['code'] != 0,
                'unborn': head['code'] != 0}

    def status(self, selector):
        repo, rel = self.resolve(selector)
        raw = self.run_git(repo, ['status', '--porcelain=v2', '--branch', '-z'])['stdout']
        tokens = [x for x in raw.split('\0') if x]
        headers = {}; entries = []
        for token in tokens:
            if token.startswith('# '):
                key, _, value = token[2:].partition(' '); headers[key] = value
            else:
                entries.append(token)
        return {'repository': rel, 'head': self.head(repo), 'clean': not entries,
                'entry_count': len(entries), 'entries': entries, 'branch_headers': headers}

    def branches(self, selector):
        repo, rel = self.resolve(selector)
        result = self.run_git(repo, ['for-each-ref', '--format=%(refname:short)%09%(objectname)%09%(HEAD)', 'refs/heads'])['stdout']
        rows = []
        for line in result.splitlines():
            fields = line.split('\t')
            need(len(fields) == 3, 'Unexpected Git branch record.')
            rows.append({'name': fields[0], 'commit': fields[1], 'current': fields[2] == '*'})
        return {'repository': rel, 'branches': rows}

    def log(self, selector, limit=20):
        need(type(limit) is int and 1 <= limit <= self.policy['max_log_entries'], 'Log limit out of range.')
        repo, rel = self.resolve(selector)
        if self.head(repo)['unborn']:
            return {'repository': rel, 'entries': []}
        result = self.run_git(repo, ['log', '--no-decorate', '-z', f'--max-count={limit}',
                                     '--format=%H%x00%aI%x00%an%x00%s%x00'])['stdout']
        fields = [x for x in result.split('\0') if x]
        rows = [{'commit': fields[i], 'author_time': fields[i+1], 'author': fields[i+2], 'subject': fields[i+3]}
                for i in range(0, len(fields) - 3, 4)]
        return {'repository': rel, 'entries': rows}

    def diff(self, selector, staged=False):
        repo, rel = self.resolve(selector)
        args = ['diff', '--no-ext-diff', '--no-textconv', '--stat', '--']
        if staged: args.insert(1, '--cached')
        result = self.run_git(repo, args)['stdout']
        return {'repository': rel, 'staged': staged, 'stat': result, 'sha256': hashlib.sha256(result.encode()).hexdigest()}

    def files(self, selector):
        repo, rel = self.resolve(selector)
        fields = [x for x in self.run_git(repo, ['ls-files', '-z'])['stdout'].split('\0') if x]
        return {'repository': rel, 'count': len(fields), 'files': fields}

    def remotes(self, selector):
        repo, rel = self.resolve(selector)
        names = [x for x in self.run_git(repo, ['remote'])['stdout'].splitlines() if x]
        rows = []
        for name in names:
            need(NAME.fullmatch(name) is not None, 'Repository contains an unsupported remote name.')
            value = self.run_git(repo, ['remote', 'get-url', name], True)
            rows.append({'name': name, 'url': redact_url(value['stdout']) if value['code'] == 0 else None})
        return {'repository': rel, 'remote_operations_allowed': False, 'remotes': rows}

    def snapshot(self, selector):
        status = self.status(selector)
        branch = self.branches(selector)
        files = self.files(selector)
        remotes = self.remotes(selector)
        body = {'repository': status['repository'], 'head': status['head'], 'clean': status['clean'],
                'entry_count': status['entry_count'], 'branches': branch['branches'],
                'tracked_files': files['count'], 'remotes': remotes['remotes']}
        return {**body, 'sha256': canonical_hash(body)}

    def read_operation(self, selector, op, options=None):
        options = options or {}
        need(op in READ_OPS, 'Unsupported read operation.')
        need(set(options) <= {'limit'}, 'Unsupported read options.')
        if op == 'status': return self.status(selector)
        if op == 'branches': return self.branches(selector)
        if op == 'log': return self.log(selector, options.get('limit', 20))
        if op == 'diff': return self.diff(selector, False)
        if op == 'staged-diff': return self.diff(selector, True)
        if op == 'files': return self.files(selector)
        if op == 'remotes': return self.remotes(selector)
        return self.snapshot(selector)

    def hooks(self, repo):
        path = self.run_git(repo, ['rev-parse', '--git-path', 'hooks'])['stdout'].strip()
        hooks = Path(path)
        if not hooks.is_absolute(): hooks = repo / hooks
        hooks = hooks.resolve()
        if not hooks.is_relative_to(self.root):
            return ['external-hooks-path']
        return sorted(p.name for p in hooks.glob('*') if p.is_file() and os.access(p, os.X_OK) and not p.name.endswith('.sample')) if hooks.is_dir() else []

    def repository_programs(self, repo):
        hooks = self.hooks(repo)
        configured = self.run_git(repo, ['config', '--get-regexp', r'^(filter\..*\.(clean|process)|core\.fsmonitor)$'], True)
        keys = []
        need(configured['code'] in {0, 1}, 'Git filter/hook configuration could not be inspected.')
        for line in configured['stdout'].splitlines():
            parts = line.split(None, 1)
            key = parts[0] if parts else ''
            value = parts[1].strip().lower() if len(parts) == 2 else ''
            if key == 'core.fsmonitor' and value in {'false', 'no', 'off', '0', ''}:
                continue
            if key and key not in keys:
                keys.append(key)
        return {'hooks': hooks, 'config_keys': keys}

    def valid_ref(self, name):
        need(isinstance(name, str) and REF.fullmatch(name) is not None and '..' not in name and '@{' not in name
             and not name.endswith(('.', '/')) and not name.startswith(('.', '/')) and '//' not in name,
             'Invalid branch or tag name.')
        return name

    def pathspecs(self, repo, values):
        need(isinstance(values, list) and values, 'At least one explicit pathspec is required.')
        output = []
        for value in values:
            need(isinstance(value, str) and value and '\\' not in value and '\0' not in value, 'Invalid pathspec.')
            rel = PurePosixPath(value)
            need(not rel.is_absolute() and '..' not in rel.parts and '.git' not in rel.parts, 'Pathspec escapes or targets Git internals.')
            output.append(value)
        return output

    def mutation(self, selector, operation, apply=False, **values):
        repo, rel = self.resolve(selector)
        need(operation in {'add', 'commit', 'create-branch', 'switch-branch', 'create-tag'}, 'Unsupported mutation.')
        permission = {'add': 'allowLocalAdd', 'commit': 'allowLocalCommit',
                      'create-branch': 'allowBranchCreate', 'switch-branch': 'allowBranchSwitch',
                      'create-tag': 'allowTagCreate'}[operation]
        need(self.legacy.get(permission) is True, 'Operation disabled by Gits policy.')
        programs = self.repository_programs(repo)
        allow_programs = values.get('allow_repository_programs') is True or values.get('allow_hooks') is True
        if operation == 'add':
            paths = self.pathspecs(repo, values.get('paths'))
            args = ['add', '--', *paths]; summary = {'paths': paths}
        elif operation == 'commit':
            message = values.get('message')
            need(isinstance(message, str) and 1 <= len(message) <= 500 and '\0' not in message, 'Commit message must be 1..500 characters.')
            args = ['-c', 'commit.gpgSign=false', 'commit', '-m', message]
            summary = {'message': message, 'signing_disabled_for_command': True}
        elif operation == 'create-branch':
            name = self.valid_ref(values.get('name')); args = ['branch', name]; summary = {'name': name}
        elif operation == 'switch-branch':
            name = self.valid_ref(values.get('name')); args = ['switch', name]; summary = {'name': name}
        else:
            name = self.valid_ref(values.get('name')); args = ['tag', name]; summary = {'name': name}
        preview = {'repository': rel, 'operation': operation, 'apply': apply,
                   'before': self.snapshot(rel), 'arguments': summary,
                   'repository_programs': programs,
                   'repository_programs_allowed': allow_programs}
        if not apply:
            return preview
        need(not self.healthy()['embargo'], 'Accord embargo blocks Git mutations.')
        active = programs['hooks'] + programs['config_keys']
        need(not active or allow_programs,
             'Repository hooks or filters may execute programs; inspect them and pass --allow-repository-programs: ' + ', '.join(active))
        self.run_git(repo, args)
        return {**preview, 'after': self.snapshot(rel), 'executed': True}

    def initialize(self, path, branch='main', apply=False):
        need(self.legacy.get('allowInitialize') is True, 'Initialization disabled by Gits policy.')
        branch = self.valid_ref(branch)
        target = self.local_path(path, create=apply, allow_missing=not apply)
        preview = {'repository': target.relative_to(self.root).as_posix(), 'operation': 'initialize',
                   'initial_branch': branch, 'apply': apply}
        if not apply: return preview
        need(not self.healthy()['embargo'], 'Accord embargo blocks repository initialization.')
        need(not (target / '.git').exists(), 'Target already contains .git.')
        self.run_git(target, ['init', '--initial-branch=' + branch, '--'])
        return {**preview, 'executed': True, 'snapshot': self.snapshot(preview['repository'])}

    def compile_script(self, relative):
        path = self.accord.path(relative, True)
        need(path.stat().st_size <= 1024 * 1024, 'Git command scripture exceeds 1 MiB.')
        payload = path.read_bytes(); source = json.loads(payload)
        need(isinstance(source, dict) and source.get('schema') == SCRIPT_SCHEMA, 'Invalid Python Git command scripture schema.')
        need(set(source) == {'schema', 'name', 'repository', 'steps'}, 'Script requires schema, name, repository and steps only.')
        need(isinstance(source['name'], str) and 1 <= len(source['name']) <= 100, 'Script name must be 1..100 characters.')
        repo, rel = self.resolve(source['repository'])
        steps = source['steps']
        need(isinstance(steps, list) and 1 <= len(steps) <= self.policy['max_script_steps'], 'Invalid script step count.')
        compiled = []
        for step in steps:
            need(isinstance(step, dict) and set(step) <= {'op', 'limit'}, 'Unknown Git script fields.')
            op = step.get('op'); need(op in READ_OPS, 'Bot command scripture accepts read operations only.')
            row = {'op': op}
            if 'limit' in step:
                need(op == 'log' and type(step['limit']) is int and 1 <= step['limit'] <= self.policy['max_log_entries'], 'Limit is valid only for log.')
                row['limit'] = step['limit']
            compiled.append(row)
        return {'schema': SCRIPT_SCHEMA, 'name': source['name'], 'source': relative,
                'script_sha256': hashlib.sha256(payload).hexdigest(),
                'repository': rel, 'head_at_compile': self.head(repo), 'steps': compiled}

    def report(self, script, results, error=None):
        body = {'schema': REPORT_SCHEMA, 'id': uuid.uuid4().hex, 'time': time.time(),
                'passed': error is None, 'script': script, 'results': results, 'error': error}
        body['sha256'] = canonical_hash({k: v for k, v in body.items() if k not in {'id', 'time'}})
        path = self.rt / 'reports' / (body['id'] + '.json')
        with self.accord.lock():
            state = self.load(); self.atomic(path, body)
            state['reports'].append(path.relative_to(self.root).as_posix())
            state['reports'] = state['reports'][-256:]; self.save(state)
        return {**body, 'report_path': path.relative_to(self.root).as_posix()}

    def execute_script(self, script, stopped=lambda: False):
        results = []
        try:
            for step in script['steps']:
                if stopped(): raise InterruptedError('Bot stop requested.')
                options = {'limit': step['limit']} if 'limit' in step else {}
                result = self.read_operation(script['repository'], step['op'], options)
                results.append({'op': step['op'], 'result': result, 'sha256': canonical_hash(result)})
            return self.report(script, results)
        except InterruptedError:
            self.report(script, results, 'interrupted by stop request')
            raise
        except (OSError, ValueError, KeyError, TypeError) as exc:
            return self.report(script, results, str(exc))

    def enqueue(self, relative):
        script = self.compile_script(relative)
        with self.accord.lock():
            state = self.load()
            while len(state['jobs']) >= self.policy['max_jobs']:
                old = next((job for job in state['jobs'] if job['state'] in TERMINAL), None)
                need(old is not None, 'Python Git bot queue is full.')
                state['jobs'].remove(old)
            job = {'id': uuid.uuid4().hex, 'state': 'pending', 'created': time.time(),
                   'attempts': 0, 'script': script, 'report': None}
            state['jobs'].append(job); self.save(state); return job

    def control(self, action, ident=None):
        self.healthy()
        with self.accord.lock():
            state = self.load()
            if action == 'stop': state['stop_requested'] = True
            elif action == 'resume':
                need(not self.worker_lock.exists(), 'Wait for the Python Git worker to exit before resuming.')
                state['stop_requested'] = False
            elif action == 'recover':
                need(not self.worker_lock.exists(), 'Worker lock is present; verify the worker has exited first.')
                for job in state['jobs']:
                    if job['state'] == 'running':
                        job['state'] = 'interrupted'; job['error'] = 'Recovered after worker exit; explicit retry required.'
            elif action in {'cancel', 'retry'}:
                job = next((row for row in state['jobs'] if row['id'] == ident), None)
                need(job is not None, 'Unknown Python Git job ID.')
                if action == 'cancel':
                    need(job['state'] == 'pending', 'Only pending jobs can be cancelled.')
                    job['state'] = 'cancelled'
                else:
                    need(job['state'] in {'failed', 'interrupted', 'cancelled'}, 'Only failed, interrupted or cancelled jobs can be retried.')
                    job['state'] = 'pending'; job['report'] = None; job.pop('error', None)
            else: raise Denied('Unknown bot control action.')
            self.save(state)
            return {'action': action, 'job_id': ident, 'stop_requested': state['stop_requested']}

    @contextmanager
    def worker(self):
        with self.accord.lock():
            self.rt.mkdir(parents=True, exist_ok=True)
            try: descriptor = os.open(self.worker_lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            except FileExistsError as exc: raise Denied('Python Git bot worker is already active or needs recovery.') from exc
            with os.fdopen(descriptor, 'w') as stream: stream.write(str(os.getpid()))
        try: yield
        finally: self.worker_lock.unlink(missing_ok=True)

    def stopped(self):
        return self.load()['stop_requested']

    def run_bot(self, rounds=10, interval=0):
        need(type(rounds) is int and 1 <= rounds <= self.policy['max_rounds'], 'Round count out of range.')
        need(isinstance(interval, (int, float)) and 0 <= interval <= 60, 'Interval must be 0..60 seconds.')
        summary = []; self.healthy()
        with self.worker():
            for _ in range(rounds):
                self.healthy()
                with self.accord.lock():
                    state = self.load()
                    if state['stop_requested']: break
                    job = next((row for row in state['jobs'] if row['state'] == 'pending'), None)
                    if job is None: break
                    job['state'] = 'running'; job['attempts'] += 1; self.save(state)
                    ident, script = job['id'], job['script']
                try:
                    result = self.execute_script(script, self.stopped)
                    state_name = 'completed' if result['passed'] else 'failed'
                    report, error = result['report_path'], result['error']
                except (InterruptedError, KeyboardInterrupt):
                    state_name, report, error = 'interrupted', None, 'Worker stopped; explicit retry required.'
                except (OSError, ValueError, KeyError, TypeError) as exc:
                    state_name, report, error = 'failed', None, str(exc)
                with self.accord.lock():
                    state = self.load(); job = next(row for row in state['jobs'] if row['id'] == ident)
                    job.update(state=state_name, report=report, error=error, finished=time.time()); self.save(state)
                summary.append({'id': ident, 'state': state_name, 'report': report, 'error': error})
                if state_name == 'interrupted': break
                until = time.monotonic() + interval
                while time.monotonic() < until and not self.stopped(): time.sleep(min(.1, until - time.monotonic()))
        return {'rounds_completed': len(summary), 'jobs': summary, 'stop_requested': self.stopped()}

    def manager_status(self):
        state = self.load()
        return {'git': self.git, 'git_version': self.run_git(self.root, ['--version'], True)['stdout'].strip(),
                'embargo': self.healthy()['embargo'], 'remote_operations_allowed': False,
                'repositories': state['repositories'], 'stop_requested': state['stop_requested'],
                'worker_lock_present': self.worker_lock.exists(),
                'jobs': [{k:v for k,v in j.items() if k != 'script'} for j in state['jobs']],
                'recent_reports': state['reports'][-10:]}


def menu(manager):
    while True:
        print('\nPYTHON GIT REPOSITORY CONNECTOR / BOT MANAGER')
        print(' 1  Manager status\n 2  Connect repository alias\n 3  Repository status')
        print(' 4  Branches\n 5  Log\n 6  Working diff stat\n 7  Staged diff stat')
        print(' 8  Tracked files\n 9  Redacted remotes\n10  Snapshot')
        print('11  Validate command scripture\n12  Run scripture now\n13  Queue scripture')
        print('14  Run finite bot rounds\n15  Stop bot\n16  Resume bot')
        print('17  Preview local mutation\n18  Apply local mutation\n B  Back')
        try:
            choice = input('Select: ').strip().upper()
            if choice in {'B', 'Q'}: return
            if choice == '1': result = manager.manager_status()
            elif choice == '2': result = manager.connect(input('Alias: ').strip(), input('Repository path: ').strip())
            elif choice in {'3','4','5','6','7','8','9','10'}:
                selector = input('Alias or repository path: ').strip()
                op = {'3':'status','4':'branches','5':'log','6':'diff','7':'staged-diff','8':'files','9':'remotes','10':'snapshot'}[choice]
                result = manager.read_operation(selector, op)
            elif choice in {'11','12','13'}:
                path = input('Command scripture path: ').strip()
                result = manager.enqueue(path) if choice == '13' else manager.compile_script(path)
                if choice == '12': result = manager.execute_script(result)
            elif choice == '14': result = manager.run_bot(int(input('Rounds: ')), float(input('Interval seconds: ') or '0'))
            elif choice in {'15','16'}: result = manager.control('stop' if choice == '15' else 'resume')
            elif choice in {'17','18'}:
                selector = input('Alias or repository path: ').strip()
                op = input('add, commit, create-branch, switch-branch, or create-tag: ').strip()
                values = {}
                if op == 'add': values['paths'] = [x.strip() for x in input('Paths separated by |: ').split('|') if x.strip()]
                elif op == 'commit': values['message'] = input('Commit message: ')
                else: values['name'] = input('Branch/tag name: ').strip()
                result = manager.mutation(selector, op, apply=choice == '18', **values)
            else: continue
            print(json.dumps(result, indent=2))
        except (EOFError, KeyboardInterrupt): print('\nStopped.'); return
        except (OSError, ValueError, KeyError, TypeError) as exc: print('DENIED:', exc)


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    sub = p.add_subparsers(dest='action', required=True)
    for name in ('menu','manager-status','stop','resume','recover'): sub.add_parser(name)
    q=sub.add_parser('connect');q.add_argument('name');q.add_argument('repository')
    for name in ('status','branches','diff','staged-diff','files','remotes','snapshot'):
        sub.add_parser(name).add_argument('repository')
    q=sub.add_parser('log');q.add_argument('repository');q.add_argument('--limit',type=int,default=20)
    for name in ('script-check','script-run','enqueue'): sub.add_parser(name).add_argument('script')
    for name in ('cancel','retry'): sub.add_parser(name).add_argument('id')
    q=sub.add_parser('bot-run');q.add_argument('--rounds',type=int,default=10);q.add_argument('--interval',type=float,default=0)
    q=sub.add_parser('init');q.add_argument('repository');q.add_argument('--branch',default='main');q.add_argument('--apply',action='store_true')
    for name in ('add','commit','create-branch','switch-branch','create-tag'):
        q=sub.add_parser(name);q.add_argument('repository');q.add_argument('--apply',action='store_true')
        q.add_argument('--allow-repository-programs',action='store_true')
        if name=='add':q.add_argument('paths',nargs='+')
        elif name=='commit':q.add_argument('--message',required=True);q.add_argument('--allow-hooks',action='store_true')
        else:q.add_argument('name')
    return p


def main():
    args=vars(parser().parse_args()); root=args.pop('root'); action=args.pop('action')
    try:
        manager=PythonGit(root)
        if action=='menu':menu(manager);return 0
        if action=='manager-status':result=manager.manager_status()
        elif action=='connect':result=manager.connect(args['name'],args['repository'])
        elif action in READ_OPS:
            repository=args.pop('repository'); result=manager.read_operation(repository,action,args)
        elif action=='script-check':result=manager.compile_script(args['script'])
        elif action=='script-run':result=manager.execute_script(manager.compile_script(args['script']))
        elif action=='enqueue':result=manager.enqueue(args['script'])
        elif action=='bot-run':result=manager.run_bot(args['rounds'],args['interval'])
        elif action in {'stop','resume','recover','cancel','retry'}:result=manager.control(action,args.get('id'))
        elif action=='init':result=manager.initialize(args['repository'],args['branch'],args['apply'])
        else:
            repository=args.pop('repository');apply=args.pop('apply');result=manager.mutation(repository,action,apply,**args)
        print(json.dumps(result,indent=2,ensure_ascii=False))
        failed=result.get('passed') is False or any(j['state']!='completed' for j in result.get('jobs',[]))
        return 2 if failed else 0
    except KeyboardInterrupt:return 130
    except (OSError,ValueError,KeyError,TypeError) as exc:
        print(json.dumps({'passed':False,'error':str(exc)}),file=sys.stderr);return 2

if __name__=='__main__':sys.exit(main())
