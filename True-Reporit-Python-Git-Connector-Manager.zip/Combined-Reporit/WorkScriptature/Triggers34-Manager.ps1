#requires -Version 5.1
[CmdletBinding()]
param([string]$Repository='', [switch]$NoClear)
$ErrorActionPreference='Stop'
& (Join-Path $PSScriptRoot 'Work-Scriptature.ps1') -Action Menu
