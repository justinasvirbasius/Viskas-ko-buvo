# Python Git repository connector and bot manager

This connector brings the existing local **Gits accord** into the Python manager.
It discovers governed repositories, records structured views, executes bounded
read-only command scriptures, and runs their reports through a finite foreground
bot queue. Local repository changes remain preview-first and require an explicit
`--apply` switch. The connector reads `Gits/Gits.policy.json`; it cannot enable
an operation that policy disables.

## Requirements and start

- Python 3.10 or later.
- Git available on `PATH`.
- Repository directories located under the extracted `Combined-Reporit` root.

```console
python WorkScriptature/python_git_connector.py menu
```

Windows convenience launcher: `Start-Python-Git-Manager.cmd`. The 34-trigger
manager also exposes **git tools**. PowerShell can open it with:

```powershell
.\WorkScriptature\Work-Scriptature.ps1 -Action PythonGit
```

All Git processes use argument arrays without a shell, a 30-second default
timeout, disabled terminal prompts and bounded output. System and global Git
configuration are ignored. Repository-local configuration remains active, so
commit identity should be set in that repository:

```console
git -C demo-repository config user.name "Local Operator"
git -C demo-repository config user.email "operator@example.invalid"
```

The connector disables Git coloring, paging, optional locks for reads,
filesystem-monitor hooks, external diff drivers and text conversion where the
corresponding view can invoke them. It rejects a repository whose work tree or
Git metadata resolves outside the package root.

## Connect and inspect

Register a short alias for an existing repository:

```console
python WorkScriptature/python_git_connector.py connect demo demo-repository
python WorkScriptature/python_git_connector.py status demo
```

The alias and path are local state. You can also pass `demo-repository` directly.
Available read commands:

```console
python WorkScriptature/python_git_connector.py branches demo
python WorkScriptature/python_git_connector.py log demo --limit 20
python WorkScriptature/python_git_connector.py diff demo
python WorkScriptature/python_git_connector.py staged-diff demo
python WorkScriptature/python_git_connector.py files demo
python WorkScriptature/python_git_connector.py remotes demo
python WorkScriptature/python_git_connector.py snapshot demo
```

`status` returns porcelain-v2 entries, branch metadata, HEAD and clean state.
`branches` returns local branch names and commits. `log` returns bounded commit
metadata. `diff` and `staged-diff` return statistics and their SHA-256. `files`
returns tracked paths. `snapshot` combines HEAD, clean state, branches, tracked
file count, redacted remotes and a canonical SHA-256.

Remote inspection removes usernames, passwords, queries and fragments. Local
remote paths expose only their final name. The connector does not contact the
remote. The inherited policy has `allowRemoteOperations: false`, so this Python
surface provides no clone, fetch, pull, push or remote-configuration command.
It also provides no merge, reset, restore, clean, rebase, force, delete or
history-rewrite command.

## Python Git command scripture

`python-git-command/1` is a bounded JSON report plan. Copy
`WorkScriptature/PythonGit.example.json` and change its repository field to a
real relative repository path or registered alias:

```json
{
  "schema": "python-git-command/1",
  "name": "Local repository inspection",
  "repository": "demo",
  "steps": [
    {"op": "status"},
    {"op": "branches"},
    {"op": "log", "limit": 10},
    {"op": "diff"},
    {"op": "remotes"},
    {"op": "snapshot"}
  ]
}
```

Only `status`, `branches`, `log`, `diff`, `staged-diff`, `files`, `remotes`, and
`snapshot` are accepted. Unknown fields and mutation commands are rejected.
The default maximum is 32 steps and 100 log entries. Validation pins the
resolved repository path and records its HEAD plus the exact script SHA-256.
Execution reads the repository's current state and writes a report whose steps
and complete report body each have canonical hashes.

```console
python WorkScriptature/python_git_connector.py script-check git-inspection.json
python WorkScriptature/python_git_connector.py script-run git-inspection.json
```

## Finite bot manager

Queue a validated copy of the scripture, then run a bounded number of jobs:

```console
python WorkScriptature/python_git_connector.py enqueue git-inspection.json
python WorkScriptature/python_git_connector.py manager-status
python WorkScriptature/python_git_connector.py bot-run --rounds 10 --interval 0
```

One round claims one pending job. The foreground worker stops when it reaches
the limit, has no work, or sees the persistent stop flag. Defaults permit up to
100 rounds and 60 seconds between jobs. A single-worker lock prevents two bot
workers from claiming the same queue.

From another terminal:

```console
python WorkScriptature/python_git_connector.py stop
```

After the worker exits:

```console
python WorkScriptature/python_git_connector.py resume
python WorkScriptature/python_git_connector.py retry JOB_ID
```

`cancel JOB_ID` accepts pending jobs. `retry JOB_ID` accepts failed,
interrupted, or cancelled jobs and retains their compiled scripture. `recover`
marks jobs left `running` after a confirmed worker crash as interrupted. Confirm
that no worker process remains before removing a stale
`.work-scriptature/python-git/worker.lock` and invoking recovery. Jobs are never
retried automatically.

Reports are stored under `.work-scriptature/python-git/reports`; state is stored
in `.work-scriptature/python-git/state.json`. These runtime paths are excluded
from the source checksum manifest. Reports are local integrity records, not
signatures. A crash between report creation and queue-state replacement can
leave an orphaned report, so inspect the queue after recovery.

## Governed local changes

Initialization and mutations preview by default:

```console
python WorkScriptature/python_git_connector.py init new-repository --branch main
python WorkScriptature/python_git_connector.py add demo notes.md
python WorkScriptature/python_git_connector.py commit demo --message "Document connector"
python WorkScriptature/python_git_connector.py create-branch demo feature/notes
python WorkScriptature/python_git_connector.py switch-branch demo feature/notes
python WorkScriptature/python_git_connector.py create-tag demo review-1
```

Add `--apply` only after reviewing the JSON preview:

```console
python WorkScriptature/python_git_connector.py add demo notes.md --apply
python WorkScriptature/python_git_connector.py commit demo --message "Document connector" --apply
```

Staging requires explicit literal paths. Parent paths, drive paths and `.git`
internals are rejected. Branch and tag names are checked before Git sees them.
An active Work Scriptature embargo blocks initialization and every mutation,
while reads and reports remain available for diagnosis. Commit signing is
disabled for this connector's commit command so it cannot unexpectedly open a
signing helper.

Git hooks, clean/process filters and an external filesystem monitor can execute
programs from repository configuration. The preview lists their names without
printing their commands. Apply refuses while any are active. After inspecting
and accepting them, repeat the exact operation with:

```console
--allow-repository-programs --apply
```

The older `--allow-hooks` spelling remains accepted for commit compatibility.
This consent applies only to that command invocation. The interactive menu does
not add this override; use the explicit CLI when required.

The policy currently permits local initialization, add, commit, branch creation,
branch switching and tag creation. Each mutation returns a before and after
snapshot. The connector does not create commits automatically, stage an entire
repository implicitly, configure identity, or publish anything.

## Verification

```console
python -m unittest discover -s WorkScriptature/tests -v
python WorkScriptature/work_scriptature.py self-test
```

The connector tests create temporary repositories and cover status, branches,
log, dirty and staged diffs, tracked files, snapshots, credential redaction,
root and symbolic-link confinement, scripture validation, finite jobs,
stop/resume/retry, initialization, preview/apply mutations, embargo blocking,
hook and filter gating, output bounds, state corruption, one-worker exclusion,
CLI execution and the interactive menu. No remote Git operation is performed.
