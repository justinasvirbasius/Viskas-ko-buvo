# Work Scriptature — 34 Triggers / Embargo Lift

This extends the existing True Reporit 24-trigger manager with ten proposal,
validation, decree and embargo-lift events. The original 24 IDs and meanings
remain. These are local software workflow terms: a **decree** records an
operator's decision, and an **embargo lift** changes this manager's release
state. New proposals start undecreed and do not execute themselves.

## Start the manager

Requires **Python 3.10 or later**. The core uses the standard library only.
From the extracted `Combined-Reporit` folder:

```console
python WorkScriptature/work_scriptature.py menu
```

Windows: run `Start-34-Triggers-Manager.cmd`, or:

```powershell
.\WorkScriptature\Triggers34-Manager.ps1
```

The Windows launcher uses your installed PowerShell and its existing execution
policy. The Python command works directly if script execution is restricted.
Old `Start-24-Triggers-Manager.cmd` and `Triggers24-Manager.ps1` launch the new
menu. Scriptature menu item 11 also opens it.

## What was added

| Trigger | Event | Command / effect |
|---|---|---|
| ZA-25 | invention-proposed | `propose`: register an undecreed proposal |
| ZA-26 | contract-bound | `bind-contract`: hash its contract and scoped files |
| ZA-27 | evidence-recorded | `add-evidence`: attach a hashed report and review outcome |
| ZA-28 | validation-passed | `validate`: verify package integrity and bound evidence |
| ZA-29 | decree-recorded | `decree`: record the operator and release rationale |
| ZA-30 | lift-requested | `request-lift`: prepare a scoped, expiring request |
| ZA-31 | lift-verified | `verify-lift`: bind verification to the state revision and manifest |
| ZA-32 | embargo-lifted | `lift-embargo`: recheck, clear embargo, mark selected proposals released |
| ZA-33 | decree-revoked | `revoke`: withdraw a decree and raise a blocking cause |
| ZA-34 | evidence-drift | `check-evidence`: withdraw a stale decree and raise embargo |

The full mapping is in `TRIGGERS-34.md` and `Triggers34.json`.

The proposed-technology catalog, `Inventions.proposed.json`, contains three
new contracts derived from the earlier accord: **ULA scoped locators**,
**receipt-bound sudden disposal**, and **revision-bound embargo lift**. They
are proposals for adopting this implementation. They are not automatically
imported, decreed, or released, and are not claims of proven technical novelty.
No prior ten-invention list was present in the source package or recovered
Reporit discussion. The ten new entries above are lifecycle triggers.

## Embargo lift: no proposal release

1. In **status**, read the active cause IDs.
2. Correct each underlying problem. Use **resolve cause** with the correction
   and operator name. Resolving a cause does not clear embargo.
3. Use **request lift**, leaving proposal IDs blank. Copy its request ID.
4. Use **verify lift** with that ID.
5. Use **lift embargo** with the same ID.

The manifest is verified at request, verification and final application.
Unresolved causes, malformed state, missing/changed/unlisted source files,
changed evidence of already released proposals, or expired requests deny the
lift. Any successful intervening governance mutation invalidates the request.
Read-only inspection does not. The default expiry is 15 minutes; the policy may
shorten it. Selected proposal IDs are included in the request and cannot be
added after verification. A global lift leaves undecreed proposals untouched.

CLI equivalent (`CAUSE_ID` and `REQUEST_ID` are values returned by the manager):

```console
python WorkScriptature/work_scriptature.py resolve-cause CAUSE_ID --actor operator --reason "Corrected and checked"
python WorkScriptature/work_scriptature.py request-lift --actor operator --reason "Ready to resume"
python WorkScriptature/work_scriptature.py verify-lift REQUEST_ID
python WorkScriptature/work_scriptature.py lift-embargo REQUEST_ID
```

The old `Work-Scriptature.ps1 -Action ClearEmbargo` now explains the verified
workflow and refuses a direct clear. It cannot silently bypass these stages.

## Propose and release technology

Prepare a contract, the actual scoped files, and an independent test report.
The contract should state purpose, input/output behavior, constraints, test
criteria and rollback steps. Then use the menu, or these commands from the
package root (replace the example paths with your files):

```console
python WorkScriptature/work_scriptature.py propose TECH-001 --title "Candidate technology" --reason "Purpose and expected improvement"
python WorkScriptature/work_scriptature.py bind-contract TECH-001 contracts/TECH-001.txt --scope candidates/implementation.py
python WorkScriptature/work_scriptature.py add-evidence TECH-001 evidence/TECH-001.txt --outcome pass --actor reviewer --reason "Observed tests and results"
python WorkScriptature/work_scriptature.py validate TECH-001
python WorkScriptature/work_scriptature.py decree TECH-001 --actor operator --reason "Contract and evidence reviewed"
python WorkScriptature/work_scriptature.py request-lift --proposal TECH-001 --actor operator --reason "Release approved scope"
python WorkScriptature/work_scriptature.py verify-lift REQUEST_ID
python WorkScriptature/work_scriptature.py lift-embargo REQUEST_ID
```

Stage intentional source changes and inspect the diff before rebuilding the
baseline with `python ZA/za_analysis.py --refresh`. This is an authoring action,
not a repair for unexplained drift. Do it before requesting a lift. Refreshing
the manifest after verification invalidates the request. `.txt` evidence and
contract files are bound by their own hashes; code, JSON and Markdown are also
covered by the source manifest.

**Evidence validation verifies file identity and the recorded review outcome.**
It does not run a submitted program or prove the truth of a test report.
Run meaningful tests separately and record their real results. Operator names
are local attestations, not authenticated signatures. `released` is a registry
state; it does not deploy code or grant operating-system privileges.

Use `check-evidence TECH-001` to inspect an existing proposal. Drift raises
embargo and withdraws its decree. Use `revoke TECH-001 --actor operator --reason
"..."` to withdraw it deliberately. To revise it, bind a new contract; this
clears old evidence and the decree. A released proposal must first be revoked.

## Trigger controls and execution scope

`evaluate --trigger ZA-05` previews a trigger without mutation. `signal ZA-05
--reason "Observed drift"` records a reported failure and raises embargo for a
critical trigger. Optional events can be toggled with `set-trigger ZA-01 off`.
Integrity triggers and new governance triggers cannot be disabled.

The manager is foreground and event-driven. It does not install watchers,
scheduled tasks or background services. Existing triggers recommending review,
inventory or quarantine emit receipts/recommendations; a `signal` never moves
or deletes files automatically. New workflow events are emitted by their
corresponding commands. Source/evidence checks run when requested and at the
release gates; continuous monitoring is not claimed.

This embargo governs Work Scriptature operations. It is not a blanket guard
over independently launched Git, ticker, Python server-manager, or shell
commands included in the archive. Those tools retain their own policies.
The manager makes no network requests and does not add GitHub write actions.

## ULA and sudden disposal

ULA retains the earlier meaning: repository-relative file locators and allowed
URI schemes. Use forward slashes for local paths. Parent traversal, absolute
paths, drive/stream paths, symlink escapes, credential-bearing URIs and denied
schemes are rejected. `file:relative/path` is accepted; absolute `file:///...`
URIs and network shares are rejected. Checking an HTTPS/SSH/Git URI does not
connect to it or certify its server.

Quarantine accepts disposable data under a subdirectory, such as `temp/item.bin`.
Protected source trees, root files, runtime state, and governed source files
cannot be moved. Embargo blocks quarantine moves and purge. Quarantine returns
an ID and records the intake time, source, destination and SHA-256.

```console
python WorkScriptature/work_scriptature.py quarantine temp/item.bin
python WorkScriptature/work_scriptature.py purge QUARANTINE_ID --confirm-purge
```

Purge requires the recorded ID, explicit confirmation, a clear embargo, a
matching checksum, and at least one hour **since intake**, regardless of the
file's original modification time. The menu requires typing `PURGE`. Untracked
quarantine files are retained and cannot be purged through this manager.

## State, migration and recovery

All new state and receipts are stored in `.work-scriptature/accord34.json`.
Writes use a single-writer lock and atomic state replacement. Read-only commands
do not create runtime directories. Runtime state is excluded from source hashes.
Keep it when upgrading; distribute source archives without it.

If no 34-trigger state exists, the manager reads legacy `embargo.json` and
`trigger-enable.json`. An active legacy embargo becomes an unresolved `legacy`
cause. Optional enable choices are retained; mandatory integrity triggers stay
on. Legacy files and receipt files remain intact. Old quarantine entries are
not silently imported as new purge permissions.

Malformed state fails closed and is not overwritten. After a process crash,
confirm no manager process remains before removing `manager.lock`. State writes
are atomic, but a quarantine move or deletion and its receipt cannot be one
filesystem transaction: a crash in between may leave an untracked item or a
stale record. Inspect those cases manually; untracked items cannot be purged.
Receipts and manifests are local records, not tamper-proof signed audit trails.

## Verification

```console
python -m unittest discover -s WorkScriptature/tests -v
python WorkScriptature/work_scriptature.py self-test
python ZA/za_analysis.py
```

The included report records checks performed for this delivery. The Python
engine and console are tested. Windows PowerShell launchers require a Windows
runtime check; PowerShell was unavailable in the build environment.

## Cache ULA and Hash Bot Manager

Run `python WorkScriptature/hash_ula.py menu` from the package root, or use
`Start-ULA-Bot-Manager.cmd` on Windows. Includes cached local aliases, ten-fold
SHA-256, JSON hash scripts, and a finite bot queue with stop/resume and recovery.
See `WorkScriptature/HASH-ULA.md` for commands, hashing semantics and limits.

## Python bot command scripture

`kuvu_rot.py` adds Script Kuvu Rot: explicit movement routes over Hash ULA
locators, a NumPy/Python numerical rescript, guide decisions, and a numeric
ending. Start `python WorkScriptature/kuvu_rot.py menu` and read
`WorkScriptature/KUVU-ROT.md`.

## Python Git repository connector

`python_git_connector.py` adds a local Python Git manager, read-only command
scripture, finite report bot, and preview-first governed mutations. Run
`python WorkScriptature/python_git_connector.py menu`. See
`WorkScriptature/PYTHON-GIT-CONNECTOR.md`.
