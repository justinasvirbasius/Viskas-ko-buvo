import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'WorkScriptature'))
from python_git_connector import PythonGit, Denied, redact_url, canonical_hash

class PythonGitTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
  self.root=Path(self.tmp.name)/'package';shutil.copytree(ROOT,self.root,ignore=shutil.ignore_patterns('__pycache__','.work-scriptature'))
  self.repo=self.root/'repo';self.repo.mkdir()
  self.git('init','--initial-branch=main');self.git('config','user.name','Test User');self.git('config','user.email','test@example.invalid')
  (self.repo/'one.txt').write_text('one\n');self.git('add','one.txt');self.git('commit','-m','initial')
  self.manager=PythonGit(self.root)
  self.manager.connect('demo','repo')
  self.script={'schema':'python-git-command/1','name':'Inspection','repository':'demo','steps':[{'op':'status'},{'op':'branches'},{'op':'log','limit':5},{'op':'diff'},{'op':'remotes'},{'op':'snapshot'}]}
  self.write_script()
 def git(self,*args):
  return subprocess.run(['git','-C',str(self.repo),*args],check=True,capture_output=True,text=True)
 def write_script(self):
  (self.root/'git-script.json').write_text(json.dumps(self.script))

 def test_connect_status_branches_log_files_snapshot(self):
  status=self.manager.status('demo');self.assertTrue(status['clean']);self.assertEqual(status['head']['branch'],'main')
  self.assertTrue(self.manager.branches('demo')['branches'][0]['current'])
  self.assertEqual(self.manager.log('demo')['entries'][0]['subject'],'initial')
  self.assertEqual(self.manager.files('demo')['files'],['one.txt'])
  snap=self.manager.snapshot('demo');self.assertEqual(snap['sha256'],canonical_hash({k:v for k,v in snap.items() if k!='sha256'}))

 def test_dirty_and_staged_diff(self):
  (self.repo/'one.txt').write_text('one\ntwo\n')
  self.assertFalse(self.manager.status('demo')['clean'])
  self.assertIn('one.txt',self.manager.diff('demo')['stat'])
  self.git('add','one.txt');self.assertIn('one.txt',self.manager.diff('demo',True)['stat'])

 def test_remotes_redact_credentials_and_remote_ops_disabled(self):
  self.git('remote','add','origin','https://user:secret@example.com/org/repo.git?token=hidden#x')
  result=self.manager.remotes('demo');serialized=json.dumps(result)
  self.assertNotIn('secret',serialized);self.assertNotIn('hidden',serialized);self.assertNotIn('user',serialized)
  self.assertEqual(result['remotes'][0]['url']['host'],'example.com');self.assertFalse(result['remote_operations_allowed'])
  self.assertEqual(redact_url('git@example.com:org/repo.git')['host'],'example.com')

 def test_root_escape_symlink_and_non_repo_denied(self):
  outside=Path(self.tmp.name)/'outside';outside.mkdir();subprocess.run(['git','init',str(outside)],check=True,capture_output=True)
  (self.root/'link').symlink_to(outside,target_is_directory=True)
  for path in ('../outside','link','WorkScriptature'):
   with self.subTest(path=path):
    with self.assertRaises(Denied):self.manager.connect('bad',path)

 def test_command_script_is_read_only_and_pins_repository(self):
  compiled=self.manager.compile_script('git-script.json')
  self.assertEqual(compiled['repository'],'repo');self.assertEqual(len(compiled['steps']),6)
  self.script['steps']=[{'op':'commit'}];self.write_script()
  with self.assertRaises(Denied):self.manager.compile_script('git-script.json')

 def test_execute_report_and_finite_queue(self):
  compiled=self.manager.compile_script('git-script.json');report=self.manager.execute_script(compiled)
  self.assertTrue(report['passed']);self.assertTrue((self.root/report['report_path']).is_file())
  for _ in range(3):self.manager.enqueue('git-script.json')
  result=self.manager.run_bot(2);self.assertEqual(result['rounds_completed'],2)
  self.assertEqual([j['state'] for j in self.manager.load()['jobs']],['completed','completed','pending'])

 def test_stop_resume_interrupt_retry(self):
  job=self.manager.enqueue('git-script.json');self.manager.control('stop');self.assertEqual(self.manager.run_bot(1)['rounds_completed'],0)
  self.manager.control('resume')
  with patch.object(self.manager,'stopped',return_value=True):result=self.manager.run_bot(1)
  self.assertEqual(result['jobs'][0]['state'],'interrupted')
  self.manager.control('retry',job['id']);self.assertEqual(self.manager.run_bot(1)['jobs'][0]['state'],'completed')

 def test_mutations_preview_apply_and_embargo(self):
  (self.repo/'two.txt').write_text('two\n')
  preview=self.manager.mutation('demo','add',paths=['two.txt']);self.assertFalse(preview['apply'])
  self.assertNotIn('two.txt',self.git('diff','--cached','--name-only').stdout)
  self.manager.mutation('demo','add',apply=True,paths=['two.txt'])
  self.assertIn('two.txt',self.git('diff','--cached','--name-only').stdout)
  self.manager.mutation('demo','commit',apply=True,message='second')
  self.assertEqual(self.git('log','-1','--pretty=%s').stdout.strip(),'second')
  self.manager.mutation('demo','create-branch',apply=True,name='feature/test')
  self.manager.mutation('demo','switch-branch',apply=True,name='feature/test')
  self.manager.mutation('demo','create-tag',apply=True,name='v1-test')
  self.manager.accord.execute('raise-embargo',reason='hold')
  with self.assertRaisesRegex(Denied,'embargo'):self.manager.mutation('demo','create-branch',apply=True,name='blocked')

 def test_commit_hooks_need_explicit_permission(self):
  hook=Path(self.git('rev-parse','--git-path','hooks').stdout.strip())
  if not hook.is_absolute():hook=self.repo/hook
  hook.mkdir(exist_ok=True);p=hook/'pre-commit';p.write_text('#!/bin/sh\nexit 0\n');p.chmod(0o755)
  (self.repo/'one.txt').write_text('changed\n');self.git('add','one.txt')
  with self.assertRaisesRegex(Denied,'hooks'):self.manager.mutation('demo','commit',apply=True,message='hooked')
  self.manager.mutation('demo','commit',apply=True,message='hooked',allow_hooks=True)

 def test_clean_filter_needs_explicit_permission(self):
  self.git('config','filter.demo.clean','cat')
  (self.repo/'.gitattributes').write_text('filtered.txt filter=demo\n')
  (self.repo/'filtered.txt').write_text('value\n')
  with self.assertRaisesRegex(Denied,'filters'):
   self.manager.mutation('demo','add',apply=True,paths=['filtered.txt'])
  self.manager.mutation('demo','add',apply=True,paths=['filtered.txt'],allow_repository_programs=True)

 def test_initialize_preview_and_apply(self):
  preview=self.manager.initialize('new');self.assertFalse(preview['apply']);self.assertFalse((self.root/'new').exists())
  done=self.manager.initialize('new',apply=True);self.assertTrue(done['executed']);self.assertTrue((self.root/'new/.git').is_dir())

 def test_pathspec_ref_output_and_timeout_controls(self):
  for path in ('../x','.git/config','C:\\x'):
   with self.assertRaises(Denied):self.manager.mutation('demo','add',paths=[path])
  for ref in ('../bad','bad..name','bad@{x}','/bad','bad/'):
   with self.assertRaises(Denied):self.manager.mutation('demo','create-branch',name=ref)
  self.manager.policy['max_output_bytes']=10
  with self.assertRaisesRegex(Denied,'output'):self.manager.status('demo')

 def test_invalid_state_policy_and_single_worker_fail_closed(self):
  self.manager.rt.mkdir(parents=True,exist_ok=True);self.manager.statefile.write_text('{bad')
  with self.assertRaises(Denied):self.manager.status('demo')
  self.manager.statefile.unlink()
  with self.manager.worker():
   with self.assertRaises(Denied):self.manager.run_bot(1)
   with self.assertRaises(Denied):self.manager.control('resume')

 def test_cli_and_menu(self):
  script=str(self.root/'WorkScriptature/python_git_connector.py')
  result=subprocess.run([sys.executable,script,'--root',str(self.root),'status','repo'],capture_output=True,text=True)
  self.assertEqual(result.returncode,0,result.stderr);self.assertEqual(json.loads(result.stdout)['head']['branch'],'main')
  result=subprocess.run([sys.executable,script,'--root',str(self.root),'menu'],input='B\n',capture_output=True,text=True)
  self.assertEqual(result.returncode,0,result.stderr);self.assertIn('REPOSITORY CONNECTOR',result.stdout)
  result=subprocess.run([sys.executable,str(self.root/'WorkScriptature/work_scriptature.py'),'--root',str(self.root),'git-tools'],input='B\n',capture_output=True,text=True)
  self.assertEqual(result.returncode,0,result.stderr);self.assertIn('REPOSITORY CONNECTOR',result.stdout)

if __name__=='__main__':unittest.main()
