import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'WorkScriptature'))
from hash_ula import HashULA, ten_folds, Stopped
from work_scriptature import Denied

class HashULATests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
  self.root=Path(self.temp.name)/'repo';shutil.copytree(ROOT,self.root,ignore=shutil.ignore_patterns('__pycache__','.work-scriptature'))
  (self.root/'payload.bin').write_bytes(b'abc'); self.bot=HashULA(self.root)
  self.make_script()
 def make_script(self,steps=None):
  spec={'schema':'hash-ula-script/1','name':'Test','steps':steps or [{'op':'hash','locator':'payload.bin'}]}
  (self.root/'test-script.json').write_text(json.dumps(spec))
 def test_known_sha256_and_exact_ten_rounds(self):
  r=self.bot.hash('payload.bin')
  self.assertEqual(r['sha256'],'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad')
  d=b'abc'; vals=[]
  for _ in range(10): d=hashlib.sha256(d).digest();vals.append(d.hex())
  self.assertEqual(r['folds'],vals);self.assertEqual(r['fold10'],vals[-1]);self.assertEqual(r['bytes_read'],3)
 def test_empty_file(self):
  (self.root/'empty.bin').write_bytes(b''); r=self.bot.hash('empty.bin')
  self.assertEqual(r['sha256'],hashlib.sha256(b'').hexdigest());self.assertEqual(len(r['folds']),10)
 def test_cache_hit_rehashes_content_and_revalidates(self):
  self.assertFalse(self.bot.resolve('payload.bin')['cache_hit'])
  self.assertTrue(self.bot.resolve('payload.bin')['cache_hit'])
  first=self.bot.hash('payload.bin');(self.root/'payload.bin').write_bytes(b'xyz')
  second=self.bot.hash('payload.bin');self.assertFalse(second['cache_hit']);self.assertNotEqual(first['sha256'],second['sha256'])
  (self.root/'payload.bin').unlink()
  with self.assertRaises(Denied):self.bot.resolve('payload.bin')
 def test_cache_ttl_and_capacity(self):
  self.bot.policy['cache_entries']=2
  self.bot.resolve('payload.bin');self.bot.resolve('README.md');self.bot.resolve('WorkScriptature/Triggers34.json')
  self.assertEqual(len(self.bot.load()['cache']),2)
  self.bot.resolve('payload.bin')
  import time
  with patch('hash_ula.time.time',return_value=time.time()+301):self.assertFalse(self.bot.resolve('payload.bin')['cache_hit'])
 def test_alias_binding_and_queue_snapshot(self):
  self.bot.alias('main','payload.bin');self.make_script([{'op':'hash','locator':'ula:main'}])
  job=self.bot.enqueue('test-script.json');self.bot.alias('main','README.md')
  (self.root/'test-script.json').write_text('{}')
  result=self.bot.run(1);self.assertEqual(result['jobs'][0]['state'],'completed')
  report=json.loads((self.root/result['jobs'][0]['report']).read_text())
  self.assertEqual(report['results'][0]['sha256'],hashlib.sha256(b'abc').hexdigest())
  self.assertEqual(report['script']['script_sha256'],job['script']['script_sha256'])
 def test_local_scope_rejects_remote_escape_runtime_symlink(self):
  outside=Path(self.temp.name)/'out';outside.write_text('out');(self.root/'link').symlink_to(outside)
  for value in ['../out','file:///etc/passwd','https://example.com/file','link','.work-scriptature/ula-bot.json']:
   with self.subTest(value=value):
    with self.assertRaises(Denied):self.bot.resolve(value)
 def test_size_limit(self):
  self.bot.policy['max_file_bytes']=2
  with self.assertRaisesRegex(Denied,'size limit'):self.bot.hash('payload.bin')
 def test_changed_during_hash_denied(self):
  n=[0]
  def changed():
   n[0]+=1
   if n[0]==2:(self.root/'payload.bin').write_bytes(b'changed')
   return False
  with self.assertRaisesRegex(Denied,'changed while hashing'):self.bot.hash('payload.bin',cancelled=changed)
 def test_mismatch_report_raises_accord_embargo(self):
  value=self.bot.report([self.bot.hash('payload.bin','0'*64)])
  self.assertFalse(value['passed']); self.assertTrue(self.bot.accord.status()['embargo'])
  self.assertTrue((self.root/value['report_path']).is_file())
 def test_embargo_allows_inspection_hashing(self):
  self.bot.accord.execute('raise-embargo',reason='Inspection needed')
  self.assertTrue(self.bot.hash('payload.bin')['passed'])
  self.assertTrue(self.bot.accord.status()['embargo'])
 def test_invalid_accord_and_bot_state_fail_closed(self):
  self.bot.rt.mkdir();self.bot.accord.statefile.write_text('{bad')
  with self.assertRaises(Denied):self.bot.hash('payload.bin')
  self.bot.accord.statefile.unlink();self.bot.statefile.write_text('{bad')
  with self.assertRaises(Denied):self.bot.resolve('payload.bin')
 def test_script_validation_rejects_code_and_bad_expectations(self):
  for step in [{'op':'shell','locator':'payload.bin'},{'op':'verify','locator':'payload.bin'},
               {'op':'hash','locator':'payload.bin','command':'echo bad'},
               {'op':'verify','locator':'payload.bin','expected_sha256':'bad'}]:
   self.make_script([step])
   with self.assertRaises(Denied):self.bot.script('test-script.json')
 def test_finite_ticks_and_job_states(self):
  for _ in range(3):self.bot.enqueue('test-script.json')
  r=self.bot.run(2);self.assertEqual(r['ticks_completed'],2)
  self.assertEqual([j['state'] for j in self.bot.load()['jobs']],['completed','completed','pending'])
 def test_persistent_stop_resume_and_interrupted_retry(self):
  job=self.bot.enqueue('test-script.json');self.bot.control('stop')
  self.assertEqual(self.bot.run(2)['ticks_completed'],0)
  self.bot.control('resume')
  with patch.object(self.bot,'stopped',return_value=True):r=self.bot.run(1)
  self.assertEqual(r['jobs'][0]['state'],'interrupted')
  self.bot.control('retry',job['id']);self.assertEqual(self.bot.run(1)['jobs'][0]['state'],'completed')
 def test_cancel_and_failed_expectation(self):
  j=self.bot.enqueue('test-script.json');self.bot.control('cancel',j['id'])
  self.assertEqual(self.bot.run(1)['ticks_completed'],0)
  self.make_script([{'op':'verify','locator':'payload.bin','expected_sha256':'0'*64}]);self.bot.enqueue('test-script.json')
  self.assertEqual(self.bot.run(1)['jobs'][0]['state'],'failed')
 def test_single_worker_and_recovery(self):
  with self.bot.worker():
   with self.assertRaises(Denied):self.bot.run(1)
   with self.assertRaises(Denied):self.bot.control('resume')
  j=self.bot.enqueue('test-script.json')
  with self.bot.accord.lock():
   s=self.bot.load();s['jobs'][0]['state']='running';self.bot.save(s)
  self.bot.control('recover');self.assertEqual(self.bot.load()['jobs'][0]['state'],'interrupted')
 def test_queue_limit_never_evicts_pending(self):
  self.bot.policy['max_jobs']=1;self.bot.enqueue('test-script.json')
  with self.assertRaisesRegex(Denied,'full'):self.bot.enqueue('test-script.json')
  self.bot.run(1);self.bot.enqueue('test-script.json');self.assertEqual(len(self.bot.load()['jobs']),1)
 def test_cli_and_integrated_menu_exit(self):
  for script,args,answer in [('hash_ula.py',['menu'],'B\n'),('work_scriptature.py',['ula-tools'],'B\n')]:
   result=subprocess.run([sys.executable,str(self.root/'WorkScriptature'/script),*args],input=answer,capture_output=True,text=True)
   self.assertEqual(result.returncode,0,result.stderr);self.assertIn('HASH TEN FOLDS',result.stdout)
  r=subprocess.run([sys.executable,str(self.root/'WorkScriptature/hash_ula.py'),'verify','payload.bin','0'*64],capture_output=True,text=True)
  self.assertEqual(r.returncode,2,r.stderr)

if __name__=='__main__':unittest.main()
