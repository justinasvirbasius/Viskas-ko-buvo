"""End-to-end route movement, numeric hashing and bot queue tests."""
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'WorkScriptature'))
from hash_ula import HashULA, Stopped
from kuvu_rot import KuvuRot, byte_counts
from work_scriptature import Denied

class KuvuRotTests(unittest.TestCase):
    def setUp(self):
        folder = tempfile.TemporaryDirectory()
        self.addCleanup(folder.cleanup)
        self.root = Path(folder.name) / 'repo'
        shutil.copytree(ROOT, self.root, ignore=shutil.ignore_patterns('__pycache__', '.work-scriptature'))
        (self.root / 'payload.bin').write_bytes(b'abc')
        self.bot = HashULA(self.root)
        self.rot = KuvuRot(self.bot)
        self.spec = {
            'schema': 'script-kuvu-rot/1', 'name': 'Movement test',
            'start': 'measure', 'max_movements': 4,
            'nodes': [
                {'id': 'measure', 'op': 'rescript', 'locator': 'payload.bin',
                 'move': {'pass': 'guide', 'fail': 'HALT'}},
                {'id': 'guide', 'op': 'guide', 'source': 'measure',
                 'metric': 'unique_bytes', 'compare': 'ge', 'threshold': 3,
                 'move': {'pass': 'END', 'fail': 'HALT'}}
            ]
        }
        self.write()

    def write(self):
        (self.root / 'rot.json').write_text(json.dumps(self.spec))

    def test_numpy_and_python_numerical_hash_agree(self):
        a = self.rot.numeric_hash('payload.bin', backend='numpy')
        b = self.rot.numeric_hash('payload.bin', backend='python')
        self.assertEqual(a['numeric'], b['numeric'])
        self.assertEqual(a['numeric']['bytes'], 3)
        self.assertEqual(a['numeric']['unique_bytes'], 3)
        self.assertEqual(a['numeric']['byte_sum'], 294)
        self.assertEqual(a['numeric']['entropy_milli_bits'], 1585)
        self.assertEqual(a['sha256'], hashlib.sha256(b'abc').hexdigest())
        self.assertEqual(a['numeric_backend'], 'numpy')
        self.assertEqual(b['numeric_backend'], 'python')
        self.assertEqual(len(a['numeric']['num_end12_display']), 12)

    def test_empty_file_and_unavailable_numpy_fallback(self):
        (self.root / 'payload.bin').write_bytes(b'')
        with patch('kuvu_rot.byte_counts', wraps=byte_counts) as tracked:
            result = self.rot.numeric_hash('payload.bin', backend='python')
            self.assertTrue(tracked.called)
        self.assertEqual(result['numeric']['entropy_milli_bits'], 0)
        self.assertEqual(result['numeric']['unique_bytes'], 0)
        self.assertEqual(result['numeric']['bytes'], 0)

    def test_route_report_has_stable_numerical_ending(self):
        plan = self.bot.script('rot.json')
        a = self.bot.execute_script(plan)
        b = self.bot.execute_script(plan)
        self.assertTrue(a['passed'])
        self.assertEqual(a['route']['end'], 'END')
        self.assertEqual(a['route']['numeric_ending'], b['route']['numeric_ending'])
        self.assertEqual([m['to'] for m in a['route']['movements']], ['guide', 'END'])
        self.assertEqual(a['route']['numeric_ending']['movements'], 2)
        self.assertTrue((self.root / a['report_path']).is_file())

    def test_false_guide_branch_can_end_successfully(self):
        self.spec['nodes'][1]['threshold'] = 4
        self.spec['nodes'][1]['move']['fail'] = 'END'
        self.write()
        report = self.bot.execute_script(self.bot.script('rot.json'))
        self.assertTrue(report['passed'])
        self.assertFalse(report['results'][-1]['condition'])
        self.assertEqual(report['route']['end'], 'END')
        self.assertFalse(self.bot.accord.status()['embargo'])

    def test_halt_and_loop_limit_return_failure(self):
        self.spec['nodes'][1]['threshold'] = 4
        self.write()
        report = self.bot.execute_script(self.bot.script('rot.json'))
        self.assertFalse(report['passed'])
        self.assertEqual(report['route']['end'], 'HALT')
        self.spec['nodes'][1]['threshold'] = 3
        self.spec['nodes'][1]['move']['pass'] = 'measure'
        self.write()
        report = self.bot.execute_script(self.bot.script('rot.json'))
        self.assertFalse(report['passed'])
        self.assertIn('limit', report['error'])
        self.assertEqual(len(report['route']['movements']), 4)

    def test_expected_checksum_failure_raises_existing_embargo(self):
        self.spec['nodes'][0]['expected_sha256'] = '0' * 64
        self.write()
        result = self.bot.execute_script(self.bot.script('rot.json'))
        self.assertFalse(result['passed'])
        self.assertEqual(result['route']['end'], 'HALT')
        self.assertTrue(self.bot.accord.status()['embargo'])

    def test_script_topology_and_unknown_commands_rejected(self):
        self.spec['nodes'][0]['move']['pass'] = 'missing'
        self.write()
        with self.assertRaises(Denied): self.bot.script('rot.json')
        self.spec['nodes'][0]['move']['pass'] = 'guide'
        self.spec['nodes'][0]['command'] = 'python -c print(1)'
        self.write()
        with self.assertRaises(Denied): self.bot.script('rot.json')
        self.spec['nodes'][0].pop('command')
        self.spec['max_movements'] = 1
        self.write()
        with self.assertRaises(Denied): self.bot.script('rot.json')

    def test_guide_requires_previously_measured_node(self):
        self.spec['start'] = 'guide'
        self.write()
        report = self.bot.execute_script(self.bot.script('rot.json'))
        self.assertFalse(report['passed'])
        self.assertIn('not run', report['error'])

    def test_enqueued_script_and_alias_are_pinned(self):
        self.bot.alias('moving', 'payload.bin')
        self.spec['nodes'][0]['locator'] = 'ula:moving'
        self.write()
        job = self.bot.enqueue('rot.json')
        self.bot.alias('moving', 'README.md')
        self.spec['nodes'][0]['locator'] = 'README.md'
        self.write()
        done = self.bot.run(1)
        self.assertEqual(done['jobs'][0]['state'], 'completed')
        report = json.loads((self.root / done['jobs'][0]['report']).read_text())
        self.assertEqual(report['results'][0]['sha256'], hashlib.sha256(b'abc').hexdigest())
        self.assertEqual(report['script']['script_sha256'], job['script']['script_sha256'])

    def test_stop_and_retry_route(self):
        job = self.bot.enqueue('rot.json')
        self.bot.control('stop')
        self.assertEqual(self.bot.run(1)['ticks_completed'], 0)
        self.bot.control('resume')
        with patch.object(self.bot, 'stopped', return_value=True):
            result = self.bot.run(1)
        self.assertEqual(result['jobs'][0]['state'], 'interrupted')
        self.bot.control('retry', job['id'])
        self.assertEqual(self.bot.run(1)['jobs'][0]['state'], 'completed')

    def test_cli_guide_and_menu(self):
        script = str(self.root / 'WorkScriptature/kuvu_rot.py')
        result = subprocess.run([sys.executable, script, '--root', str(self.root), 'guide', 'rot.json'],
                                capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)['routes'][0]['pass'], 'guide')
        result = subprocess.run([sys.executable, script, '--root', str(self.root), 'menu'],
                                input='B\n', capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('COMMAND SCRIPTURE', result.stdout)

if __name__ == '__main__': unittest.main()
