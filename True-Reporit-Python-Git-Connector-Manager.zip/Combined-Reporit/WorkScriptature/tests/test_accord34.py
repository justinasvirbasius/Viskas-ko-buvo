"""Behavior tests use disposable copies; never write to the shipped package."""
import importlib.util, json, os, shutil, subprocess, sys, tempfile, time, unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('accord34', ROOT/'WorkScriptature/work_scriptature.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

class AccordTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
  self.root=Path(self.tmp.name)/'repo'; shutil.copytree(ROOT,self.root,ignore=shutil.ignore_patterns('__pycache__','.work-scriptature'))
  self.a=m.Accord(self.root)
  for name,body in [('contract.txt','Contract: local evidence-bound release.'),('evidence.txt','Independent test report: pass.'),('artifact.txt','test candidate')]:
   (self.root/name).write_text(body)
  self.refresh()
 def refresh(self):
  (self.root/'ZA/ZA-SHA256.txt').write_text(''.join(m.sha(self.root/r)+'  '+r+'\n' for r in sorted(self.a.inventory())))
 def call(self,cmd,**kw): return self.a.execute(cmd,**kw)
 def proposal(self):
  self.call('propose',id='TECH-1',title='Candidate',reason='Test lifecycle')
  self.call('bind-contract',id='TECH-1',target='contract.txt',scope=['artifact.txt'])
  self.call('add-evidence',id='TECH-1',target='evidence.txt',outcome='pass',actor='tester',reason='Behavior tested')
 def decree(self):
  self.proposal(); self.call('validate',id='TECH-1'); self.call('decree',id='TECH-1',actor='operator',reason='Reviewed')
 def embargo(self): return self.call('raise-embargo',reason='Correction required')['cause']
 def resolve(self,c): self.call('resolve-cause',id=c,actor='operator',reason='Correction inspected')
 def request(self,ids=None): return self.call('request-lift',proposals=ids or [],actor='operator',reason='Ready for release')['id']
 def verified(self):
  c=self.embargo(); self.resolve(c); r=self.request(); self.call('verify-lift',id=r); return r

 def test_34_preserves_original_ids_names_actions(self):
  old=json.loads((self.root/'WorkScriptature/Triggers24.json').read_text())['triggers']; new=self.call('list')
  self.assertEqual(len(new),34)
  for a,b in zip(old,new):
   for k,v in a.items(): self.assertEqual(b[k],v)

 def test_complete_lifecycle_and_all_new_success_events(self):
  self.decree(); c=self.embargo(); self.resolve(c); r=self.request(['TECH-1'])
  self.call('verify-lift',id=r); result=self.call('lift-embargo',id=r)
  self.assertFalse(result['embargo']); self.assertEqual(result['released'],['TECH-1'])
  s=self.a.load(); self.assertEqual(s['proposals']['TECH-1']['status'],'released')
  events={x['trigger'] for x in s['receipts']}; self.assertTrue({f'ZA-{i}' for i in range(25,33)}<=events)
  self.assertIsNone(s['lift_request'])

 def test_unresolved_cause_blocks_lift(self):
  self.embargo()
  with self.assertRaisesRegex(m.Denied,'Unresolved'): self.request()
  self.assertTrue(self.call('status')['embargo'])

 def test_undecreed_candidate_stays_proposed_after_global_lift(self):
  self.call('propose',id='NEW',title='Undecreed',reason='Proposal')
  c=self.embargo(); self.resolve(c)
  with self.assertRaisesRegex(m.Denied,'decree'): self.request(['NEW'])
  r=self.request(); self.call('verify-lift',id=r); self.call('lift-embargo',id=r)
  self.assertEqual(self.call('proposals')['NEW']['status'],'proposed')

 def test_lift_needs_verification(self):
  c=self.embargo(); self.resolve(c); r=self.request()
  with self.assertRaisesRegex(m.Denied,'unverified'): self.call('lift-embargo',id=r)

 def test_source_drift_after_verify_denies_apply(self):
  r=self.verified(); p=self.root/'README.md'; p.write_text(p.read_text()+'\ndrift')
  with self.assertRaisesRegex(m.Denied,'Integrity'): self.call('lift-embargo',id=r)
  self.assertTrue(self.call('status')['embargo'])

 def test_rebaselined_manifest_after_verify_denies_apply(self):
  r=self.verified(); p=self.root/'README.md'; p.write_text(p.read_text()+'\nintentional change'); self.refresh()
  with self.assertRaisesRegex(m.Denied,'Manifest changed'): self.call('lift-embargo',id=r)

 def test_governance_mutation_invalidates_request(self):
  r=self.verified(); self.call('propose',id='NEW',title='New',reason='New proposal')
  with self.assertRaisesRegex(m.Denied,'Current lift'): self.call('lift-embargo',id=r)

 def test_expiry(self):
  r=self.verified()
  with patch.object(m.time,'time',return_value=time.time()+901):
   with self.assertRaisesRegex(m.Denied,'expired'): self.call('lift-embargo',id=r)

 def test_evidence_drift_raises_embargo_and_withdraws_decree(self):
  self.decree(); (self.root/'evidence.txt').write_text('Changed evidence')
  r=self.call('check-evidence',id='TECH-1'); self.assertFalse(r['passed']); self.assertTrue(r['embargo'])
  self.assertIsNone(self.call('proposals')['TECH-1']['decree'])
  self.assertEqual(self.a.load()['receipts'][-1]['trigger'],'ZA-34')

 def test_released_evidence_rechecked_on_global_lift(self):
  self.decree(); r=self.request(['TECH-1']); self.call('verify-lift',id=r); self.call('lift-embargo',id=r)
  c=self.embargo(); self.resolve(c); (self.root/'artifact.txt').write_text('drift')
  with self.assertRaisesRegex(m.Denied,'drift'): self.request()

 def test_revoke_blocks_and_invalidates(self):
  self.decree(); r=self.request(['TECH-1']); self.call('verify-lift',id=r)
  self.call('revoke',id='TECH-1',actor='operator',reason='Withdrawn')
  self.assertTrue(self.call('status')['embargo']); self.assertEqual(self.a.load()['receipts'][-1]['trigger'],'ZA-33')
  with self.assertRaises(m.Denied): self.call('lift-embargo',id=r)

 def test_fail_evidence_never_validates(self):
  self.call('propose',id='X',title='X',reason='X'); self.call('bind-contract',id='X',target='contract.txt',scope=['artifact.txt'])
  self.call('add-evidence',id='X',target='evidence.txt',outcome='fail',actor='tester',reason='failed test')
  with self.assertRaisesRegex(m.Denied,'Passing'): self.call('validate',id='X')

 def test_traversal_uri_and_symlink_rejection(self):
  for x in ['../repo-other/x','/etc/passwd','file:///etc/passwd','file:%2e%2e/outside','file://host/share','https://user:pass@example.com','javascript:alert(1)','C:\\outside','']:
   with self.subTest(x=x): self.assertFalse(self.call('address-check',target=x)['valid'])
  outside=Path(self.tmp.name)/'outside'; outside.write_text('outside')
  (self.root/'linked').symlink_to(outside)
  self.assertFalse(self.call('address-check',target='linked')['valid'])
  self.assertTrue(self.call('address-check',target='https://example.com/repo')['valid'])
  self.assertTrue(self.call('address-check',target='file:artifact.txt')['valid'])

 def test_invalid_state_is_fail_closed_and_not_overwritten(self):
  self.a.rt.mkdir(); self.a.statefile.write_text('{broken')
  self.assertTrue(self.call('status')['embargo']); self.assertFalse(self.call('status')['passed'])
  with self.assertRaises(m.Denied): self.call('raise-embargo',reason='test')
  self.assertEqual(self.a.statefile.read_text(),'{broken')

 def test_invalid_manifest(self):
  p=self.root/'ZA/ZA-SHA256.txt'; original=p.read_text()
  for content in ['', 'malformed\n', original+original.splitlines()[0]+'\n',original+('a'*64)+'  ../outside\n']:
   p.write_text(content)
   with self.assertRaises(m.Denied): self.call('verify-integrity')

 def test_legacy_migration_keeps_embargo_and_protects_required_triggers(self):
  self.a.rt.mkdir(); (self.a.rt/'embargo.json').write_text(json.dumps({'embargo':True,'reason':'Old cause'}))
  (self.a.rt/'trigger-enable.json').write_text(json.dumps({'ZA-01':False,'ZA-05':False}))
  s=self.call('status'); self.assertTrue(s['embargo']); self.assertFalse(s['causes']['legacy']['resolved'])
  self.assertFalse(s['enabled']['ZA-01']); self.assertNotIn('ZA-05',s['enabled'])
  self.call('resolve-cause',id='legacy',actor='operator',reason='checked'); self.assertTrue(self.a.statefile.exists())

 def test_lock_rejects_second_writer(self):
  with self.a.lock():
   with self.assertRaisesRegex(m.Denied,'busy'): self.call('raise-embargo',reason='test')

 def test_optional_triggers_disable_but_safety_triggers_cannot(self):
  for trigger in ['ZA-05','ZA-25','ZA-34']:
   with self.assertRaisesRegex(m.Denied,'cannot be disabled'): self.call('set-trigger',trigger=trigger,enabled=False)
  self.call('set-trigger',trigger='ZA-01',enabled=False)
  self.assertFalse(self.call('evaluate',trigger='ZA-01')['enabled'])
  with self.assertRaises(m.Denied): self.call('signal',trigger='ZA-01',reason='test')
  self.call('signal',trigger='ZA-05',reason='Detected checksum failure'); self.assertTrue(self.call('status')['embargo'])

 def test_read_only_does_not_create_runtime_and_mutations_do_not_break_manifest(self):
  self.call('status'); self.call('list'); self.call('verify-integrity'); self.assertFalse(self.a.rt.exists())
  self.embargo(); self.assertTrue(self.call('verify-integrity')['passed'])

 def test_quarantine_hold_uses_intake_and_hash_is_bound(self):
  p=self.root/'temp/data.bin'; p.parent.mkdir(); p.write_bytes(b'disposable'); os.utime(p,(1,1))
  q=self.call('quarantine',target='temp/data.bin'); self.assertFalse(p.exists())
  with self.assertRaisesRegex(m.Denied,'Hold'): self.call('purge',id=q['id'],confirm_purge=True)
  with patch.object(m.time,'time',return_value=time.time()+3601):
   with self.assertRaisesRegex(m.Denied,'confirmation'): self.call('purge',id=q['id'])
   self.call('purge',id=q['id'],confirm_purge=True)
  self.assertFalse((self.root/q['destination']).exists())

 def test_purge_denies_checksum_drift_and_embargo(self):
  p=self.root/'temp/data.bin'; p.parent.mkdir(); p.write_bytes(b'test'); q=self.call('quarantine',target='temp/data.bin')
  (self.root/q['destination']).write_bytes(b'drift')
  with patch.object(m.time,'time',return_value=time.time()+3601):
   with self.assertRaisesRegex(m.Denied,'checksum'): self.call('purge',id=q['id'],confirm_purge=True)
   self.embargo()
   with self.assertRaisesRegex(m.Denied,'Embargo'): self.call('purge',id=q['id'],confirm_purge=True)

 def test_source_cannot_be_quarantined(self):
  with self.assertRaises(m.Denied): self.call('quarantine',target='WorkScriptature/work_scriptature.py')

 def test_cli_exit_codes_and_console_menu(self):
  script=str(self.root/'WorkScriptature/work_scriptature.py')
  r=subprocess.run([sys.executable,script,'self-test'],capture_output=True,text=True); self.assertEqual(r.returncode,0,r.stderr)
  r=subprocess.run([sys.executable,script,'address-check','../escape'],capture_output=True,text=True); self.assertEqual(r.returncode,2)
  r=subprocess.run([sys.executable,script,'menu'],input='B\n',capture_output=True,text=True); self.assertEqual(r.returncode,0,r.stderr); self.assertIn('34 TRIGGERS',r.stdout)

if __name__=='__main__': unittest.main()
