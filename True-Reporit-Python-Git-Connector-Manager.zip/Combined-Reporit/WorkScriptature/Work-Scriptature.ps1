#requires -Version 5.1
[CmdletBinding()]
param(
 [ValidateSet('Status','List','Evaluate','RaiseEmbargo','ClearEmbargo','Quarantine','Purge','AddressCheck','SelfTest','Menu','VerifyIntegrity','Proposals','Receipts','Propose','BindContract','AddEvidence','Validate','Decree','Revoke','CheckEvidence','ResolveCause','RequestLift','VerifyLift','LiftEmbargo','SetTrigger','Signal','UlaTools','PythonGit')][string]$Action='Status',
 [string]$Target, [string]$Id, [string]$Title, [string]$Reason, [string]$Actor,
 [string]$Trigger, [string[]]$Scope, [string[]]$Proposal, [ValidateSet('pass','fail')][string]$Outcome='pass',
 [ValidateSet('on','off')][string]$Setting='on', [switch]$ConfirmPurge
)
$ErrorActionPreference='Stop'
$entry=Join-Path $PSScriptRoot 'work_scriptature.py'
$python=$null
foreach($name in @('python','python3','py')) {
 $candidate=Get-Command $name -ErrorAction SilentlyContinue
 if($candidate){$python=$candidate.Source;break}
}
if(-not $python){throw 'Python 3.10 or later is required.'}
$map=@{Status='status';List='list';Evaluate='evaluate';RaiseEmbargo='raise-embargo';Quarantine='quarantine';Purge='purge';AddressCheck='address-check';SelfTest='self-test';Menu='menu';VerifyIntegrity='verify-integrity';Proposals='proposals';Receipts='receipts';Propose='propose';BindContract='bind-contract';AddEvidence='add-evidence';Validate='validate';Decree='decree';Revoke='revoke';CheckEvidence='check-evidence';ResolveCause='resolve-cause';RequestLift='request-lift';VerifyLift='verify-lift';LiftEmbargo='lift-embargo';SetTrigger='set-trigger';Signal='signal';UlaTools='ula-tools';PythonGit='git-tools'}
if($Action -eq 'ClearEmbargo') {
 throw 'Direct clear is retired. Resolve causes, RequestLift, VerifyLift, then LiftEmbargo with the request ID. Use -Action Menu for guided controls.'
}
$cli=@($entry,$map[$Action])
switch($Action){
 'Evaluate'{if($Trigger){$cli+=@('--trigger',$Trigger)}elseif($Target){$cli+=$Target}}
 'RaiseEmbargo'{if(-not $Reason){$Reason=$Target};$cli+=@('--reason',$Reason)}
 'AddressCheck'{$cli+=$Target}
 'Quarantine'{$cli+=$Target}
 'Propose'{$cli+=@($Id,'--title',$Title,'--reason',$Reason)}
 'BindContract'{$cli+=@($Id,$Target);foreach($s in $Scope){$cli+=@('--scope',$s)}}
 'AddEvidence'{$cli+=@($Id,$Target,'--outcome',$Outcome,'--actor',$Actor,'--reason',$Reason)}
 'RequestLift'{foreach($p in $Proposal){$cli+=@('--proposal',$p)};$cli+=@('--actor',$Actor,'--reason',$Reason)}
 'SetTrigger'{$cli+=@($Trigger,$Setting)}
 'Signal'{$cli+=@($Trigger,'--reason',$Reason)}
 'Purge'{if(-not $Id){throw 'Purge requires -Id from the quarantine receipt.'};$cli+=$Id;if($ConfirmPurge){$cli+='--confirm-purge'}}
 {$_ -in @('Decree','Revoke','ResolveCause')}{$cli+=@($Id,'--actor',$Actor,'--reason',$Reason)}
 {$_ -in @('Validate','CheckEvidence','VerifyLift','LiftEmbargo')}{$cli+=$Id}
}
if($Action -in @('Menu','UlaTools','PythonGit')) {& $python @cli;if($LASTEXITCODE -ne 0){throw "Manager exit code $LASTEXITCODE"};return}
$output=& $python @cli
if($LASTEXITCODE -ne 0){throw "Work Scriptature denied the operation (exit $LASTEXITCODE)."}
$output | ConvertFrom-Json
