# Complete 34-trigger accord

ZA-01 through ZA-24 retain their original IDs, names, severity and action declarations.
Triggers are explicit events; no background watcher is installed.

| ID | Event | Class | Severity | Handler | Required |
|---|---|---|---|---|---|
| ZA-01 | workspace-open | lifecycle | info | signal | no |
| ZA-02 | workspace-close | lifecycle | info | signal | no |
| ZA-03 | pre-run | execution | info | signal | no |
| ZA-04 | post-run | execution | info | signal | no |
| ZA-05 | checksum-drift | integrity | critical | signal | yes |
| ZA-06 | core-missing | integrity | critical | signal | yes |
| ZA-07 | new-unlisted | integrity | warning | signal | no |
| ZA-08 | zero-byte | integrity | warning | signal | no |
| ZA-09 | config-invalid | configuration | critical | signal | yes |
| ZA-10 | address-invalid | address | critical | signal | yes |
| ZA-11 | address-outside-root | address | critical | signal | yes |
| ZA-12 | uri-scheme-denied | address | critical | signal | yes |
| ZA-13 | process-start | runtime | info | signal | no |
| ZA-14 | process-failure | runtime | warning | signal | no |
| ZA-15 | timeout | runtime | warning | signal | no |
| ZA-16 | retry-exhausted | runtime | critical | signal | yes |
| ZA-17 | disk-pressure | resource | warning | signal | no |
| ZA-18 | memory-pressure | resource | warning | signal | no |
| ZA-19 | stale-artifact | disposal | info | signal | no |
| ZA-20 | temp-expired | disposal | info | signal | no |
| ZA-21 | quarantine-ready | disposal | info | signal | no |
| ZA-22 | disposal-request | disposal | warning | signal | no |
| ZA-23 | embargo-raised | governance | critical | raise-embargo | yes |
| ZA-24 | embargo-cleared | governance | info | lift-embargo | yes |
| ZA-25 | invention-proposed | proposal | info | propose | yes |
| ZA-26 | contract-bound | proposal | info | bind-contract | yes |
| ZA-27 | evidence-recorded | validation | info | add-evidence | yes |
| ZA-28 | validation-passed | validation | info | validate | yes |
| ZA-29 | decree-recorded | governance | info | decree | yes |
| ZA-30 | lift-requested | governance | info | request-lift | yes |
| ZA-31 | lift-verified | governance | info | verify-lift | yes |
| ZA-32 | embargo-lifted | governance | info | lift-embargo | yes |
| ZA-33 | decree-revoked | governance | critical | revoke | yes |
| ZA-34 | evidence-drift | integrity | critical | check-evidence | yes |
