#!/usr/bin/env python3
"""Work Scriptature 34. Local governance; Python 3.10+, standard library only."""
from __future__ import annotations
import argparse, copy, hashlib, json, os, re, sys, time, uuid
from contextlib import contextmanager
from pathlib import Path, PurePosixPath
from urllib.parse import unquote, urlsplit

EXT = {'.ps1','.psm1','.psd1','.py','.c','.cpp','.h','.hpp','.rs','.toml','.json','.md','.cmd'}
EXCLUDED = {'__pycache__','build','target','manager-state','ticker-state','record-through-state','forward-pass-state','.work-scriptature'}
GENERATED = {'ZA-SHA256.txt','ZA-REPORT.json','ZA-REPORT.md'}
CRITICAL = {'WorkScriptature/python_git_connector.py','WorkScriptature/PythonGit.policy.json','WorkScriptature/kuvu_rot.py','WorkScriptature/KuvuRot.example.json','WorkScriptature/hash_ula.py','WorkScriptature/HashULA.policy.json','WorkScriptature/work_scriptature.py','WorkScriptature/Triggers34.json','WorkScriptature/Embargo.policy.json','WorkScriptature/Work-Scriptature.ps1','WorkScriptature/Triggers34-Manager.ps1'}

class Denied(ValueError): pass

def need(ok, message):
    if not ok: raise Denied(message)

def required(value, label):
    need(isinstance(value,str) and bool(value.strip()), label+' is required.')
    return value.strip()

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def read(p):
    try: return json.loads(p.read_text(encoding='utf-8-sig'))
    except (OSError, ValueError) as e: raise Denied(f'Invalid/missing JSON {p.name}: {e}') from e

class Accord:
    def __init__(self,root):
        self.root=Path(root).resolve(); self.rt=self.root/'.work-scriptature'; self.statefile=self.rt/'accord34.json'

    def path(self,target,exists=False):
        required(target,'Relative path')
        need(not any(c in target for c in ('\\',':','\0')), 'Use relative paths with forward slashes; no drive/stream paths.')
        rel=PurePosixPath(target)
        need(not rel.is_absolute() and '..' not in rel.parts, 'Path escapes repository.')
        p=self.root
        for part in rel.parts:
            p=p/part
            need(not p.is_symlink(), 'Symbolic-link paths denied.')
            need(not (hasattr(p,'is_junction') and p.is_junction()), 'Junction paths denied.')
        p=p.resolve(); need(p.is_relative_to(self.root),'Path escapes repository.')
        if exists: need(p.is_file(),'Existing regular file required.')
        return p

    def address(self,x):
        try:
            required(x,'Address')
            if re.match(r'^[A-Za-z][A-Za-z0-9+.-]*:',x):
                u=urlsplit(x)
                need(u.scheme in {'https','ssh','git','file'},'URI scheme denied.')
                need(not u.username and not u.password and '@' not in u.netloc,'Embedded credentials denied.')
                if u.scheme=='file':
                    need(not u.netloc and not u.query and not u.fragment,'File URI authority/query/fragment denied.')
                    return {'valid':True,'kind':'file','value':str(self.path(unquote(u.path)))}
                need(bool(u.hostname) and not any(c.isspace() for c in x),'Malformed URI.')
                _=u.port
                return {'valid':True,'kind':'uri','value':x,'connected':False}
            return {'valid':True,'kind':'file','value':str(self.path(x))}
        except (ValueError,OSError) as e: return {'valid':False,'reason':str(e)}

    def triggers(self):
        d=read(self.root/'WorkScriptature/Triggers34.json'); rows=d.get('triggers',[])
        need(d.get('count')==34 and len(rows)==34,'Exactly 34 triggers required.')
        need([t['id'] for t in rows]==[f'ZA-{i:02}' for i in range(1,35)],'Invalid trigger IDs/order.')
        return rows

    def inventory(self):
        return {p.relative_to(self.root).as_posix() for p in self.root.rglob('*') if p.is_file()
                and p.suffix.lower() in EXT and p.name not in GENERATED
                and not set(p.relative_to(self.root).parts).intersection(EXCLUDED)}

    def manifest(self):
        mf=self.path('ZA/ZA-SHA256.txt',True); entries={}
        for line in mf.read_text(encoding='utf-8-sig').splitlines():
            if not line.strip() or line.startswith('#'): continue
            m=re.fullmatch(r'([0-9a-fA-F]{64})  (.+)',line); need(m is not None,'Malformed manifest line.')
            h,r=m.groups(); need(r not in entries,'Duplicate manifest entry.'); self.path(r); entries[r]=h.lower()
        need(CRITICAL<=entries.keys(),'Empty manifest or missing critical 34-trigger files.')
        problems=[]
        for r,h in entries.items():
            try:
                if sha(self.path(r,True))!=h: problems.append('changed: '+r)
            except (Denied,OSError) as e: problems.append(r+': '+str(e))
        problems += ['unlisted: '+r for r in sorted(self.inventory()-entries.keys())]
        need(not problems,'Integrity failure: '+'; '.join(problems))
        self.triggers(); p=read(self.root/'WorkScriptature/Embargo.policy.json')
        need(p.get('fail_closed') is True,'fail_closed must be true.')
        need(p['disposal']['minimum_hold_seconds']>=3600,'Minimum hold must be at least one hour.')
        return {'passed':True,'checked':len(entries),'sha256':sha(mf)}

    def load(self):
        self.path('.work-scriptature/accord34.json')
        if self.statefile.exists():
            s=read(self.statefile)
            need(s.get('schema')=='work-scriptature.accord/2','Unknown state schema; original state retained.')
            need(type(s.get('embargo')) is bool and type(s.get('revision')) is int,'Malformed state.')
            for k,t in [('causes',dict),('proposals',dict),('enabled',dict),('quarantine',dict),('receipts',list)]:
                need(isinstance(s.get(k),t),'Malformed state: '+k)
            need('lift_request' in s,'Missing lift state.')
            need(all(type(v) is bool for v in s['enabled'].values()),'Invalid trigger enable state.')
            need(all(isinstance(v,dict) and type(v.get('resolved')) is bool for v in s['causes'].values()),'Invalid cause state.')
            valid_states={'proposed','contracted','evidenced','validated','decreed','released','revoked','evidence-drift'}
            need(all(isinstance(v,dict) and v.get('status') in valid_states for v in s['proposals'].values()),'Invalid proposal state.')
            need(all(s['enabled'].get(t['id'],True) for t in self.triggers() if t['required']),'Required trigger disabled; state fails closed.')
            return s
        s={'schema':'work-scriptature.accord/2','revision':0,'embargo':False,'reason':'','causes':{},
           'proposals':{},'enabled':{},'quarantine':{},'receipts':[],'lift_request':None}
        old=self.path('.work-scriptature/embargo.json')
        if old.exists():
            d=read(old); need(type(d.get('embargo')) is bool,'Malformed legacy embargo; fail closed.')
            if d['embargo']:
                s['embargo']=True; s['reason']=str(d.get('reason','legacy embargo'))
                s['causes']['legacy']={'reason':s['reason'],'resolved':False}
        old=self.path('.work-scriptature/trigger-enable.json')
        if old.exists():
            d=read(old); need(isinstance(d,dict) and all(type(v) is bool for v in d.values()),'Malformed enable state.')
            mandatory={t['id'] for t in self.triggers() if t['required']}
            s['enabled']={k:v for k,v in d.items() if k not in mandatory}
        return s

    @contextmanager
    def lock(self):
        self.path('.work-scriptature/manager.lock'); self.rt.mkdir(exist_ok=True); p=self.rt/'manager.lock'
        try: fd=os.open(p,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
        except FileExistsError as e: raise Denied('Manager busy. After a crash, confirm all managers stopped before removing manager.lock.') from e
        try:
            with os.fdopen(fd,'w') as f: f.write(str(os.getpid()))
            yield
        finally: p.unlink(missing_ok=True)

    def save(self,s):
        p=self.rt/('.state-'+uuid.uuid4().hex+'.tmp')
        try:
            with p.open('x',encoding='utf-8') as f:
                json.dump(s,f,indent=2); f.write('\n'); f.flush(); os.fsync(f.fileno())
            os.replace(p,self.statefile)
        finally: p.unlink(missing_ok=True)

    def receipt(self,s,event,action,detail):
        r={'id':uuid.uuid4().hex,'time':time.time(),'revision':s['revision']+1,
           'trigger':event,'kind':action,'detail':copy.deepcopy(detail)}
        s['receipts'].append(r); return r

    def snapshot(self,r):
        p=self.path(r,True); need('.work-scriptature' not in p.relative_to(self.root).parts,'Runtime state cannot be evidence.')
        return {'path':p.relative_to(self.root).as_posix(),'sha256':sha(p)}

    def check_proposal(self,p):
        need(p.get('contract') and p.get('scope') and p.get('evidence'),'Contract, scope and evidence required.')
        for item in [p['contract'],*p['scope'],*p['evidence']]:
            need(self.snapshot(item['path'])=={'path':item['path'],'sha256':item['sha256']},'Evidence/contract/scope drift: '+item['path'])
        need(all(e['outcome']=='pass' for e in p['evidence']),'Passing evidence attestations required; rebind to replace failed evidence.')

    def lift_checks(self,s,ids):
        result=self.manifest(); unresolved=[k for k,v in s['causes'].items() if not v['resolved']]
        need(not unresolved,'Unresolved embargo causes: '+', '.join(unresolved))
        for p in s['proposals'].values():
            if p['status']=='released': self.check_proposal(p)
        for ident in ids:
            p=s['proposals'].get(ident); need(p is not None and p['status']=='decreed',str(ident)+': current decree required.')
            self.check_proposal(p)
        return result

    def status(self):
        try:
            s=self.load()
            return {**s,'passed':True,'triggers':34,'receipts':len(s['receipts']),
                    'enabled_count':sum(s['enabled'].get(t['id'],True) for t in self.triggers())}
        except (OSError,ValueError,KeyError,TypeError) as e: return {'passed':False,'embargo':True,'reason':'fail-closed: '+str(e)}

    def execute(self,action,**k):
        if action=='ula-tools':
            from hash_ula import HashULA, menu as hash_menu
            hash_menu(HashULA(self.root)); return {'closed':True}
        if action=='git-tools':
            from python_git_connector import PythonGit, menu as git_menu
            git_menu(PythonGit(self.root)); return {'closed':True}
        if action=='status': return self.status()
        if action=='address-check': return self.address(k.get('target'))
        if action=='verify-integrity': return self.manifest()
        if action=='self-test':
            self.triggers(); need(not self.address('../escape')['valid'],'Escape accepted.')
            return {'passed':True,'triggers':34,'escape_rejected':True,'integrity':self.manifest()}
        if action in {'list','proposals','receipts','evaluate'}:
            s=self.load()
            if action=='list': return [{**t,'enabled':s['enabled'].get(t['id'],True)} for t in self.triggers()]
            if action in {'proposals','receipts'}: return s[action]
            if not k.get('trigger'):
                a=self.address(k.get('target')); return {'embargo':s['embargo'],'address':a,'allowed':not s['embargo'] and a['valid']}
            t=next((t for t in self.triggers() if t['id']==k['trigger']),None); need(t is not None,'Unknown trigger.')
            return {'trigger':t,'enabled':s['enabled'].get(t['id'],True),'embargo':s['embargo'],'mode':'dry-run-no-mutation','automatic_execution':False}
        with self.lock():
            s=self.load(); result=self.mutate(s,action,k); s['revision']+=1; self.save(s); return result

    def mutate(self,s,action,k):
        ident=k.get('id'); reason=k.get('reason',''); actor=k.get('actor','')
        if action not in {'verify-lift','lift-embargo'}: s['lift_request']=None
        if action=='raise-embargo':
            cause=uuid.uuid4().hex[:12]; s['embargo']=True; s['reason']=required(reason,'Reason')
            s['causes'][cause]={'reason':reason,'resolved':False}
            self.receipt(s,'ZA-23',action,{'cause':cause,'reason':reason}); return {'embargo':True,'cause':cause}
        if action=='resolve-cause':
            need(ident in s['causes'],'Unknown cause.'); c=s['causes'][ident]
            c.update(resolved=True,resolution=required(reason,'Correction'),actor=required(actor,'Operator'))
            self.receipt(s,'ZA-22',action,{'cause':ident,**c}); return c
        if action=='set-trigger':
            t=next((t for t in self.triggers() if t['id']==k['trigger']),None); need(t is not None,'Unknown trigger.')
            need(not t['required'] or k['enabled'],'Required integrity/governance trigger cannot be disabled.')
            s['enabled'][t['id']]=bool(k['enabled']); return self.receipt(s,'ZA-04',action,{'id':t['id'],'enabled':bool(k['enabled'])})
        if action=='signal':
            t=next((t for t in self.triggers() if t['id']==k['trigger']),None)
            need(t is not None and int(t['id'][3:])<=24,'Use dedicated workflow commands for triggers 25-34.')
            need(t['id'] not in {'ZA-23','ZA-24'},'Use raise-embargo or verified lift.')
            need(s['enabled'].get(t['id'],True),'Trigger disabled.')
            if t['embargo_on_failure']:
                cause=uuid.uuid4().hex[:12]; s['embargo']=True; s['reason']=required(reason,'Failure reason')
                s['causes'][cause]={'reason':reason,'trigger':t['id'],'resolved':False}
            return self.receipt(s,t['id'],action,{'reason':reason,'recommended_action':t['action'],'embargo':s['embargo'],'automatic_disposal':False})
        if action=='propose':
            need(re.fullmatch(r'[A-Za-z][A-Za-z0-9_.-]{0,63}',ident or '') is not None,'Invalid proposal ID.')
            need(ident not in s['proposals'],'Proposal ID already exists.')
            p={'id':ident,'title':required(k.get('title'),'Title'),'rationale':required(reason,'Rationale'),
               'origin':k.get('origin') or 'operator proposal','status':'proposed','contract':None,'scope':[],'evidence':[],'decree':None}
            s['proposals'][ident]=p; self.receipt(s,'ZA-25',action,p); return p
        if action in {'bind-contract','add-evidence','validate','decree','revoke','check-evidence'}:
            need(ident in s['proposals'],'Unknown proposal.'); p=s['proposals'][ident]
            if action=='bind-contract':
                need(p['status']!='released','Revoke a released proposal before rebinding.'); need(k.get('scope'),'Scoped files required.')
                p.update(contract=self.snapshot(k.get('target')),scope=[self.snapshot(r) for r in sorted(set(k['scope']))],evidence=[],decree=None,status='contracted'); event='ZA-26'
            elif action=='add-evidence':
                need(p['status'] in {'contracted','evidenced'},'Bind contract before evidence.')
                need(k['outcome'] in {'pass','fail'},'Outcome must be pass or fail.')
                e={**self.snapshot(k.get('target')),'outcome':k['outcome'],'actor':required(actor,'Reviewer'),'note':required(reason,'Evidence note'),'time':time.time()}
                need(not any(x['path']==e['path'] for x in p['evidence']),'Duplicate evidence; rebind to replace.')
                p['evidence'].append(e); p['status']='evidenced'; event='ZA-27'
            elif action in {'validate','decree'}:
                need(p['status']==('evidenced' if action=='validate' else 'validated'),'Invalid proposal stage.')
                self.manifest(); self.check_proposal(p)
                if action=='decree': p['decree']={'actor':required(actor,'Operator'),'reason':required(reason,'Decree reason'),'time':time.time()}
                p['status']='validated' if action=='validate' else 'decreed'; event='ZA-28' if action=='validate' else 'ZA-29'
            elif action=='revoke':
                required(reason,'Revocation reason'); required(actor,'Operator'); p.update(status='revoked',decree=None)
                s['embargo']=True; s['reason']=reason
                s['causes']['revoke-'+uuid.uuid4().hex[:12]]={'reason':reason,'resolved':False,'proposal':ident}; event='ZA-33'
            else:
                try: self.check_proposal(p)
                except (Denied,OSError) as e:
                    p.update(status='evidence-drift',decree=None); s['embargo']=True; s['reason']=str(e)
                    s['causes']['drift-'+uuid.uuid4().hex[:12]]={'reason':str(e),'resolved':False,'proposal':ident}
                    self.receipt(s,'ZA-34',action,{'id':ident,'error':str(e)}); return {'passed':False,'embargo':True,'proposal':p}
                return self.receipt(s,'ZA-04',action,{'id':ident,'passed':True})
            self.receipt(s,event,action,{'id':ident,'status':p['status'],'actor':actor,'reason':reason}); return p
        if action=='request-lift':
            ids=sorted(set(k.get('proposals') or [])); need(s['embargo'] or ids,'No embargo or selected proposal to lift.')
            self.lift_checks(s,ids)
            ttl=read(self.root/'WorkScriptature/Embargo.policy.json')['lift']['request_ttl_seconds']
            need(type(ttl) is int and 1<=ttl<=900,'Lift TTL must be 1..900 seconds.')
            r={'id':uuid.uuid4().hex,'proposals':ids,'created':time.time(),'expires':time.time()+ttl,
               'actor':required(actor,'Operator'),'reason':required(reason,'Lift reason'),'requested_revision':s['revision']+1,'verified_revision':None}
            s['lift_request']=r; self.receipt(s,'ZA-30',action,r); return r
        if action in {'verify-lift','lift-embargo'}:
            r=s['lift_request']; need(r is not None and r['id']==ident,'Current lift request ID required.')
            need(time.time()<=r['expires'],'Lift request expired; create another.')
            rev=r['requested_revision'] if action=='verify-lift' else r['verified_revision']
            need(rev is not None and s['revision']==rev,'Request unverified or stale.')
            checked=self.lift_checks(s,r['proposals'])
            if action=='verify-lift':
                r['verified_revision']=s['revision']+1; r['manifest_sha256']=checked['sha256']; self.receipt(s,'ZA-31',action,r); return r
            need(checked['sha256']==r['manifest_sha256'],'Manifest changed after verification.')
            for pid in r['proposals']: s['proposals'][pid]['status']='released'
            s['embargo']=False; s['reason']=r['reason']; self.receipt(s,'ZA-32',action,r); self.receipt(s,'ZA-24','embargo-cleared',{'request':ident})
            s['lift_request']=None; return {'embargo':False,'released':r['proposals'],'request':ident}
        if action=='quarantine':
            need(not s['embargo'],'Embargo blocks quarantine moves.'); p=self.path(k.get('target'),True); rel=p.relative_to(self.root).as_posix()
            need(not rel.startswith('.work-scriptature/'),'Runtime files protected.')
            policy=read(self.root/'WorkScriptature/Embargo.policy.json')
            need(not any(rel==x or rel.startswith(x+'/') for x in policy['protected_roots'] if x!='.'),'Protected source directory.')
            need(rel not in self.inventory() and '/' in rel,'Source and root files protected; disposable data only.')
            h=sha(p); key=uuid.uuid4().hex; dest=self.path('.work-scriptature/quarantine/'+key+'-'+p.name); dest.parent.mkdir(exist_ok=True)
            os.replace(p,dest)
            item={'source':rel,'destination':dest.relative_to(self.root).as_posix(),'sha256':h,'intake_time':time.time()}
            s['quarantine'][key]=item; self.receipt(s,'ZA-21',action,item); return {'id':key,**item}
        if action=='purge':
            need(not s['embargo'],'Embargo blocks purge.'); need(k.get('confirm_purge') is True,'Explicit purge confirmation required.')
            item=s['quarantine'].get(ident); need(item is not None,'Recorded quarantine ID required; untracked files cannot be purged.')
            policy=read(self.root/'WorkScriptature/Embargo.policy.json'); hold=max(3600,policy['disposal']['minimum_hold_seconds'])
            need(time.time()-item['intake_time']>=hold,f'Hold required: {hold} seconds after intake.')
            p=self.path(item['destination'],True); need(p.is_relative_to(self.rt/'quarantine'),'Target outside quarantine.')
            need(sha(p)==item['sha256'],'Quarantine checksum drift; purge denied.'); p.unlink(); del s['quarantine'][ident]
            return self.receipt(s,'ZA-22',action,item)
        raise Denied('Unknown action: '+action)

# One command definition also drives the console menu, avoiding separate policy paths.
COMMANDS = {
 'git-tools':[],
 'ula-tools':[],
 'status':[], 'list':[], 'evaluate':[('trigger','Trigger ID')], 'address-check':[('target','Relative path or URI')],
 'raise-embargo':[('reason','Reason')], 'resolve-cause':[('id','Cause ID'),('actor','Operator'),('reason','Correction')],
 'proposals':[], 'propose':[('id','New proposal ID'),('title','Title'),('reason','Rationale')],
 'bind-contract':[('id','Proposal ID'),('target','Contract path'),('scope','Scoped file paths, separated by |')],
 'add-evidence':[('id','Proposal ID'),('target','Evidence path'),('outcome','pass or fail'),('actor','Reviewer'),('reason','Evidence note')],
 'validate':[('id','Proposal ID')], 'decree':[('id','Proposal ID'),('actor','Operator'),('reason','Decree reason')],
 'request-lift':[('proposals','Proposal IDs separated by |, blank for global lift only'),('actor','Operator'),('reason','Lift reason')],
 'verify-lift':[('id','Request ID')], 'lift-embargo':[('id','Request ID')],
 'revoke':[('id','Proposal ID'),('actor','Operator'),('reason','Revocation reason')], 'check-evidence':[('id','Proposal ID')],
 'receipts':[], 'self-test':[], 'quarantine':[('target','Disposable relative file path')],
 'purge':[('id','Quarantine ID'),('confirm_purge','Type PURGE')],
 'set-trigger':[('trigger','Trigger ID'),('enabled','on or off')], 'signal':[('trigger','Trigger ID'),('reason','Reason')], 'verify-integrity':[]}

def menu(a):
    choices=list(COMMANDS)
    while True:
        print('\n34 TRIGGERS ACCORD — EMBARGO LIFT / UNDECREED TECHNOLOGY')
        s=a.status(); print('Embargo:',s['embargo'],'|',s.get('reason',''))
        for i,cmd in enumerate(choices,1): print(f'{i:2}  {cmd.replace("-"," ")}')
        print(' B  Back / exit')
        try:
            choice=input('Select: ').strip().upper()
            if choice in {'B','Q'}: return
            if not choice.isdigit() or not 1<=int(choice)<=len(choices): continue
            cmd=choices[int(choice)-1]; k={key:input(label+': ').strip() for key,label in COMMANDS[cmd]}
            for key in ['scope','proposals']:
                if key in k: k[key]=[x.strip() for x in k[key].split('|') if x.strip()]
            if 'enabled' in k:
                need(k['enabled'] in {'on','off'},'Enter on or off.'); k['enabled']=k['enabled']=='on'
            if 'confirm_purge' in k: k['confirm_purge']=k['confirm_purge']=='PURGE'
            print(json.dumps(a.execute(cmd,**k),indent=2)); input('Enter to continue: ')
        except (EOFError,KeyboardInterrupt): print('\nStopped.'); return
        except (ValueError,OSError,KeyError,TypeError) as e: print('DENIED:',e)

def parser():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]); sub=p.add_subparsers(dest='action',required=True)
    for name in ['status','list','proposals','receipts','self-test','verify-integrity','menu','ula-tools','git-tools']: sub.add_parser(name)
    for name in ['address-check','quarantine']: sub.add_parser(name).add_argument('target')
    q=sub.add_parser('evaluate'); q.add_argument('target',nargs='?'); q.add_argument('--trigger')
    q=sub.add_parser('set-trigger'); q.add_argument('trigger'); q.add_argument('setting',choices=['on','off'])
    q=sub.add_parser('signal'); q.add_argument('trigger'); q.add_argument('--reason',required=True)
    q=sub.add_parser('raise-embargo'); q.add_argument('--reason',required=True)
    for name in ['resolve-cause','decree','revoke']:
        q=sub.add_parser(name); q.add_argument('id'); q.add_argument('--actor',required=True); q.add_argument('--reason',required=True)
    q=sub.add_parser('propose'); q.add_argument('id'); q.add_argument('--title',required=True); q.add_argument('--reason',required=True); q.add_argument('--origin')
    q=sub.add_parser('bind-contract'); q.add_argument('id'); q.add_argument('target'); q.add_argument('--scope',action='append',required=True)
    q=sub.add_parser('add-evidence'); q.add_argument('id'); q.add_argument('target'); q.add_argument('--outcome',choices=['pass','fail'],required=True); q.add_argument('--actor',required=True); q.add_argument('--reason',required=True)
    for name in ['validate','check-evidence','verify-lift','lift-embargo']: sub.add_parser(name).add_argument('id')
    q=sub.add_parser('request-lift'); q.add_argument('--proposal',dest='proposals',action='append'); q.add_argument('--actor',required=True); q.add_argument('--reason',required=True)
    q=sub.add_parser('purge'); q.add_argument('id'); q.add_argument('--confirm-purge',action='store_true')
    return p

def main():
    k=vars(parser().parse_args()); a=Accord(k.pop('root')); action=k.pop('action')
    if 'setting' in k: k['enabled']=k.pop('setting')=='on'
    try:
        if action=='menu': menu(a); return 0
        result=a.execute(action,**k); print(json.dumps(result,indent=2))
        return 2 if isinstance(result,dict) and (result.get('passed') is False or result.get('valid') is False) else 0
    except (ValueError,OSError,KeyError,TypeError) as e:
        print(json.dumps({'passed':False,'error':str(e)}),file=sys.stderr); return 2

if __name__=='__main__': sys.exit(main())
