@echo off
call "%~dp0Start-Triggers34-Manager.cmd" %*
exit /b %errorlevel%
