# Combined Reporit

This repository combines:

- `server-script-manager/`: the Python manager with disk routines, cleanup gates, native connector support, and forecasts.
- `reporitor-ticker/`: the PowerShell Reporitor ticker package.
- `integration/ssm.reporitor.example.toml`: a combined configuration example.
- `COMBINED-REPORIT.md`: the report explaining the combined operating model.

The Python copy has been extended with the `reporitor_ticker` routine so SSM can forecast and run the ticker when PowerShell is available.


## Scriptature menu

The combined package now has one top-level script menu:

```powershell
.\Scriptature-Menu.ps1 -Repository owner/name
```

On Windows Command Prompt you can use `Start-Scriptature.cmd`. The menu surfaces
True Reporit, the ticker, Reporitor read/report operations, Gits, ShellNotion,
Forward Pass, Record-Through, the Python manager, native connector builds, tests,
and a full scripture/source index. See `scriptature/README.md`.

## ZA + checksum completeness

The Scriptature menu now includes **10 — ZA analysis + checksum**. ZA inventories the governed scripture, checks declared core-path completeness, zero-byte files, JSON structure, top-level menu linkage, and SHA-256 manifest consistency. Its checksum manifest detects missing, modified, and newly-unlisted source/config/documentation files. See `ZA/README.md`.


## Work Scriptature: 34 Triggers / Embargo Lift

Run `Start-34-Triggers-Manager.cmd` on Windows, or:

```console
python WorkScriptature/work_scriptature.py menu
```

Requires Python 3.10+. Includes the original 24 events plus ten proposal,
contract, evidence, decree and verified-lift events. Undecreed proposals remain
inactive. Source checks run at every lift gate, and a changed revision or
manifest invalidates the request. Existing 24-trigger launchers open the new
manager. See `WorkScriptature/README.md`, `WorkScriptature/TRIGGERS-34.md`, and
`WorkScriptature/VALIDATION.md` for the workflow and tested scope.

## Cache ULA and Hash Bot Manager

Run `python WorkScriptature/hash_ula.py menu` from the package root, or use
`Start-ULA-Bot-Manager.cmd` on Windows. Includes cached local aliases, ten-fold
SHA-256, JSON hash scripts, and a finite bot queue with stop/resume and recovery.
See `WorkScriptature/HASH-ULA.md` for commands, hashing semantics and limits.

## Script Kuvu Rot

`python WorkScriptature/kuvu_rot.py menu` opens the Python command scripture
for route movements, numeric rescripts, and the Hash ULA locator ending.
Windows: `Start-Kuvu-Rot-Manager.cmd`. See `WorkScriptature/KUVU-ROT.md`.

## Python Git repository connector

Run `python WorkScriptature/python_git_connector.py menu`, or use
`Start-Python-Git-Manager.cmd` on Windows. It provides local repository views,
read-only command scriptures, a finite report bot, and explicit preview/apply
local operations under the existing Gits policy.
