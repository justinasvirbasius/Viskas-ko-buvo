@echo off
call "%~dp0WorkScriptature\Start-Triggers24-Manager.cmd" %*
