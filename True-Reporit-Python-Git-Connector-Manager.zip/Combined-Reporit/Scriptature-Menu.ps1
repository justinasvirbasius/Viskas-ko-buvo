#requires -Version 5.1
<#
.SYNOPSIS
    True Reporit Scriptature menu.
.DESCRIPTION
    One operator-facing console menu for the scripts bundled in the True Reporit
    Manager Accord. The menu exposes the manager, ticker, repository reporter,
    local Git accord, ShellNotion, Forward Pass, Record-Through, Python manager,
    native connectors, and integrity checks without enabling GitHub write actions.

    The menu is intentionally foreground and finite. It does not install a
    service, scheduled task, autorun entry, or hidden background loop.
.EXAMPLE
    .\Scriptature-Menu.ps1 -Repository owner/repository
.EXAMPLE
    .\Scriptature-Menu.ps1 -Repository owner/repository -RepositoryPath C:\src\repo
#>

[CmdletBinding()]
param(
    [string]$Repository = '',
    [string]$RepositoryPath = (Get-Location).Path,
    [string]$StateRoot = (Join-Path $PSScriptRoot 'manager-state'),
    [string]$TickerRoot = (Join-Path $PSScriptRoot 'ticker-state'),
    [string]$PythonConfig = (Join-Path $PSScriptRoot 'integration\ssm.reporitor.example.toml'),
    [switch]$NoClear
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$script:Root = [IO.Path]::GetFullPath($PSScriptRoot)
$script:TrueReporit = Join-Path $script:Root 'Start-TrueReporit.ps1'
$script:TickerManifest = Join-Path $script:Root 'reporitor-ticker\ReporitorTicker.psd1'
$script:TickerStart = Join-Path $script:Root 'reporitor-ticker\Start-ReporitorTicker.ps1'
$script:TickerTest = Join-Path $script:Root 'reporitor-ticker\Test-ReporitorTicker.ps1'
$script:ReporitorManifest = Join-Path $script:Root 'Reporitor\Reporitor.psd1'
$script:ReporitorStart = Join-Path $script:Root 'Reporitor\Start-Reporitor.ps1'
$script:ReporitorTest = Join-Path $script:Root 'Reporitor\Test-Reporitor.ps1'
$script:GitsManifest = Join-Path $script:Root 'Gits\Gits.psd1'
$script:GitsTest = Join-Path $script:Root 'Gits\Test-Gits.ps1'
$script:ShellManifest = Join-Path $script:Root 'ShellNotion\ShellNotion.psd1'
$script:ShellStart = Join-Path $script:Root 'ShellNotion\Start-ShellNotion.ps1'
$script:ShellTest = Join-Path $script:Root 'ShellNotion\Test-ShellNotion.ps1'
$script:ForwardPass = Join-Path $script:Root 'ShellNotion\ForwardPass\PowerShell-Forward-Pass.ps1'
$script:RecordCore = Join-Path $script:Root 'ShellNotion\RecordThrough\PowerShell-Record-Through.ps1'
$script:RecordVerify = Join-Path $script:Root 'ShellNotion\RecordThrough\PowerShell-Record-Through-Verify.ps1'
$script:RecordRoller = Join-Path $script:Root 'ShellNotion\RecordThrough\PowerShell-Record-Through-Roller.ps1'
$script:RecordUI = Join-Path $script:Root 'ShellNotion\RecordThrough\PowerShell-Record-Through-UI.ps1'
$script:PythonRoot = Join-Path $script:Root 'server-script-manager'
$script:ZAManifest = Join-Path $script:Root 'ZA\ZA.psd1'
$script:ZAEntry = Join-Path $script:Root 'ZA\Invoke-ZAAnalysis.ps1'
$script:ZATest = Join-Path $script:Root 'ZA\Test-ZA.ps1'
$script:PythonSource = Join-Path $script:PythonRoot 'src'
$script:RecordRoot = if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'RecordThrough' } else { Join-Path $script:Root 'record-through-state' }
$script:ForwardRoot = if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'ForwardPass' } else { Join-Path $script:Root 'forward-pass-state' }

function Write-Rule {
    param([string]$Title = '')
    Write-Host ''
    Write-Host ('=' * 78)
    if ($Title) { Write-Host ('  ' + $Title) }
    Write-Host ('=' * 78)
}

function Clear-ScriptatureHost {
    if (-not $NoClear) { Clear-Host }
}

function Wait-Scriptature {
    [void](Read-Host 'Press Enter to return')
}

function Write-Result {
    param([Parameter(ValueFromPipeline = $true)]$Value)
    process {
        if ($null -eq $Value) { return }
        if ($Value -is [string]) { Write-Host $Value; return }
        $Value | Format-List * | Out-Host
    }
}

function Invoke-Guarded {
    param(
        [Parameter(Mandatory = $true)][string]$Name,
        [Parameter(Mandatory = $true)][scriptblock]$Body,
        [switch]$NoPause
    )
    Write-Rule $Name
    try {
        $result = & $Body
        if ($null -ne $result) { $result | Write-Result }
        Write-Host ''
        Write-Host '[complete]'
    } catch {
        Write-Host ''
        Write-Host ('[error] ' + $_.Exception.Message)
    }
    if (-not $NoPause) { Wait-Scriptature }
}

function Require-Repository {
    if ($Repository -and $Repository -match '^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$') { return $Repository }
    $value = Read-Host 'Repository (owner/name)'
    if ($value -notmatch '^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$') { throw 'Repository must use owner/name form.' }
    $script:Repository = $value
    return $value
}

function Read-Int {
    param([string]$Prompt, [int]$Default, [int]$Minimum, [int]$Maximum)
    $raw = Read-Host ("$Prompt [$Default]")
    if ([string]::IsNullOrWhiteSpace($raw)) { return $Default }
    $value = 0
    if (-not [int]::TryParse($raw, [ref]$value)) { throw "$Prompt must be an integer." }
    if ($value -lt $Minimum -or $value -gt $Maximum) { throw "$Prompt must be between $Minimum and $Maximum." }
    return $value
}

function Read-YesNo {
    param([string]$Prompt, [bool]$Default = $false)
    $suffix = if ($Default) { '[Y/n]' } else { '[y/N]' }
    $raw = (Read-Host "$Prompt $suffix").Trim().ToLowerInvariant()
    if (-not $raw) { return $Default }
    return @('y','yes') -contains $raw
}

function Import-BundledModule {
    param([Parameter(Mandatory = $true)][string]$Manifest)
    if (-not (Test-Path -LiteralPath $Manifest)) { throw "Module is missing: $Manifest" }
    Import-Module $Manifest -Force -ErrorAction Stop
}

function Show-MainMenu {
    Clear-ScriptatureHost
    Write-Rule 'TRUE REPORIT — SCRIPTATURE MENU'
    Write-Host ('Root:       ' + $script:Root)
    Write-Host ('Repository: ' + $(if ($Repository) { $Repository } else { '<not set>' }))
    Write-Host ('Local repo: ' + $RepositoryPath)
    Write-Host ''
    Write-Host '  1  True Reporit manager'
    Write-Host '  2  Reporitor ticker'
    Write-Host '  3  Reporitor GitHub reader/report bot'
    Write-Host '  4  Gits local repository accord'
    Write-Host '  5  ShellNotion / Forward Pass / Record-Through'
    Write-Host '  6  Python server-script manager'
    Write-Host '  7  Native connector source/builds'
    Write-Host '  8  Tests and integrity'
    Write-Host '  9  Scripture index — show all source/config files'
    Write-Host ' 10  ZA analysis + checksum completeness'
    Write-Host '  R  Set/change repository context'
    Write-Host '  Q  Quit'
}

function Show-TrueReporitMenu {
    while ($true) {
        Clear-ScriptatureHost
        Write-Rule '1 — TRUE REPORIT MANAGER'
        Write-Host '  1  Forecast'
        Write-Host '  2  Run one finite round (local ticker only)'
        Write-Host '  3  Run bounded rounds (local ticker only)'
        Write-Host '  4  Run bounded rounds + GitHub remote reads'
        Write-Host '  5  Status'
        Write-Host '  6  Verify linked manager ledger'
        Write-Host '  7  Request stop'
        Write-Host '  8  Show entry script path'
        Write-Host '  B  Back'
        $choice = (Read-Host 'Select').Trim().ToUpperInvariant()
        switch ($choice) {
            '1' { Invoke-Guarded 'True Reporit forecast' { & $script:TrueReporit -Action Forecast -Repository $Repository -StateRoot $StateRoot } }
            '2' { Invoke-Guarded 'True Reporit — one round' { $repo = Require-Repository; & $script:TrueReporit -Action Run -Repository $repo -StateRoot $StateRoot -Rounds 1 -IntervalSeconds 0 } }
            '3' { Invoke-Guarded 'True Reporit — bounded rounds' {
                    $repo = Require-Repository
                    $rounds = Read-Int 'Rounds' 3 1 100
                    $interval = Read-Int 'Interval seconds' 0 0 86400
                    & $script:TrueReporit -Action Run -Repository $repo -StateRoot $StateRoot -Rounds $rounds -IntervalSeconds $interval
                } }
            '4' { Invoke-Guarded 'True Reporit — bounded rounds + remote reads' {
                    $repo = Require-Repository
                    $rounds = Read-Int 'Rounds' 1 1 100
                    $interval = Read-Int 'Interval seconds' 0 0 86400
                    & $script:TrueReporit -Action Run -Repository $repo -StateRoot $StateRoot -Rounds $rounds -IntervalSeconds $interval -EnableRemoteReads
                } }
            '5' { Invoke-Guarded 'True Reporit status' { & $script:TrueReporit -Action Status -StateRoot $StateRoot } }
            '6' { Invoke-Guarded 'True Reporit ledger verification' { & $script:TrueReporit -Action Verify -StateRoot $StateRoot } }
            '7' { Invoke-Guarded 'True Reporit stop request' { & $script:TrueReporit -Action Stop -StateRoot $StateRoot } }
            '8' { Invoke-Guarded 'True Reporit entry script' { Get-Item -LiteralPath $script:TrueReporit | Select-Object FullName,Length,LastWriteTime } }
            'B' { return }
        }
    }
}

function Show-TickerMenu {
    while ($true) {
        Clear-ScriptatureHost
        Write-Rule '2 — REPORITOR TICKER'
        Write-Host ('Ticker state: ' + $TickerRoot)
        Write-Host '  1  Initialize workspace'
        Write-Host '  2  Test connector'
        Write-Host '  3  Run one tick'
        Write-Host '  4  Start finite ticker'
        Write-Host '  5  Status'
        Write-Host '  6  Verify ticker state'
        Write-Host '  7  Stop — Immediate'
        Write-Host '  8  Stop — AfterTick'
        Write-Host '  9  Stop — Drain'
        Write-Host ' 10  New standard ticket'
        Write-Host ' 11  New subvariance ticket'
        Write-Host ' 12  Get ticket by id'
        Write-Host ' 13  Run bundled ticker self-test'
        Write-Host '  B  Back'
        $choice = (Read-Host 'Select').Trim().ToUpperInvariant()
        switch ($choice) {
            '1' { Invoke-Guarded 'Initialize ticker workspace' { Import-BundledModule $script:TickerManifest; $repo = Require-Repository; Initialize-RTWorkspace -Root $TickerRoot -Repository $repo } }
            '2' { Invoke-Guarded 'Ticker connector test' { Import-BundledModule $script:TickerManifest; Test-RTConnector -Root $TickerRoot } }
            '3' { Invoke-Guarded 'Ticker single tick' { Import-BundledModule $script:TickerManifest; $repo = Require-Repository; Initialize-RTWorkspace -Root $TickerRoot -Repository $repo | Out-Null; Invoke-RTTick -Root $TickerRoot -Repository $repo } }
            '4' { Invoke-Guarded 'Finite ticker run' {
                    $repo = Require-Repository
                    $ticks = Read-Int 'Maximum ticks' 12 1 2147483647
                    $interval = Read-Int 'Interval seconds' 5 1 86400
                    & $script:TickerStart -Root $TickerRoot -Repository $repo -MaxTicks $ticks -IntervalSeconds $interval
                } }
            '5' { Invoke-Guarded 'Ticker status' { Import-BundledModule $script:TickerManifest; Get-RTStatus -Root $TickerRoot } }
            '6' { Invoke-Guarded 'Ticker state verification' { Import-BundledModule $script:TickerManifest; Test-RTState -Root $TickerRoot } }
            '7' { Invoke-Guarded 'Ticker stop — Immediate' { Import-BundledModule $script:TickerManifest; Stop-ReporitorTicker -Root $TickerRoot -Mode Immediate } }
            '8' { Invoke-Guarded 'Ticker stop — AfterTick' { Import-BundledModule $script:TickerManifest; Stop-ReporitorTicker -Root $TickerRoot -Mode AfterTick } }
            '9' { Invoke-Guarded 'Ticker stop — Drain' { Import-BundledModule $script:TickerManifest; Stop-ReporitorTicker -Root $TickerRoot -Mode Drain } }
            '10' { Invoke-Guarded 'New standard ticket' {
                    Import-BundledModule $script:TickerManifest
                    $title = Read-Host 'Ticket title'
                    New-RTTicket -Root $TickerRoot -Title $title
                } }
            '11' { Invoke-Guarded 'New subvariance ticket' {
                    Import-BundledModule $script:TickerManifest
                    $title = Read-Host 'Ticket title'
                    $parent = Read-Host 'Parent ticket id'
                    $limitRaw = Read-Host 'Variance limit [0.15]'
                    $limit = if ([string]::IsNullOrWhiteSpace($limitRaw)) { 0.15 } else { [double]::Parse($limitRaw, [Globalization.CultureInfo]::InvariantCulture) }
                    New-RTSubvarianceTicket -Root $TickerRoot -Title $title -ParentId $parent -VarianceLimit $limit
                } }
            '12' { Invoke-Guarded 'Get ticker ticket' { Import-BundledModule $script:TickerManifest; $id = Read-Host 'Ticket id'; Get-RTTicket -Root $TickerRoot -Id $id } }
            '13' { Invoke-Guarded 'Ticker self-test' { & $script:TickerTest } }
            'B' { return }
        }
    }
}

function Show-ReporitorMenu {
    while ($true) {
        Clear-ScriptatureHost
        Write-Rule '3 — REPORITOR GITHUB READER / REPORT BOT'
        Write-Host 'Remote write actions are deliberately not exposed by this menu.'
        Write-Host '  1  Prerequisite check'
        Write-Host '  2  Repository summary'
        Write-Host '  3  Read issues'
        Write-Host '  4  Read pull requests'
        Write-Host '  5  Read workflow runs'
        Write-Host '  6  Run one finite report round (remote reads, local report writes)'
        Write-Host '  7  Verify Reporitor accord ledger'
        Write-Host '  8  Start-Reporitor overview'
        Write-Host '  9  Run bundled Reporitor self-test'
        Write-Host '  B  Back'
        $choice = (Read-Host 'Select').Trim().ToUpperInvariant()
        switch ($choice) {
            '1' { Invoke-Guarded 'Reporitor prerequisites' { Import-BundledModule $script:ReporitorManifest; Test-RPPrerequisite } }
            '2' { Invoke-Guarded 'Reporitor repository summary' { Import-BundledModule $script:ReporitorManifest; $repo = Require-Repository; Get-RPRepository -Repository $repo } }
            '3' { Invoke-Guarded 'Reporitor issues' { Import-BundledModule $script:ReporitorManifest; $repo = Require-Repository; Invoke-RPRead -Repository $repo -Operation Issues } }
            '4' { Invoke-Guarded 'Reporitor pull requests' { Import-BundledModule $script:ReporitorManifest; $repo = Require-Repository; Invoke-RPRead -Repository $repo -Operation PullRequests } }
            '5' { Invoke-Guarded 'Reporitor workflow runs' { Import-BundledModule $script:ReporitorManifest; $repo = Require-Repository; Invoke-RPRead -Repository $repo -Operation Runs } }
            '6' { Invoke-Guarded 'Reporitor finite report bot' { Import-BundledModule $script:ReporitorManifest; $repo = Require-Repository; Invoke-ReporitorBot -Repository $repo -Rounds 1 -IntervalSeconds 0 -Commit } }
            '7' { Invoke-Guarded 'Reporitor accord verification' { Import-BundledModule $script:ReporitorManifest; $repo = Require-Repository; Test-RPAccord -Repository $repo } }
            '8' { Invoke-Guarded 'Start-Reporitor overview' { $repo = Require-Repository; & $script:ReporitorStart -Repository $repo -LocalPath $RepositoryPath } }
            '9' { Invoke-Guarded 'Reporitor self-test' { & $script:ReporitorTest -Repository $Repository -LocalPath $RepositoryPath } }
            'B' { return }
        }
    }
}

function Show-GitsMenu {
    while ($true) {
        Clear-ScriptatureHost
        Write-Rule '4 — GITS LOCAL REPOSITORY ACCORD'
        Write-Host ('Repository path: ' + $RepositoryPath)
        Write-Host '  1  Repository status'
        Write-Host '  2  Read log'
        Write-Host '  3  Read branches'
        Write-Host '  4  Read tags'
        Write-Host '  5  Verify Gits accord'
        Write-Host '  6  Start-Gits overview'
        Write-Host '  7  Initialize repository (explicit local mutation)'
        Write-Host '  8  Local mutation submenu (Add/Commit/Branch/Switch/Tag)'
        Write-Host '  9  Run bundled Gits self-test'
        Write-Host '  P  Change local repository path'
        Write-Host '  B  Back'
        $choice = (Read-Host 'Select').Trim().ToUpperInvariant()
        switch ($choice) {
            '1' { Invoke-Guarded 'Gits status' { Import-BundledModule $script:GitsManifest; Invoke-GitsRead -RepositoryPath $RepositoryPath -Operation Status } }
            '2' { Invoke-Guarded 'Gits log' { Import-BundledModule $script:GitsManifest; Invoke-GitsRead -RepositoryPath $RepositoryPath -Operation Log } }
            '3' { Invoke-Guarded 'Gits branches' { Import-BundledModule $script:GitsManifest; Invoke-GitsRead -RepositoryPath $RepositoryPath -Operation Branches } }
            '4' { Invoke-Guarded 'Gits tags' { Import-BundledModule $script:GitsManifest; Invoke-GitsRead -RepositoryPath $RepositoryPath -Operation Tags } }
            '5' { Invoke-Guarded 'Gits accord verification' { Import-BundledModule $script:GitsManifest; Test-GitsAccord -RepositoryPath $RepositoryPath } }
            '6' { Invoke-Guarded 'Start-Gits overview' { Import-BundledModule $script:GitsManifest; Start-Gits -RepositoryPath $RepositoryPath } }
            '7' { Invoke-Guarded 'Initialize local Git repository' {
                    Import-BundledModule $script:GitsManifest
                    if (-not (Read-YesNo 'Initialize this path as a Git repository?')) { return 'Cancelled.' }
                    Initialize-GitsRepository -Path $RepositoryPath -Commit
                } }
            '8' { Show-GitsMutationMenu }
            '9' { Invoke-Guarded 'Gits self-test' { & $script:GitsTest -RepositoryPath $RepositoryPath } }
            'P' { $value = Read-Host 'Local repository path'; if ($value) { $script:RepositoryPath = [IO.Path]::GetFullPath($value) } }
            'B' { return }
        }
    }
}

function Show-GitsMutationMenu {
    while ($true) {
        Clear-ScriptatureHost
        Write-Rule 'GITS — EXPLICIT LOCAL MUTATIONS'
        Write-Host 'Every operation requires a second confirmation and the module -Commit gate.'
        Write-Host '  1  Add pathspec'
        Write-Host '  2  Commit staged changes'
        Write-Host '  3  Create branch'
        Write-Host '  4  Switch branch'
        Write-Host '  5  Create tag'
        Write-Host '  B  Back'
        $choice = (Read-Host 'Select').Trim().ToUpperInvariant()
        if ($choice -eq 'B') { return }
        Invoke-Guarded 'Gits local mutation' {
            Import-BundledModule $script:GitsManifest
            switch ($choice) {
                '1' { $pathspec = Read-Host 'Pathspec'; if (-not (Read-YesNo "Stage '$pathspec'?")) { return 'Cancelled.' }; Invoke-GitsMutation -RepositoryPath $RepositoryPath -Operation Add -Pathspec $pathspec -Commit }
                '2' { $message = Read-Host 'Commit message'; if (-not (Read-YesNo 'Create this local commit?')) { return 'Cancelled.' }; Invoke-GitsMutation -RepositoryPath $RepositoryPath -Operation Commit -Message $message -Commit }
                '3' { $name = Read-Host 'New branch name'; if (-not (Read-YesNo "Create branch '$name'?")) { return 'Cancelled.' }; Invoke-GitsMutation -RepositoryPath $RepositoryPath -Operation CreateBranch -Name $name -Commit }
                '4' { $name = Read-Host 'Branch name'; if (-not (Read-YesNo "Switch to '$name'?")) { return 'Cancelled.' }; Invoke-GitsMutation -RepositoryPath $RepositoryPath -Operation SwitchBranch -Name $name -Commit }
                '5' { $name = Read-Host 'Tag name'; if (-not (Read-YesNo "Create tag '$name'?")) { return 'Cancelled.' }; Invoke-GitsMutation -RepositoryPath $RepositoryPath -Operation CreateTag -Name $name -Commit }
                default { return 'Unknown selection.' }
            }
        }
    }
}

function Show-ShellMenu {
    while ($true) {
        Clear-ScriptatureHost
        Write-Rule '5 — SHELLNOTION / FORWARD PASS / RECORD-THROUGH'
        Write-Host '  1  ShellNotion overview'
        Write-Host '  2  ShellNotion overview + windows'
        Write-Host '  3  ShellNotion self-test'
        Write-Host '  4  Categories / currents / light snapshot'
        Write-Host '  5  Forward Pass snapshot'
        Write-Host '  6  Forward Pass verify'
        Write-Host '  7  Record-Through status'
        Write-Host '  8  Record-Through write notation'
        Write-Host '  9  Record-Through verify'
        Write-Host ' 10  Record-Through finite roller'
        Write-Host ' 11  Record-Through Windows UI'
        Write-Host '  B  Back'
        $choice = (Read-Host 'Select').Trim().ToUpperInvariant()
        switch ($choice) {
            '1' { Invoke-Guarded 'ShellNotion overview' { & $script:ShellStart } }
            '2' { Invoke-Guarded 'ShellNotion + windows' { & $script:ShellStart -ListWindows } }
            '3' { Invoke-Guarded 'ShellNotion self-test' { & $script:ShellTest } }
            '4' { Invoke-Guarded 'ShellNotion categories/currents/light' {
                    Import-BundledModule $script:ShellManifest
                    [pscustomobject]@{ Categories = @(Get-SNCategory); Current = Get-SNCurrent; Currents = @(Get-SNCurrents); Light = Get-SNLight }
                } }
            '5' { Invoke-Guarded 'Forward Pass snapshot' {
                    $human = Read-Host 'Human note (optional)'
                    $proposal = Read-Host 'Assistant/next proposal (optional)'
                    & $script:ForwardPass -DataDirectory $script:ForwardRoot -HumanNote $human -AssistantProposal $proposal -ScriptEnvironment 'true-reporit-scriptature'
                } }
            '6' { Invoke-Guarded 'Forward Pass verify' { & $script:ForwardPass -DataDirectory $script:ForwardRoot -Verify } }
            '7' { Invoke-Guarded 'Record-Through status' { & $script:RecordCore -RootPath $script:RecordRoot -Action Status -PassThru } }
            '8' { Invoke-Guarded 'Record-Through write notation' {
                    $purpose = Read-Host 'Purpose'
                    $message = Read-Host 'Message'
                    $prior = Read-Host 'Prior reference (optional)'
                    & $script:RecordCore -RootPath $script:RecordRoot -Action Record -Purpose $purpose -Message $message -PriorReference $prior -PassThru
                } }
            '9' { Invoke-Guarded 'Record-Through verify' { & $script:RecordVerify -RootPath $script:RecordRoot -PassThru } }
            '10' { Invoke-Guarded 'Record-Through finite roller' {
                    $purpose = Read-Host 'Purpose'
                    $message = Read-Host 'Message'
                    $count = Read-Int 'Count' 5 1 10000
                    $interval = Read-Int 'Interval seconds' 30 0 86400
                    & $script:RecordRoller -RootPath $script:RecordRoot -Purpose $purpose -Message $message -Count $count -IntervalSeconds $interval -VerifyAfter -PassThru
                } }
            '11' { Invoke-Guarded 'Record-Through Windows UI' { & $script:RecordUI -RootPath $script:RecordRoot } }
            'B' { return }
        }
    }
}

function Get-PythonCommand {
    foreach ($candidate in @('python','py','python3')) {
        $cmd = Get-Command $candidate -ErrorAction SilentlyContinue
        if ($cmd) { return $cmd.Source }
    }
    throw 'Python was not found in PATH.'
}

function Invoke-PythonManager {
    param([Parameter(Mandatory = $true)][string[]]$Arguments)
    $python = Get-PythonCommand
    $oldPythonPath = $env:PYTHONPATH
    try {
        $env:PYTHONPATH = $script:PythonSource
        & $python -m server_script_manager.cli --config $PythonConfig @Arguments
        if ($LASTEXITCODE -ne 0) { throw "Python manager exited with code $LASTEXITCODE." }
    } finally { $env:PYTHONPATH = $oldPythonPath }
}

function Show-PythonMenu {
    while ($true) {
        Clear-ScriptatureHost
        Write-Rule '6 — PYTHON SERVER-SCRIPT MANAGER'
        Write-Host ('Config: ' + $PythonConfig)
        Write-Host '  1  Python/environment check'
        Write-Host '  2  List routines'
        Write-Host '  3  Forecast'
        Write-Host '  4  Run named routine'
        Write-Host '  5  Run reporitor_ticker routine'
        Write-Host '  6  Serve configured interval jobs (foreground; Ctrl+C stops)'
        Write-Host '  7  Run Python tests'
        Write-Host '  B  Back'
        $choice = (Read-Host 'Select').Trim().ToUpperInvariant()
        switch ($choice) {
            '1' { Invoke-Guarded 'Python environment' { $python = Get-PythonCommand; [pscustomobject]@{ Python = $python; Source = $script:PythonSource; Config = $PythonConfig; ConfigExists = Test-Path -LiteralPath $PythonConfig } } }
            '2' { Invoke-Guarded 'Python manager routines' { Invoke-PythonManager @('routines') } }
            '3' { Invoke-Guarded 'Python manager forecast' { Invoke-PythonManager @('forecast') } }
            '4' { Invoke-Guarded 'Python manager — named routine' { $name = Read-Host 'Routine name'; Invoke-PythonManager @('run',$name) } }
            '5' { Invoke-Guarded 'Python manager — reporitor_ticker' { Invoke-PythonManager @('run','reporitor_ticker') } }
            '6' { Invoke-Guarded 'Python manager service loop' { Invoke-PythonManager @('serve') } }
            '7' { Invoke-Guarded 'Python tests' { Invoke-PythonTests } }
            'B' { return }
        }
    }
}

function Invoke-PythonTests {
    $python = Get-PythonCommand
    $oldPythonPath = $env:PYTHONPATH
    try {
        $env:PYTHONPATH = $script:PythonSource
        Push-Location $script:PythonRoot
        try {
            & $python -m unittest discover -s tests -v
            if ($LASTEXITCODE -ne 0) { throw "Python tests exited with code $LASTEXITCODE." }
        } finally { Pop-Location }
    } finally { $env:PYTHONPATH = $oldPythonPath }
}

function Get-CCompiler { foreach ($name in @('cl','gcc','clang')) { $cmd = Get-Command $name -ErrorAction SilentlyContinue; if ($cmd) { return $cmd.Source } }; return $null }
function Get-CppCompiler { foreach ($name in @('cl','g++','clang++')) { $cmd = Get-Command $name -ErrorAction SilentlyContinue; if ($cmd) { return $cmd.Source } }; return $null }

function Show-NativeMenu {
    while ($true) {
        Clear-ScriptatureHost
        Write-Rule '7 — NATIVE CONNECTOR SOURCE / BUILDS'
        Write-Host '  1  Show connector sources'
        Write-Host '  2  Build C connector (detected compiler)'
        Write-Host '  3  Build C++ connector (detected compiler)'
        Write-Host '  4  Build Rust connector with cargo'
        Write-Host '  5  Open build guidance path'
        Write-Host '  B  Back'
        $choice = (Read-Host 'Select').Trim().ToUpperInvariant()
        switch ($choice) {
            '1' { Invoke-Guarded 'Native connector sources' { Get-ChildItem -LiteralPath (Join-Path $script:PythonRoot 'connectors') -Recurse -File | Select-Object FullName,Length } }
            '2' { Invoke-Guarded 'Build C connector' { Build-CConnector } }
            '3' { Invoke-Guarded 'Build C++ connector' { Build-CppConnector } }
            '4' { Invoke-Guarded 'Build Rust connector' { Build-RustConnector } }
            '5' { Invoke-Guarded 'Connector build guidance' { Get-Item -LiteralPath (Join-Path $script:PythonRoot 'connectors\BUILDING.md') | Select-Object FullName,Length } }
            'B' { return }
        }
    }
}

function Build-CConnector {
    $src = Join-Path $script:PythonRoot 'connectors\c\server_ops.c'
    $outDir = Join-Path $script:PythonRoot 'build\native'
    [void](New-Item -ItemType Directory -Path $outDir -Force)
    $compiler = Get-CCompiler
    if (-not $compiler) { throw 'No C compiler found (cl, gcc, or clang).' }
    $leaf = [IO.Path]::GetFileName($compiler).ToLowerInvariant()
    if ($leaf -eq 'cl.exe' -or $leaf -eq 'cl') {
        & $compiler /nologo /LD $src /Fe:(Join-Path $outDir 'server_ops_c.dll')
    } elseif ([Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT) {
        & $compiler -shared -O2 -o (Join-Path $outDir 'server_ops_c.dll') $src
    } else {
        & $compiler -shared -fPIC -O2 -o (Join-Path $outDir 'libserver_ops_c.so') $src
    }
    if ($LASTEXITCODE -ne 0) { throw "C compiler exited with code $LASTEXITCODE." }
    Get-ChildItem -LiteralPath $outDir -File | Where-Object Name -Match 'server_ops_c'
}

function Build-CppConnector {
    $src = Join-Path $script:PythonRoot 'connectors\cpp\server_ops.cpp'
    $outDir = Join-Path $script:PythonRoot 'build\native'
    [void](New-Item -ItemType Directory -Path $outDir -Force)
    $compiler = Get-CppCompiler
    if (-not $compiler) { throw 'No C++ compiler found (cl, g++, or clang++).' }
    $leaf = [IO.Path]::GetFileName($compiler).ToLowerInvariant()
    if ($leaf -eq 'cl.exe' -or $leaf -eq 'cl') {
        & $compiler /nologo /LD /EHsc $src /Fe:(Join-Path $outDir 'server_ops_cpp.dll')
    } elseif ([Environment]::OSVersion.Platform -eq [PlatformID]::Win32NT) {
        & $compiler -shared -O2 -o (Join-Path $outDir 'server_ops_cpp.dll') $src
    } else {
        & $compiler -shared -fPIC -O2 -o (Join-Path $outDir 'libserver_ops_cpp.so') $src
    }
    if ($LASTEXITCODE -ne 0) { throw "C++ compiler exited with code $LASTEXITCODE." }
    Get-ChildItem -LiteralPath $outDir -File | Where-Object Name -Match 'server_ops_cpp'
}

function Build-RustConnector {
    $cargo = Get-Command cargo -ErrorAction SilentlyContinue
    if (-not $cargo) { throw 'cargo was not found in PATH.' }
    $rustRoot = Join-Path $script:PythonRoot 'connectors\rust'
    Push-Location $rustRoot
    try {
        & $cargo.Source build --release
        if ($LASTEXITCODE -ne 0) { throw "cargo exited with code $LASTEXITCODE." }
    } finally { Pop-Location }
    Get-ChildItem -LiteralPath (Join-Path $rustRoot 'target\release') -File -ErrorAction SilentlyContinue | Select-Object FullName,Length
}

function Show-IntegrityMenu {
    while ($true) {
        Clear-ScriptatureHost
        Write-Rule '8 — TESTS AND INTEGRITY'
        Write-Host '  1  Run Python test suite'
        Write-Host '  2  Run ShellNotion self-test'
        Write-Host '  3  Run Ticker self-test'
        Write-Host '  4  Run Gits self-test'
        Write-Host '  5  Run Reporitor self-test'
        Write-Host '  6  Verify True Reporit ledger'
        Write-Host '  7  Verify Ticker state'
        Write-Host '  8  Verify Forward Pass chain'
        Write-Host '  9  Verify Record-Through accord'
        Write-Host ' 10  Hash all scripture files'
        Write-Host ' 11  Run available non-network checks together'
        Write-Host ' 12  ZA completeness analysis'
        Write-Host ' 13  Verify ZA SHA-256 manifest'
        Write-Host ' 14  Refresh ZA SHA-256 manifest (intentional changes)'
        Write-Host ' 15  Write ZA JSON + Markdown report'
        Write-Host '  B  Back'
        $choice = (Read-Host 'Select').Trim().ToUpperInvariant()
        switch ($choice) {
            '1' { Invoke-Guarded 'Python test suite' { Invoke-PythonTests } }
            '2' { Invoke-Guarded 'ShellNotion self-test' { & $script:ShellTest } }
            '3' { Invoke-Guarded 'Ticker self-test' { & $script:TickerTest } }
            '4' { Invoke-Guarded 'Gits self-test' { & $script:GitsTest -RepositoryPath $RepositoryPath } }
            '5' { Invoke-Guarded 'Reporitor self-test' { & $script:ReporitorTest -Repository $Repository -LocalPath $RepositoryPath } }
            '6' { Invoke-Guarded 'True Reporit ledger' { & $script:TrueReporit -Action Verify -StateRoot $StateRoot } }
            '7' { Invoke-Guarded 'Ticker state' { Import-BundledModule $script:TickerManifest; Test-RTState -Root $TickerRoot } }
            '8' { Invoke-Guarded 'Forward Pass chain' { & $script:ForwardPass -DataDirectory $script:ForwardRoot -Verify } }
            '9' { Invoke-Guarded 'Record-Through accord' { & $script:RecordVerify -RootPath $script:RecordRoot -PassThru } }
            '10' { Invoke-Guarded 'Scripture SHA-256 catalog' { Get-ScriptureHashes } }
            '11' { Invoke-Guarded 'Available non-network checks' { Invoke-NonNetworkChecks } }
            '12' { Invoke-Guarded 'ZA completeness analysis' { Import-BundledModule $script:ZAManifest; Invoke-ZAAnalysis -Root $script:Root -VerifyChecksums } }
            '13' { Invoke-Guarded 'ZA SHA-256 verification' { Import-BundledModule $script:ZAManifest; Test-ZAChecksumManifest -Root $script:Root } }
            '14' { Invoke-Guarded 'Refresh ZA SHA-256 manifest' { Import-BundledModule $script:ZAManifest; New-ZAChecksumManifest -Root $script:Root } }
            '15' { Invoke-Guarded 'Write ZA analysis report' { Import-BundledModule $script:ZAManifest; New-ZAReport -Root $script:Root } }
            'B' { return }
        }
    }
}

function Show-ZAMenu {
    while ($true) {
        Clear-ScriptatureHost
        Write-Rule '10 — ZA ANALYSIS + CHECKSUM'
        Write-Host '  1  ZA completeness analysis'
        Write-Host '  2  Verify existing ZA SHA-256 manifest'
        Write-Host '  3  Refresh ZA SHA-256 manifest'
        Write-Host '  4  Generate ZA JSON + Markdown report'
        Write-Host '  5  Run ZA self-test'
        Write-Host '  6  Show ZA governed scripture inventory'
        Write-Host '  7  Show ZA README path'
        Write-Host '  B  Back'
        $choice=(Read-Host 'Select').Trim().ToUpperInvariant()
        switch($choice){
            '1' { Invoke-Guarded 'ZA completeness analysis' { Import-BundledModule $script:ZAManifest; Invoke-ZAAnalysis -Root $script:Root -VerifyChecksums } }
            '2' { Invoke-Guarded 'ZA SHA-256 verification' { Import-BundledModule $script:ZAManifest; Test-ZAChecksumManifest -Root $script:Root } }
            '3' { Invoke-Guarded 'Refresh ZA SHA-256 manifest' { Import-BundledModule $script:ZAManifest; New-ZAChecksumManifest -Root $script:Root } }
            '4' { Invoke-Guarded 'Generate ZA report' { Import-BundledModule $script:ZAManifest; New-ZAReport -Root $script:Root } }
            '5' { Invoke-Guarded 'ZA self-test' { & $script:ZATest -Root $script:Root } }
            '6' { Invoke-Guarded 'ZA governed scripture inventory' { Import-BundledModule $script:ZAManifest; Get-ZAScriptureFiles -Root $script:Root | Select-Object FullName,Length } }
            '7' { Invoke-Guarded 'ZA README' { Get-Item -LiteralPath (Join-Path $script:Root 'ZA\\README.md') | Select-Object FullName,Length,LastWriteTime } }
            'B' { return }
        }
    }
}


function Show-WorkScriptatureMenu {
    while($true){
        Clear-ScriptatureHost; Write-Rule '11 — 34 TRIGGERS ACCORD + MANAGER'
        Write-Host '1  Open dedicated 34 Triggers Manager'; Write-Host '2  Status / embargo state'; Write-Host '3  List all 34 triggers'; Write-Host '4  ULA address check'; Write-Host '5  Raise embargo'; Write-Host '6  Verified lift workflow (manager)'; Write-Host '7  Quarantine sudden disposal'; Write-Host '8  Worker self-test'; Write-Host 'B  Back'
        $c=(Read-Host 'Select').Trim().ToUpperInvariant(); $w=Join-Path $script:Root 'WorkScriptature\Work-Scriptature.ps1'; $m=Join-Path $script:Root 'WorkScriptature\Triggers34-Manager.ps1'
        switch($c){
          '1'{& $m -Repository $script:Repository};'2'{& $w -Action Status|Format-List;Wait-Scriptature};'3'{& $w -Action List|Format-Table id,name,class,severity,action;Wait-Scriptature};'4'{$x=Read-Host 'Relative path or URI';& $w -Action AddressCheck -Target $x|Format-List;Wait-Scriptature};'5'{$x=Read-Host 'Embargo reason';& $w -Action RaiseEmbargo -Target $x|Format-List;Wait-Scriptature};'6'{& $m -Repository $script:Repository};'7'{$x=Read-Host 'Repository-relative file to quarantine';& $w -Action Quarantine -Target $x|Format-List;Wait-Scriptature};'8'{& $w -Action SelfTest|Format-List;Wait-Scriptature};'B'{return}
        }
    }
}

function Get-ScriptureFiles {
    $extensions = @('.ps1','.psm1','.psd1','.py','.c','.cpp','.rs','.toml','.json','.md','.cmd')
    Get-ChildItem -LiteralPath $script:Root -Recurse -File | Where-Object {
        $extensions -contains $_.Extension.ToLowerInvariant() -and
        $_.FullName -notmatch '[\\/]__pycache__[\\/]' -and
        $_.FullName -notmatch '[\\/]build[\\/]' -and
        $_.FullName -notmatch '[\\/]target[\\/]'
    } | Sort-Object FullName
}

function Get-ScriptureHashes {
    foreach ($file in Get-ScriptureFiles) {
        $relative = ($file.FullName.Substring($script:Root.Length) -replace '^[\\/]+','')
        $hash = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        [pscustomobject]@{ Sha256 = $hash; File = $relative }
    }
}

function Show-ScriptureIndex {
    Clear-ScriptatureHost
    Write-Rule '9 — SCRIPTURE INDEX'
    $groups = Get-ScriptureFiles | Group-Object Extension
    foreach ($group in $groups) {
        Write-Host ''
        Write-Host ('[' + $group.Name + ']')
        foreach ($file in $group.Group) {
            $relative = ($file.FullName.Substring($script:Root.Length) -replace '^[\\/]+','')
            Write-Host ('  ' + $relative)
        }
    }
    Write-Host ''
    Write-Host ('Total scripture files: ' + (@(Get-ScriptureFiles).Count))
    Wait-Scriptature
}

function Invoke-NonNetworkChecks {
    $outcomes = New-Object Collections.Generic.List[object]
    try { Invoke-PythonTests | Out-Host; $outcomes.Add([pscustomobject]@{ Check='PythonTests'; Passed=$true; Detail='' }) } catch { $outcomes.Add([pscustomobject]@{ Check='PythonTests'; Passed=$false; Detail=$_.Exception.Message }) }
    try { $r = & $script:ShellTest; $outcomes.Add([pscustomobject]@{ Check='ShellNotion'; Passed=[bool]$r.Passed; Detail='' }) } catch { $outcomes.Add([pscustomobject]@{ Check='ShellNotion'; Passed=$false; Detail=$_.Exception.Message }) }
    try { $r = & $script:TickerTest; $outcomes.Add([pscustomobject]@{ Check='Ticker'; Passed=$true; Detail='Self-test completed.' }) } catch { $outcomes.Add([pscustomobject]@{ Check='Ticker'; Passed=$false; Detail=$_.Exception.Message }) }
    try { $r = & $script:TrueReporit -Action Verify -StateRoot $StateRoot; $outcomes.Add([pscustomobject]@{ Check='TrueReporitLedger'; Passed=[bool]$r.valid; Detail=('Rounds=' + $r.rounds) }) } catch { $outcomes.Add([pscustomobject]@{ Check='TrueReporitLedger'; Passed=$false; Detail=$_.Exception.Message }) }
    return $outcomes
}

while ($true) {
    Show-MainMenu
    $choice = (Read-Host 'Select').Trim().ToUpperInvariant()
    switch ($choice) {
        '1' { Show-TrueReporitMenu }
        '2' { Show-TickerMenu }
        '3' { Show-ReporitorMenu }
        '4' { Show-GitsMenu }
        '5' { Show-ShellMenu }
        '6' { Show-PythonMenu }
        '7' { Show-NativeMenu }
        '8' { Show-IntegrityMenu }
        '9' { Show-ScriptureIndex }
        '10' { Show-ZAMenu }
        '11' { Show-WorkScriptatureMenu }
        'R' {
            $value = Read-Host 'Repository (owner/name; blank clears)'
            if ([string]::IsNullOrWhiteSpace($value)) { $script:Repository = '' }
            elseif ($value -match '^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$') { $script:Repository = $value }
            else { Write-Host 'Invalid owner/name.'; Wait-Scriptature }
        }
        'Q' { return }
    }
}
